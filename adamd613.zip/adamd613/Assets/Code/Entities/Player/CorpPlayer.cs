﻿using UnityEngine;
using System.Collections;

public class CorpPlayer : Entity {

	public static Player control;



	void Start () 
	{	


	}

	void Update ()
	{


		if (Input.GetKey (KeyCode.W) || Input.GetKey (KeyCode.UpArrow)) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;
			moving = true;
			direction = 1;
		}
		if (Input.GetKey (KeyCode.S) || Input.GetKey (KeyCode.DownArrow)) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			moving = true;
			direction = 0;
		}
		if (Input.GetKey (KeyCode.A) || Input.GetKey (KeyCode.LeftArrow)) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
			moving = true;
			direction = 2;
		}
		if (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow)) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;
			moving = true;
			direction = 3;
		}

		if (Input.GetKeyUp (KeyCode.D) || Input.GetKeyUp (KeyCode.RightArrow) || Input.GetKeyUp (KeyCode.W) || Input.GetKeyUp (KeyCode.UpArrow) || Input.GetKeyUp (KeyCode.A) || Input.GetKeyUp (KeyCode.LeftArrow) || Input.GetKeyUp (KeyCode.S) || Input.GetKeyUp (KeyCode.DownArrow)) {
			moving = false;
		}
			
		if (direction == 0 && (Input.GetKey (KeyCode.S) || Input.GetKey (KeyCode.DownArrow))) {
			animator.Play ("WalkDown");
		}
		if (direction == 1 && (Input.GetKey (KeyCode.W) || Input.GetKey (KeyCode.UpArrow))) {
			animator.Play ("WalkUp");
		}
		if (direction == 2 && (Input.GetKey (KeyCode.A) || Input.GetKey (KeyCode.LeftArrow))) {
			animator.Play ("WalkLeft");
		}
		if (direction == 3 && (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow))) {
			animator.Play ("WalkRight");
		}
	}
}