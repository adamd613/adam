﻿using UnityEngine;
using System.Collections;

public class Lazer : MonoBehaviour {

	public Entity player;
	public Animator animator;
	//public bool canAttack;
	public GameObject thisPlayer;

	void Start () 
	{
		animator = GetComponent<Animator> ();
		//canAttack = false;
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		}
	}
	

	void Update () {
	
	}
		

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
				attackEntity ();
		}

	}
	/*void OnTriggerStay2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null && canAttack == true)
		{
			attackEntity ();
			StartCoroutine (waitForAttack());
		}

	}*/
	public void attackEntity()
	{
		int take = (20);
		player.takeHealth(take);
	}
/*	IEnumerator waitForAttack()
	{
		canAttack = false;
		yield return new WaitForSeconds (1);
		canAttack = true;
	}*/
}
