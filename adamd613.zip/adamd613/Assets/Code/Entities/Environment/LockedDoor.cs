﻿using UnityEngine;
using System.Collections;

public class LockedDoor : MonoBehaviour {

	public GameObject thisPlayer;
	public ItemPlayerManager ipManager;
	public Player player;
	public GameObject Door;
	public int thisProg;
	public int newProg;
	public bool setNewProg;
	public bool unlockOnLoad;

	public bool locked = true;
	public bool StartLocked = true;

	void Start () 
	{
		Door = gameObject;
		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		ipManager = thisPlayer.GetComponent<ItemPlayerManager> ();
		player = thisPlayer.GetComponent<Player> ();

	}

	void Update () 
	{
		if (locked == false) 
		{
			if (setNewProg == true) 
			{
				player.doorProg = newProg;
			}
			Unlock ();
		}
		if (StartLocked == false) {
			UnlockStart ();
		}

		if (unlockOnLoad && player.doorProg >= thisProg)
				StartLocked = false;
		
	}

	public void Unlock()
	{
		Destroy (gameObject);
		ipManager.removeItemFromInventory (6, 1);
	}
	public void UnlockStart()
	{
		
		Destroy (gameObject);
	}

}
