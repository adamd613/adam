﻿using UnityEngine;
using System.Collections;

public class PlatformTraps : MonoBehaviour {

	public GameObject ballOne;
	public GameObject ballTwo;
	public GameObject turretOne;
	public GameObject turretTwo;
	public GameObject turretThree;
	public GameObject turretFour;



	void Start () 
	{
		StartCoroutine (startTraps ());
		StartCoroutine (startBalls ());
	}


	void Update () 
	{
	
	}
	IEnumerator startTraps()
	{
		turretOne.SetActive(true);
		turretThree.SetActive(true);
		yield return new WaitForSeconds (1);
		turretTwo.SetActive(true);
		turretFour.SetActive(true);
	}
	IEnumerator startBalls()
	{
		ballOne.SetActive(true);
		ballTwo.SetActive(true);
		yield return new WaitForSeconds (6);
		ballOne.SetActive(false);
		ballTwo.SetActive(false);
		ballOne.transform.position = new Vector3(144, 120.5f, 0);
		ballTwo.transform.position = new Vector3(167, 118.5f, 0);
		yield return new WaitForSeconds (2);
		StartCoroutine(startBalls ());

	}
}
