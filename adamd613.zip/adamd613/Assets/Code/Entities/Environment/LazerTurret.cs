﻿using UnityEngine;
using System.Collections;

public class LazerTurret : MonoBehaviour {

	public GameObject lazer;
	public bool pew;
	

	void Start () 
	{
		pew = true;
	}

	void Update () 
	{
		if (pew == true) 
		{
			StartCoroutine (fireMahLazer ());
		}
	}

	IEnumerator fireMahLazer()
	{
		lazer.SetActive (true);
		yield return new WaitForSeconds (2);
		lazer.SetActive (false);
		pew = false;
		yield return new WaitForSeconds (2);
		pew = true;
	}
}

