﻿using UnityEngine;
using System.Collections;

public class MusicManager : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;

	public GameObject SongOne;
	public GameObject SongTwo;

	public int lvPntOne;
	public int lvPntTwo;

	void Start () {
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

		if (player.levelPoint <= lvPntOne) {
			AudioSource trapMusicOne = SongOne.GetComponent<AudioSource>();

			trapMusicOne.Play();
		}
		if (player.levelPoint >= lvPntTwo) {
			AudioSource trapMusicTwo = SongTwo.GetComponent<AudioSource>();

			trapMusicTwo.Play();
		}
	}
	

	void Update () {
	
	}
}
