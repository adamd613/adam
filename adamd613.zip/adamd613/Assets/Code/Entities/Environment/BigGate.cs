﻿using UnityEngine;
using System.Collections;

public class BigGate : MonoBehaviour {

	public GameObject thisPlayer;

	public Player player;

	public GameObject enemyOne;
	public GameObject enemyTwo;
	public GameObject thisDoor;

	void Start () {
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}
	

	void Update ()
	{
	
		if (player.progPoint >= 2) {
			if(enemyOne != null)
			enemyOne.SetActive (false);
			if(enemyTwo != null)
			enemyTwo.SetActive (false);
			thisDoor.SetActive (false);
		}

	}
}
