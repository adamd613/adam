﻿using UnityEngine;
using System.Collections;

public class Fan : MonoBehaviour {

	public GameObject wind;

	public GameObject thisPlayer;
	public Player player;

	public FloorSwitch switchOne;
	public FloorSwitch switchTwo;

	public int seconds;

	public bool on = true;
	public bool canTurnOn = true;

	void Start () 
	{

		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		player = thisPlayer.GetComponent<Player> ();

	}
	void Update () 
	{
		if (switchOne.isOn == true || switchTwo.isOn == true) {
			on = false;
			if(canTurnOn == true)
				StartCoroutine(timer ());
		}

		if (on == false) {
			wind.SetActive (false);
			GetComponent<Animator> ().enabled = false;
		}
		if (on == true) {
			wind.SetActive (true);
			GetComponent<Animator> ().enabled = true;
		}
	}
	IEnumerator timer()
	{
		canTurnOn = false;
		yield return new WaitForSeconds (seconds);
		on = true;
		canTurnOn = true;
	}
}
