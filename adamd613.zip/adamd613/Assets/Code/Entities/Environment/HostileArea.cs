﻿using UnityEngine;
using System.Collections;

public class HostileArea: MonoBehaviour {

	public Entity player;
	public Animator animator;
	public int Damage;
	public GameObject thisPlayer;

	void Start () 
	{
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		}
	}


	void Update () {
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		}
	}


	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			attackEntity ();
		}

	}
	public void attackEntity()
	{
		int take = (Damage);
		player.takeHealth(take);
	}
}
