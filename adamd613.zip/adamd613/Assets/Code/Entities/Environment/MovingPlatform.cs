﻿using UnityEngine;
using System.Collections;

public class MovingPlatform : MonoBehaviour {

	public GameObject topWall;
	public GameObject rightWall;
	public GameObject leftWall;
	public GameObject bottomWall;

	public GameObject thisPlayer;
	public Player player;

	public bool lefting;
	public bool righting;
	public bool upping;
	public bool downing;

	public float speed;
	public float seconds;

	public FloorSwitch switchOne;


	public bool topPos;
	public bool bottomPos;

	public bool notDead;

	void Start () 
	{
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		}
	
	}
	

	void Update () 

	{
		if (player.health <= 0) {
			notDead = false;
	//		topPos = true;
	//		bottomPos = false;
		//	StopCoroutine (moveToBot ());
		//	StopCoroutine (moveToTop ());

		}


		seconds = 1 / speed;

			if (upping == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			if (notDead == true)
				player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;
			}
			if (righting == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			if (notDead == true) 
				player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;
			
			}
			if (downing == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
			if (notDead == true) 
				player.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			
			}
			if (lefting == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			if (notDead == true) 
				player.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;


		}

		if (topPos == true) {
			bottomWall.SetActive (false);
		}
		if (bottomPos == true) {
			bottomWall.SetActive (false);
		}

		if (switchOne.isOn == true && topPos == true) {

			StartCoroutine (moveToBot ());
		}
		if (switchOne.isOn == true && bottomPos == true ||	notDead == false && bottomPos == true  ) {

			StartCoroutine (moveToTop ());
		}

	}
	IEnumerator moveToBot()
	{
		notDead = true;
			topPos = false;
			upping = true;
			bottomWall.SetActive (true);
			yield return new WaitForSeconds (2 * seconds);
			upping = false;
			righting = true;
			yield return new WaitForSeconds (14 * seconds);
			righting = false;
			downing = true;
			yield return new WaitForSeconds (8 * seconds);
			downing = false;
			righting = true;
			yield return new WaitForSeconds (6.5f * seconds);
			righting = false;	
			downing = true;
			yield return new WaitForSeconds (4 * seconds);
			downing = false;
			bottomPos = true;
	}
	IEnumerator moveToTop()
	{
		
			bottomPos = false;
			bottomWall.SetActive (true);
			upping = true;
			yield return new WaitForSeconds (4 * seconds);
			upping = false;
			lefting = true;
			yield return new WaitForSeconds (6.5f * seconds);
			lefting = false;	
			upping = true;
			yield return new WaitForSeconds (8 * seconds);
			upping = false;
			lefting = true;
			yield return new WaitForSeconds (14 * seconds);
			lefting = false;
			downing = true;
			yield return new WaitForSeconds (2 * seconds);
			downing = false;
			topPos = true;
	}
		
}
