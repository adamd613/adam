﻿using UnityEngine;
using System.Collections;

public class SceneSixTraps : MonoBehaviour {

//	public GameObject ballOne;
//	public GameObject ballTwo;
	public GameObject turretsOne;
	public GameObject turretsTwo;



	void Start () 
	{
		StartCoroutine (startTraps ());
		//StartCoroutine (startBalls ());
	}


	void Update () 
	{

	}
	IEnumerator startTraps()
	{
		turretsOne.SetActive(true);
		yield return new WaitForSeconds (2);
		turretsTwo.SetActive(true);
	
	}
	/*IEnumerator startBalls()
	{
		ballOne.SetActive(true);
		ballTwo.SetActive(true);
		yield return new WaitForSeconds (6);
		ballOne.SetActive(false);
		ballTwo.SetActive(false);
		ballOne.transform.position = new Vector3(144, 120.5f, 0);
		ballTwo.transform.position = new Vector3(167, 118.5f, 0);
		yield return new WaitForSeconds (2);
		StartCoroutine(startBalls ());

	}*/
}
