﻿using UnityEngine;
using System.Collections;

public class WallSwitch : MonoBehaviour {

	public GameObject BlueOne;
	public GameObject BlueTwo;
	public GameObject BlueThree;
	public GameObject BlueFour;

	public GameObject RedOne;
	public GameObject RedTwo;
	public GameObject RedThree;
	public GameObject RedFour;
	public GameObject RedFive;

	public FloorSwitch SwitchOne;
	public FloorSwitch SwitchTwo;
	public FloorSwitch SwitchThree;

	public bool RedOn;
	public bool BlueOn;

	public bool canSwitch;


	void Start () 
	{
		RedOn = true;
		canSwitch = true;

	}
	

	void Update ()
	{
		if ((SwitchOne.isOn == true || SwitchTwo.isOn == true || SwitchThree.isOn == true) && canSwitch == true && RedOn == false) 
		{
			canSwitch = false;
			RedOn = true;
			BlueOn = false;

		}
		else if ((SwitchOne.isOn == true || SwitchTwo.isOn == true || SwitchThree.isOn == true) && canSwitch == true && BlueOn == false) 
		{
			canSwitch = false;
			RedOn = false;
			BlueOn = true;
		}

		if ((SwitchOne.isOn == false && SwitchTwo.isOn == false && SwitchThree.isOn == false) && canSwitch == false) {
			canSwitch = true;
		}

		if (RedOn == true) {
			BlueOne.SetActive (false);
			BlueTwo.SetActive (false);
			BlueThree.SetActive (false);
			BlueFour.SetActive (false);
			RedOne.SetActive (true);
			RedTwo.SetActive (true);
			RedThree.SetActive (true);
			RedFour.SetActive (true);
			RedFive.SetActive (true);
		}


			if (BlueOn == true) 
		{
			BlueOne.SetActive (true);
			BlueTwo.SetActive (true);
			BlueThree.SetActive (true);
			BlueFour.SetActive (true);
			RedOne.SetActive (false);
			RedTwo.SetActive (false);
			RedThree.SetActive (false);
			RedFour.SetActive (false);
			RedFive.SetActive (false);
		}

	}
}

