﻿using UnityEngine;
using System.Collections;

public class SpiderSpawnerDetection : MonoBehaviour {


	public GameObject thisPlayer;

	public Player player;

	public bool canLaunch;

	public GameObject Crystal;

	public GameObject spiderMinnion;

	public GameObject spawnerMain;



	void Start () {

		canLaunch = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

	

	}

	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			if (canLaunch == false) {
				StartCoroutine (LaunchSpiders ());
			}
		}
	}
	IEnumerator LaunchSpiders()
	{
		canLaunch = true;
		Crystal.SetActive (true);
		yield return new WaitForSeconds (1.5f);
		GameObject tmpMinnion =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x + 2, spawnerMain.transform.position.y, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionTwo =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x - 2, spawnerMain.transform.position.y, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionThree =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x, spawnerMain.transform.position.y + 2, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionFour =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x, spawnerMain.transform.position.y - 2, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionFive =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x + 2, spawnerMain.transform.position.y + 2, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionSix =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x + 2, spawnerMain.transform.position.y - 2, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionSeven =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x - 2, spawnerMain.transform.position.y + 2, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionEight =  (GameObject)Instantiate(spiderMinnion, new Vector3(spawnerMain.transform.position.x - 2, spawnerMain.transform.position.y - 2, 0), Quaternion.identity);
		Crystal.SetActive (false);
		yield return new WaitForSeconds (60f);
		canLaunch = false;

	}


}
