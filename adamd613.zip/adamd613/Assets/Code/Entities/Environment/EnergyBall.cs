﻿using UnityEngine;
using System.Collections;

public class EnergyBall : MonoBehaviour {

		public Entity player;
		public Animator animator;

		public GameObject thisPlayer;

		public bool lefting;
		public bool righting;
		public bool upping;
		public bool downing;

		public int speed;

		void Start () 
		{
			animator = GetComponent<Animator> ();
			if (thisPlayer == null) 
			{
				thisPlayer = GameObject.FindGameObjectWithTag ("Player");
				player = thisPlayer.GetComponent<Entity> ();
			}
		}


		void Update () 
		{

		if (upping == true) 
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
		}
		if (righting == true) 
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
		}
		if (downing == true) 
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
		}
		if (lefting == true) 
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
		}

		}


		void OnTriggerEnter2D(Collider2D col)
		{
			if(col.GetComponent<Player>() != null)
			{
				attackEntity ();
			}

		}

		public void attackEntity()
		{
			int take = (20);
			player.takeHealth(take);
		}

	}
