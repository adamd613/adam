﻿using UnityEngine;
using System.Collections;

public class LoganBoss: Entity {

	public GameObject lazers;
	public GameObject DeathLog;
	public GameObject prizeChest;

	public GameObject thisOldLogan;
	public AttackingLogan oldLogan;
	public GameObject thisPlayer;
	public Entity attacking;
	public Player loot;


	public EndingDialogue dialogueOne;
	public OrderedDialogue dialogueTwo;

	public GameObject deadSprite;

	public bool lefting;
	public bool downing;
	public bool righting;
	public bool upping;

	public GameObject bossHealth;
	public BossHealth bHealth;

	void Start () {

		lefting = false;
		downing = false;
		righting = false;
		upping = false;

		animator = GetComponent<Animator> ();
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			attacking = thisPlayer.GetComponent<Entity> ();
			loot = thisPlayer.GetComponent<Player> ();
		} 
		speed = 4;
		transform.position = new Vector3(150,51.2f,0);
		oldLogan = thisOldLogan.GetComponent<AttackingLogan> ();
		StartCoroutine (Waiting ());
		StartCoroutine (RunningAway ());
	}

	void Update ()
	{
		if (loot.health > 0) {
			bossHealth.SetActive (true);
			bHealth.isLoganOne = false;
			bHealth.isLoganTwo = true;
		}
		if (lefting == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
			animator.Play ("WalkLeft");
			StartCoroutine (stopping ());
		}
		if (downing == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			animator.Play ("WalkDown");
			StartCoroutine (stopping ());
		}
		if (righting == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			animator.Play ("WalkRight");
			StartCoroutine (stopping ());
		}
		if (upping == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			animator.Play ("WalkUp");
			StartCoroutine (stopping ());
		}
		if (dialogueOne.textNum >= 1) {
			dialogueOne.toggleOff ();
		}
		if (dialogueTwo.textNum >= 5) {
			dialogueTwo.enabled = false;
		}

		if (attacking.health <= 0)
			health = maxHealth;
			
		if (health <= 0) {
			bossHealth.SetActive (false);
			Die ();
		}
	}
		
	IEnumerator RunningAway()
	{
		yield return new WaitForSeconds (2f);
		lazers.SetActive (true);
	
	}

	IEnumerator Waiting()
	{
		if (GetComponent<Rigidbody2D> ().isKinematic == false){
			GetComponent<Rigidbody2D> ().isKinematic = true;
		}
	
		downing = !downing;
		yield return new WaitForSeconds (2.5f);
		downing = !downing;
		righting = !righting;
		yield return new WaitForSeconds (2.7f);
		righting = !righting;
		upping = !upping;
		yield return new WaitForSeconds (2.5f);
		upping = !upping;
		lefting = !lefting;
		yield return new WaitForSeconds (2.7f);
		lefting = !lefting;
		StartCoroutine (Waiting ());
	}

		


	public void Die()
	{
		GetComponent<Rigidbody2D> ().isKinematic = false;
		spriteParent.enabled = false;
		deadSprite.SetActive (true);
		dialogueOne.enabled = false;
		transform.position = new Vector3(155, 47, 0);
		lazers.SetActive (false);
		DeathLog.SetActive (true);
		prizeChest.SetActive (true);
		animator.enabled = false;
		GetComponent<Rigidbody2D> ().isKinematic = true;
		int add = Random.Range (100, 200);
		loot.maxHealth += 25;
		loot.addMoney (add);
		Dead ();
	}
	public void Dead()
	{
		enabled = false;
	}
	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
}

