﻿using UnityEngine;
using System.Collections;

public class AttackingPat : Entity {

	public GameObject thisPlayer;

	public Player player;
	public float distance;
	public float range;

	public Vector2 forwardPos, backPos, sidePos;
	//public SpriteRenderer weaponSpriteParent;
//	public CircleCollider2D DamageCollider2D;
	public bool swing;

	public bool onCoolDown;
	public bool inRange;
	public bool canAttack;

	public bool starting;
	public bool canKill;
	public int stage;
	public int counter;

	public bool canStage;

	public EndingDialogue deathLog;

	public GameObject teleport;
	public GameObject attackAnim;
	public SpriteRenderer patSprite;

	public GameObject ballOne;
	public GameObject ballTwo;
	public GameObject ballThree;
	public GameObject ballFour;
	public GameObject ballFive;
	public GameObject ballSix;
	public GameObject ballSeven;
	public GameObject ballEight;
	public GameObject ballNine;
	public GameObject ballTen;
	public GameObject ballEleven;
	public GameObject ballTwelve;
	public GameObject ballThirteen;
	public GameObject ballFourteen;
	public GameObject ballFifteen;
	public GameObject ballSixteen;
	public GameObject ballSeventeen;
	public GameObject ballEighteen;

	public GameObject bossHealth;

	void Start () {

		animator = GetComponent<Animator> ();
		canAttack = false;
		swing = false;
		inRange = false;
		onCoolDown = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (isHostile == false) {
			armor = 100;
		}
		if (isHostile == true) {
			armor = 5;
		}

		if (health <= 0) {
			Die ();
			bossHealth.SetActive (false);
		}

			if (direction == 0 && moving == true)
			{
				animator.Play ("WalkDown");
			}
			if (direction == 1 && moving == true)
			{
				animator.Play ("WalkUp");
			}
			if (direction == 2 && moving == true)
			{
				animator.Play ("WalkLeft");
			}
			if (direction == 3 && moving == true)
			{
				animator.Play ("WalkRight");
			}

		if (starting == false) {
			bossHealth.SetActive (true);
			StartCoroutine (rollDice ());
		}
		if (player.health <= 0) {
			stage = 0;
			counter = 0;
			starting = false;
			canStage = false;
			bossHealth.SetActive (false);

		}
		if ((stage == 1 || stage == 2 || stage == 3 || stage == 4) && canStage == false) {
			StartCoroutine (porting ());
		}
		if ((stage == 5 || stage == 6) && canStage == false) {
			StartCoroutine (ballBarrage ());
		}

		if (canKill == true) {
			player.takeHealth (10);
			canKill = false;
		}
			

	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
	
		}
	}	
	IEnumerator rollDice()
	{
		starting = true;
		yield return new WaitForSeconds (1);
		if (counter < 6) {
			stage = Random.Range (1, 7);
			counter += 1;
		} else {
			StartCoroutine (killing ());
		}




	}
	IEnumerator killing()
	{

		patSprite.enabled = false;
		isHostile = false;
		transform.position = new Vector3(-232, 55, 0);
		yield return new WaitForSeconds (1f);

		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		patSprite.enabled = true;
		isHostile = true;

			attackAnim.SetActive (true);
			canKill = true;
			yield return new WaitForSeconds (.5f);
			canKill = true;
			yield return new WaitForSeconds (.5f);
			canKill = true;
			yield return new WaitForSeconds (.5f);
			canKill = true;
			yield return new WaitForSeconds (.5f);
			canKill = true;
			yield return new WaitForSeconds (.5f);
			attackAnim.SetActive (false);


		patSprite.enabled = false;
		teleport.SetActive (true);
		isHostile = false;
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);

		starting = false;
		counter = 0;
		stage = 0;
	}

	IEnumerator ballBarrage()
	{
		canStage = true;
		isHostile = false;
		patSprite.enabled = false;
		transform.position = new Vector3(-232, 55, 0);
		yield return new WaitForSeconds (1f);

		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		isHostile = true;
		teleport.SetActive (false);
		patSprite.enabled = true;
		if (stage == 5) 
		{
			ballFive.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballSix.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballSeven.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballEight.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballNine.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballTen.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballEleven.SetActive (true);
			yield return new WaitForSeconds (.4f);
			ballFive.SetActive (false);
			yield return new WaitForSeconds (.4f);
			ballSix.SetActive (false);
			yield return new WaitForSeconds (.4f);
			ballSeven.SetActive (false);
			yield return new WaitForSeconds (.3f);
			ballEight.SetActive (false);
			yield return new WaitForSeconds (.3f);
			ballNine.SetActive (false);
			yield return new WaitForSeconds (.2f);
			ballTen.SetActive (false);
			yield return new WaitForSeconds (.2f);
			ballEleven.SetActive (false);
			yield return new WaitForSeconds (.1f);
			ballFive.transform.position = new Vector3(-238, 60, 0);
			ballSix.transform.position = new Vector3(-236, 60, 0);
			ballSeven.transform.position = new Vector3(-234, 60, 0);
			ballEight.transform.position = new Vector3(-232, 60, 0);
			ballNine.transform.position = new Vector3(-230, 60, 0);
			ballTen.transform.position = new Vector3(-228, 60, 0);
			ballEleven.transform.position = new Vector3(-226, 60, 0);
			patSprite.enabled = false;
			teleport.SetActive (true);
			isHostile = false;
			yield return new WaitForSeconds (.4f);
			teleport.SetActive (false);
			starting = false;
			canStage = false;
			stage = 0;
			 
		}
		if (stage == 6) 
		{
			ballTwelve.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballThirteen.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballFourteen.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballFifteen.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballSixteen.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballSeventeen.SetActive (true);
			yield return new WaitForSeconds (.8f);
			ballEighteen.SetActive (true);
			yield return new WaitForSeconds (.4f);
			ballTwelve.SetActive (false);
			yield return new WaitForSeconds (.4f);
			ballThirteen.SetActive (false);
			yield return new WaitForSeconds (.4f);
			ballFourteen.SetActive (false);
			yield return new WaitForSeconds (.3f);
			ballFifteen.SetActive (false);
			yield return new WaitForSeconds (.3f);
			ballSixteen.SetActive (false);
			yield return new WaitForSeconds (.2f);
			ballSeventeen.SetActive (false);
			yield return new WaitForSeconds (.2f);
			ballEighteen.SetActive (false);
			yield return new WaitForSeconds (.1f);
			ballTwelve.transform.position = new Vector3(-226, 49, 0);
			ballThirteen.transform.position = new Vector3(-228, 49, 0);
			ballFourteen.transform.position = new Vector3(-230, 49, 0);
			ballFifteen.transform.position = new Vector3(-232, 49, 0);
			ballSixteen.transform.position = new Vector3(-234, 49, 0);
			ballSeventeen.transform.position = new Vector3(-236, 49, 0);
			ballEighteen.transform.position = new Vector3(-238, 49, 0);
			patSprite.enabled = false;
			teleport.SetActive (true);
			isHostile = false;
			yield return new WaitForSeconds (.4f);
			teleport.SetActive (false);
			starting = false;
			canStage = false;
			stage = 0;
		}
	}

	IEnumerator porting()
	{
		canStage = true;
		isHostile = false;
		patSprite.enabled = false;
		if (stage == 1) {
			transform.position = new Vector3(-229, 57, 0);
		}
		if (stage == 2) {
			transform.position = new Vector3(-235, 57, 0);
		}
		if (stage == 3) {
			transform.position = new Vector3(-229, 52, 0);
		}
		if (stage == 4) {
			transform.position = new Vector3(-235, 52, 0);
		}
		yield return new WaitForSeconds (1f);
		stage = 0;
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		isHostile = true;
		teleport.SetActive (false);
		patSprite.enabled = true;
		ballOne.SetActive(true);
		ballTwo.SetActive(true);
		ballThree.SetActive(true);
		ballFour.SetActive(true);
		yield return new WaitForSeconds (3f);
		ballOne.SetActive(false);
		ballTwo.SetActive(false);
		ballThree.SetActive(false);
		ballFour.SetActive(false);
		yield return new WaitForSeconds (.1f);
		ballOne.transform.position = patSprite.transform.position;
		ballTwo.transform.position = patSprite.transform.position;
		ballThree.transform.position = patSprite.transform.position;
		ballFour.transform.position = patSprite.transform.position;
		patSprite.enabled = false;
		teleport.SetActive (true);
		isHostile = false;
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		starting = false;
		canStage = false;
	}

	public void Die()
	{
		deathLog.enabled = true;
		int add = Random.Range (100, 200);
		player.maxHealth += 25;
		player.addMoney (add);
		Dead ();
	}
	public void Dead()
	{
		enabled = false;
	}
		
}

