﻿using UnityEngine;
using System.Collections;

public class SpiderBoss: Entity {

	public GameObject thisPlayer;

	public Player player;
	public bool swing;

	public bool canMove;

	public bool canLaunch;

	public bool starting;
	public int stage;
	public int mover;
	public int counter;

	public bool canStage;

//	public EndingDialogue deathLog;

	public GameObject attackAnim;
	public SpiderBossAttack attacking;
	public GameObject scareFace;

	public GameObject spiderMinnion;

	public Transform targetOne;
	public Transform targetTwo;
	public Transform targetThree;
	public Transform targetFour;

	public Transform launchTarget;

	public bool isArmored;

	public GameObject bossHealth;

	void Start () {

		isHostile = true;
		canLaunch = false;
		swing = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{


		if (health <= 0) {
			bossHealth.SetActive (false);
			Die ();
		}

		if (isArmored == false) {
			armor = 0;
		}
		if (isArmored == true) {
			armor = 50;
		}

		if (starting == false) {
			bossHealth.SetActive (true);
			StartCoroutine (rollDice ());
		}
		if (player.health <= 0) 
		{
			bossHealth.SetActive (false);
			stage = 0;
			counter = 0;
			starting = false;
			canStage = false;


		}
		if ((stage == 1 || stage == 2 || stage == 3 || stage == 4) && canStage == false) {
			StartCoroutine (MoveAndAttack ());
		}
		if ((stage == 5 || stage == 6) && canStage == false) {
			StartCoroutine (RushAcross ());
		}
		if(canMove == true)
		{
			if (stage == 1 || mover == 1) {
			transform.position = Vector3.MoveTowards(transform.position, targetOne.position, speed * Time.deltaTime);
			}
			if (stage == 2 || mover == 2) {
			transform.position = Vector3.MoveTowards(transform.position, targetTwo.position, speed * Time.deltaTime);
			}
			if (stage == 3 || mover == 3) {
			transform.position = Vector3.MoveTowards(transform.position, targetThree.position, speed * Time.deltaTime);
			}
			if (stage == 4 || mover == 4) {
			transform.position = Vector3.MoveTowards(transform.position, targetFour.position, speed * Time.deltaTime);
			}

		}
		if (canLaunch == true) {
			transform.position = Vector3.MoveTowards(transform.position, launchTarget.position, speed * Time.deltaTime);
		}
	}

	IEnumerator rollDice()
	{
		starting = true;
		yield return new WaitForSeconds (1);
		if (counter < 5) {
			stage = Random.Range (1, 7);
			counter += 1;
		} else 
		{
			StartCoroutine (LaunchSpiders ());
		}



	}
	IEnumerator LaunchSpiders()
	{
		canLaunch = true;
		speed = 5;
		yield return new WaitForSeconds (3f);
		scareFace.SetActive (true);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnion =  (GameObject)Instantiate(spiderMinnion, new Vector3(151f, 154f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionTwo =  (GameObject)Instantiate(spiderMinnion, new Vector3(155f, 154f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionThree =  (GameObject)Instantiate(spiderMinnion, new Vector3(151f, 151f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionFour =  (GameObject)Instantiate(spiderMinnion, new Vector3(151f, 154f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionFive =  (GameObject)Instantiate(spiderMinnion, new Vector3(159f, 151f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionSix =  (GameObject)Instantiate(spiderMinnion, new Vector3(159f, 154f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionSeven =  (GameObject)Instantiate(spiderMinnion, new Vector3(151f, 146f, 0), Quaternion.identity);
		yield return new WaitForSeconds (.5f);
		GameObject tmpMinnionEight =  (GameObject)Instantiate(spiderMinnion, new Vector3(159f, 146f, 0), Quaternion.identity);
		scareFace.SetActive (false);
		canLaunch = false;
		starting = false;
		speed = 3;
		counter = 0;
		stage = 0;
	}

	IEnumerator RushAcross()
	{
		canStage = true;
		canMove = true;
		speed = 8;
		scareFace.SetActive (true);
		if (stage == 5) 
		{
			mover = 1;
			yield return new WaitForSeconds (3f);
			attackAnim.SetActive (true);
			attacking.cantAttack = false;
			isArmored = true;
			mover = 2;
			yield return new WaitForSeconds (2f);
			mover = 3;
			yield return new WaitForSeconds (2f);
			mover = 4;
			yield return new WaitForSeconds (2f);
			isArmored = false;
			attackAnim.SetActive (false);
			yield return new WaitForSeconds (1f);
			starting = false;
			canStage = false;
			mover = 0;
			stage = 0;
			speed = 3;

		}
		if (stage == 6) 
		{
			mover = 2;
			yield return new WaitForSeconds (3f);
			attackAnim.SetActive (true);
			attacking.cantAttack = false;
			isArmored = true;
			mover = 1;
			yield return new WaitForSeconds (2f);
			mover = 4;
			yield return new WaitForSeconds (2f);
			mover = 3;
			yield return new WaitForSeconds (2f);
			isArmored = false;
			attackAnim.SetActive (false);
			yield return new WaitForSeconds (1f);
			starting = false;
			canStage = false;
			mover = 0;
			stage = 0;
			speed = 3;
		}
	}

	IEnumerator MoveAndAttack()
	{
		canStage = true;
		canMove = true;
		speed = 3;
		scareFace.SetActive (true);
		yield return new WaitForSeconds (1f);
		attackAnim.SetActive (true);
		attacking.cantAttack = false;
		isArmored = true;
		yield return new WaitForSeconds (4f);
		scareFace.SetActive (false);
		attackAnim.SetActive (false);
		isArmored = false;
		yield return new WaitForSeconds (1f);
		canMove = false;
		stage = 0;
		starting = false;
		canStage = false;
	}

	public void Die()
	{
		int add = Random.Range (100, 200);
		player.maxHealth += 25;
		player.addMoney (add);
		Dead ();
	}
	public void Dead()
	{
		enabled = false;
		Destroy (gameObject);
	}

}

