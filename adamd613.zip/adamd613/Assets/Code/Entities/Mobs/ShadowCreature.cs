﻿using UnityEngine;
using System.Collections;

public class ShadowCreature : Entity {

	public GameObject thisPlayer;
	public Entity attacking;
	public Player loot;
	public float distance;
	public float range;

	public CircleCollider2D DamageCollider2D;
	public bool swing;

	public SpriteRenderer AttackAnim;

	public bool onCoolDown;
	public bool inRange;
	public bool canAttack;

	public bool selfDestruct;


	void Start () {

		canAttack = false;
		swing = false;
		inRange = false;
		onCoolDown = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			attacking = thisPlayer.GetComponent<Entity> ();
			loot = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update ()
	{
		if (swing == true) {
			AttackAnim.enabled = true;
		} else {
			AttackAnim.enabled = false;
		}
		if (selfDestruct == true) {
			if(attacking.health <= 0)
				Destroy (gameObject);
		}
		if (attacking.maxHealth == 175 && selfDestruct == true && loot.progPoint == 20) {
			Destroy (gameObject);
		}

			

		{
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			{
				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
				direction = 1;
				StartCoroutine (stopping());
			}
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance)) 
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			{
				GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
				direction = 0;
				StartCoroutine (stopping());
			} 
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			{ 
				GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
				direction = 3;
				StartCoroutine (stopping());
			}
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			{
				GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
				direction = 2;
				StartCoroutine (stopping());
			}

			/*if (Vector2.Distance (GetComponent<Rigidbody2D>().transform.position, attacking.transform.position) <= distance && canAttack) 
				{
					attackEntity ();
					StartCoroutine (waitForAttack());
				}*/
			if (health <= 0)
				Die ();

			if (canAttack == true && inRange == true && (loot.shadowsOn == true || loot.progPoint >= 16)) {
				attackEntity ();
				canAttack = false;
				StartCoroutine (waitForAttack ());
			}
		}
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = true;
			canAttack = false;
			if (onCoolDown == false) {
				StartCoroutine (waitForAttack ());
			}
			speed = 0;
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = false;
			canAttack = false;
			StopCoroutine (waitForAttack ());
			StartCoroutine (speedUp ());
		}
	}
	IEnumerator speedUp()
	{
		yield return new WaitForSeconds (1f);
		if (inRange == false) {
			speed = 2;
		}
	}
	IEnumerator waitForAttack()
	{
		onCoolDown = true;
		canAttack = false;
		yield return new WaitForSeconds (1.25f);
		if (inRange == true) {
			canAttack = true;
		}
		onCoolDown = false;

	}

	public void Die()
	{
		print ("Enemy Slain");
		int add = Random.Range (5, 10);
		loot.addMoney (add);
		Destroy (gameObject);
	}

	public void attackEntity()
	{
		canAttack = false;
		StartCoroutine (Swinging ());
		int take = Random.Range (8, 15);
		attacking.takeHealth(take);


	}

	IEnumerator Swinging()
	{
		swing = true;
		yield return new WaitForSeconds (.3f);
		swing = false;
	}

	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
}

