﻿using UnityEngine;
using System.Collections;

public class AttackingLogan: Entity {

	public GameObject newLogan;

	public GameObject thisPlayer;
	public Entity attacking;
	public Player loot;
	public float distance;
	public float range;

	public Vector2 forwardPos, backPos, sidePos;
	public SpriteRenderer weaponSpriteParent;
	public CircleCollider2D DamageCollider2D;
	public bool swing;
	public bool swingTwo;

	public bool onCoolDown;
	public bool inRange;
	public bool canAttack;

	public GameObject bossHealth;

	void Start () {

		canAttack = false;
		swing = false;
		inRange = false;
		onCoolDown = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			attacking = thisPlayer.GetComponent<Entity> ();
			loot = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update ()
	{
		if (direction == 0) {
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;	
			weaponSpriteParent.transform.localPosition = forwardPos;
			if (swing == true && swingTwo == false) {
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, 20);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = forwardPos;
			}
			if (swing == true && swingTwo == true) 
			{
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, -5);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = forwardPos;
			}
		}
		if (direction == 1) {
			weaponSpriteParent.sortingOrder = 19;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = backPos;
			if (swing == true && swingTwo == false) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 70);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = backPos;
			}
			if (swing == true && swingTwo == true)  {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 95);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = backPos;
			}
		}
		if (direction == 2) {
			weaponSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (0, 0, 90);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			if (swing == true && swingTwo == false) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 115);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
			if (swing == true && swingTwo == true) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 140);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
		}
		if (direction == 3) {
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			if (swing == true && swingTwo == false) {
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, -25);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
			if (swing == true && swingTwo == true) {
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, -50);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
		}

		if (attacking.health <= 0)
			health = maxHealth;
		

		{
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			{

				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
				direction = 1;
				StartCoroutine (stopping());
				if(loot.health >0)
					bossHealth.SetActive (true);
			}
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance)) 
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			{

				GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
				direction = 0;
				StartCoroutine (stopping());
				if(loot.health >0)
					bossHealth.SetActive (true);
			} 
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			{ 

				GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
				direction = 3;
				StartCoroutine (stopping());
				if(loot.health >0)
					bossHealth.SetActive (true);
			}
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			{

				GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
				direction = 2;
				StartCoroutine (stopping());
				if(loot.health >0)
					bossHealth.SetActive (true);
			}

			/*if (Vector2.Distance (GetComponent<Rigidbody2D>().transform.position, attacking.transform.position) <= distance && canAttack) 
				{
					attackEntity ();
					StartCoroutine (waitForAttack());
				}*/
			if (health <= 0) {
				StartCoroutine (waitToDie ());
				if (loot.health > 0)
					bossHealth.SetActive (false);
				
			}

			if (direction == 0 && moving == true)
			{
				animator.Play ("WalkDown");
			}
			if (direction == 1 && moving == true)
			{
				animator.Play ("WalkUp");
			}
			if (direction == 2 && moving == true)
			{
				animator.Play ("WalkLeft");
			}
			if (direction == 3 && moving == true)
			{
				animator.Play ("WalkRight");
			}
			if (canAttack == true && inRange == true) {
				attackEntity ();
				canAttack = false;
				StartCoroutine (waitForAttack ());
			}
		}
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = true;
			canAttack = false;
			if (onCoolDown == false) {
				StartCoroutine (waitForAttack ());
			}
			speed = 0;
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = false;
			canAttack = false;
			StopCoroutine (waitForAttack ());
			StartCoroutine (speedUp ());
		}
	}
	IEnumerator speedUp()
	{
		yield return new WaitForSeconds (1f);
		if (inRange == false) {
			speed = 5;
		}
	}
	IEnumerator waitForAttack()
	{
		onCoolDown = true;
		canAttack = false;
		yield return new WaitForSeconds (1.25f);
		if (inRange == true) {
			canAttack = true;
		}
		onCoolDown = false;

	}
	public void attackEntity()
	{
		canAttack = false;
		StartCoroutine (Swinging ());
		int take = Random.Range (15, 25);
		attacking.takeHealth(take);


	}
	IEnumerator Swinging()
	{
		swing = true;
		yield return new WaitForSeconds (.15f);
		swingTwo = true;	
		yield return new WaitForSeconds (.15f);
		swingTwo = false;
		swing = false;
	}

	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
	IEnumerator waitToDie()
	{
		newLogan.SetActive (true);

		yield return new WaitForSeconds (.1f);
		Destroy (gameObject);
	}
}

