﻿using UnityEngine;
using System.Collections;

public class ShootingMob : Entity {

	public GameObject thisPlayer;
	public Entity enemy;
	public Entity attacking;
	public Player loot;
	public float distance;
	public float range;

	public SpriteRenderer weaponSpriteParent;
	public SpriteRenderer shootingSpriteParent;
	public BoxCollider2D DamageCollider2D;
	public Vector2 forwardPos, backPos, sidePos;

	public bool onCoolDown;
	public bool inRange;
	public bool canAttack;

	void Start () 
	{
		canAttack = false;
		inRange = false;
		onCoolDown = false;
		weaponSpriteParent.enabled = true;
		shootingSpriteParent.enabled = false;
		animator = GetComponent<Animator> ();
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			attacking = thisPlayer.GetComponent<Entity> ();
			loot = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update () 
	{
		if (direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			shootingSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, -90);
			weaponSpriteParent.transform.localRotation = newRot;	
			weaponSpriteParent.transform.localPosition = forwardPos;
			DamageCollider2D.offset = new Vector2 (3, -.25f);
			DamageCollider2D.size = new Vector2 (5f, .5f);
		}
		if (direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			shootingSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (0, 0, 90);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = backPos;
			DamageCollider2D.offset = new Vector2 (3, -.25f);
			DamageCollider2D.size = new Vector2 (5f, .5f);

		}
		if (direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			shootingSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (180, 0, 180);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (3, 0);
			DamageCollider2D.size = new Vector2 (5f, .5f);

		}
		if (direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			shootingSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (3, 0);
			DamageCollider2D.size = new Vector2 (5f, .5f);

		}
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			direction = 1;
			StartCoroutine (stopping());
		}
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance)) 
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			direction = 0;
			StartCoroutine (stopping());
		} 
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
		{ 
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			direction = 3;
			StartCoroutine (stopping());
		}
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
		if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
			direction = 2;
			StartCoroutine (stopping());
		}
			
		if (health <= 0)
			Die ();

		if (direction == 0 && moving == true)
		{
			animator.Play ("WalkDown");
		}
		if (direction == 1 && moving == true)
		{
			animator.Play ("WalkUp");
		}
		if (direction == 2 && moving == true)
		{
			animator.Play ("WalkLeft");
		}
		if (direction == 3 && moving == true)
		{
			animator.Play ("WalkRight");
		}
		if (canAttack == true && inRange == true) {
			attackEntity ();
			canAttack = false;
			StartCoroutine (waitForAttack ());
		}
	}

	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = true;
			canAttack = false;
			if (onCoolDown == false) {
				StartCoroutine (waitForAttack ());
			}
			speed = 0;
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = false;
			canAttack = false;
			StopCoroutine (waitForAttack ());
			StartCoroutine (speedUp ());
		}
	}
	IEnumerator speedUp()
	{
		yield return new WaitForSeconds (1.25f);
		if (inRange == false) {
			speed = 4;
		}
	}
	IEnumerator waitForAttack()
	{
		onCoolDown = true;
		canAttack = false;
		yield return new WaitForSeconds (1.5f);
		if (inRange == true) {
			canAttack = true;
		}
		onCoolDown = false;

	}

	
	public void Die()
	{
		print ("Enemy Slain");
		int add = Random.Range (10, 20);
		loot.addMoney (add);
		loot.ipManager.addToItemInventory (5, 5);
		Destroy (gameObject);
	}

	public void attackEntity()
	{
		canAttack = false;
		int take = Random.Range (5, 15);
		attacking.takeHealth(take);
		StartCoroutine (flashSprite());


	}
		

	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
	IEnumerator flashSprite()
	{
		weaponSpriteParent.enabled = false;
		shootingSpriteParent.enabled = true;
		yield return new WaitForSeconds (.1f);
		weaponSpriteParent.enabled = true;
		shootingSpriteParent.enabled = false;
	}
}
