﻿using UnityEngine;
using System.Collections;

public class SpiderBossAttack : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public BoxCollider2D thisCollider;

	public bool cantAttack;

	void Start () {
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		}
	}
	

	void Update () 
	{
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		}
		if(cantAttack == false)
			StartCoroutine (flashAttack ());
	}
	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			attackEntity ();
		}

	}

	public void attackEntity()
	{
		int take = (15);
		player.takeHealth(take);
	}
	IEnumerator flashAttack()
	{
		cantAttack = true;
		thisCollider.enabled = true;
		yield return new WaitForSeconds (.9f);
		thisCollider.enabled = false;
		yield return new WaitForSeconds (.1f);
		cantAttack = false;
	}
}
