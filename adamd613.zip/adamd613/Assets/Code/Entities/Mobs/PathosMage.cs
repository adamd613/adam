﻿using UnityEngine;
using System.Collections;

public class PathosMage: Entity {

	public GameObject thisPlayer;
	public Entity attacking;
	public Player loot;
	public float distance;
	public float range;

	public Vector2 forwardPos, backPos, sidePos;
	public SpriteRenderer weaponSpriteParent;
	public CircleCollider2D DamageCollider2D;
	public bool swing;

	public bool onCoolDown;
	public bool inRange;
	public bool canAttack;
	public bool cantSpawn;

	public SpriteRenderer patSprite;

	public GameObject ballOne;
	public GameObject ballTwo;
	public GameObject ballThree;
	public GameObject ballFour;

	public GameObject spiderOne;
	public GameObject spiderTwo;
	public GameObject spiderThree;
	public GameObject spiderFour;

	void Start () {

		animator = GetComponent<Animator> ();
		canAttack = false;
		swing = false;
		inRange = false;
		onCoolDown = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			attacking = thisPlayer.GetComponent<Entity> ();
			loot = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update ()
	{
		if (direction == 0) {
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;	
			weaponSpriteParent.transform.localPosition = forwardPos;
			if (swing == true) {
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, 0);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = forwardPos;
			}
		}
		if (direction == 1) {
			weaponSpriteParent.sortingOrder = 19;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = backPos;
			if (swing == true) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 90);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = backPos;
			}
		}
		if (direction == 2) {
			weaponSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (0, 0, 90);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			if (swing == true) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 125);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
		}
		if (direction == 3) {
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			if (swing == true) {
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, -45);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
		}

		{
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			{
				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
				direction = 1;
				StartCoroutine (stopping());
			}
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance)) 
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			{
				GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
				direction = 0;
				StartCoroutine (stopping());
			} 
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			{ 
				GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
				direction = 3;
				StartCoroutine (stopping());
			}
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (attacking.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			{
				GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
				direction = 2;
				StartCoroutine (stopping());
			}

			/*if (Vector2.Distance (GetComponent<Rigidbody2D>().transform.position, attacking.transform.position) <= distance && canAttack) 
				{
					attackEntity ();
					StartCoroutine (waitForAttack());
				}*/
			if (health <= 0)
				Die ();

			if (direction == 0 && moving == true)
			{
				animator.Play ("WalkDown");
			}
			if (direction == 1 && moving == true)
			{
				animator.Play ("WalkUp");
			}
			if (direction == 2 && moving == true)
			{
				animator.Play ("WalkLeft");
			}
			if (direction == 3 && moving == true)
			{
				animator.Play ("WalkRight");
			}
			if (canAttack == true && inRange == true) {
				attackEntity ();
				canAttack = false;
				StartCoroutine (waitForAttack ());
			}
		}
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = true;
			canAttack = false;
			if (onCoolDown == false) {
				StartCoroutine (waitForAttack ());
				if (cantSpawn == false) {
					StartCoroutine (SpawnSpiders ());
				}
			}
			speed = 0;
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			inRange = false;
			canAttack = false;
			StopCoroutine (waitForAttack ());
			StartCoroutine (speedUp ());
		}
	}
	IEnumerator speedUp()
	{
		yield return new WaitForSeconds (1f);
		if (inRange == false) {
			speed = 4;
		}
	}
	IEnumerator waitForAttack()
	{
		onCoolDown = true;
		canAttack = false;
		yield return new WaitForSeconds (1.5f);
		if (inRange == true) {
			canAttack = true;
			StartCoroutine (attackEntity ());
		}
		onCoolDown = false;

	}

	public void Die()
	{
		print ("Enemy Slain");
		int add = Random.Range (15, 30);
		loot.addMoney (add);
		Destroy (gameObject);
	}

	IEnumerator attackEntity()
	{
		if (canAttack == true) {
			StartCoroutine (Swinging ());
			if (direction == 0) {
				ballOne.transform.position = patSprite.transform.position;
				ballOne.SetActive (true);
				yield return new WaitForSeconds (1.25f);
				ballOne.SetActive (false);
				canAttack = false;
			}

			if (direction == 1) {
				ballTwo.transform.position = patSprite.transform.position;
				ballTwo.SetActive (true);
				yield return new WaitForSeconds (1.25f);
				ballTwo.SetActive (false);
				canAttack = false;
				}

			if (direction == 2) {
				ballThree.transform.position = patSprite.transform.position;
				ballThree.SetActive (true);
				yield return new WaitForSeconds (1.25f);
				ballThree.SetActive (false);
				canAttack = false;
				}

			if (direction == 3) {
				ballFour.transform.position = patSprite.transform.position;
				ballFour.SetActive (true);
				yield return new WaitForSeconds (1.25f);
				ballFour.SetActive (false);
				canAttack = false;
			}




		}
	}
	IEnumerator SpawnSpiders()
	{
		cantSpawn = true;
	yield return new WaitForSeconds (1f);
		spiderOne.transform.position = new Vector3(patSprite.transform.position.x + 1, patSprite.transform.position.y);
	spiderOne.SetActive (true);
	yield return new WaitForSeconds (1f);
		spiderTwo.transform.position = new Vector3(patSprite.transform.position.x - 1, patSprite.transform.position.y);
	spiderTwo.SetActive (true);
	yield return new WaitForSeconds (1f);
		spiderThree.transform.position = new Vector3(patSprite.transform.position.x, patSprite.transform.position.y + 1);
	spiderThree.SetActive (true);
	yield return new WaitForSeconds (1f);
		spiderFour.transform.position = new Vector3(patSprite.transform.position.x, patSprite.transform.position.y - 1);
	spiderFour.SetActive (true);
	}
	IEnumerator Swinging()
	{
		swing = true;
		yield return new WaitForSeconds (.3f);
		swing = false;
	}

	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
}

