﻿using UnityEngine;
using System.Collections;

public class CutSceneThreeNPC: Entity {

	public GameObject thisPlayer;

	public Entity player;
	public float distance;

	public Entity thisNpc;

	void Start () 
	{

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		} 
		animator = GetComponent<Animator> ();
	}

	void Update ()
	{
		

			if (player.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - distance)) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
				animator.Play ("WalkUp");
			} 
			else 
			{
				animator.Play ("WalkDown");
			}
		
	}
}

