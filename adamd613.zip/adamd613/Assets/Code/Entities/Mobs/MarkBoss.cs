﻿using UnityEngine;
using System.Collections;

public class MarkBoss: MonoBehaviour {

	public GameObject thisPlayer;

	public Player player;
	public bool swing;

	public bool starting;
	public int stage;
	public int mover;
	public int counter;

	public bool canStage;

	public bool isArmored;

	public GameObject marksSword;
	public MeleeShadowGuard mark;
	public SpriteRenderer markSprite;
	public GameObject thisMark;
	public GameObject markTele;
	public GameObject markZap;
	public BoxCollider2D markCollider;

	public FollowerMob cloneOne;
	public SpriteRenderer cloneOneSprite;
	public GameObject thisCloneOne;
	public GameObject cloneOneTele;
	public GameObject cloneOneZap;
	public FollowerMob cloneTwo;
	public SpriteRenderer cloneTwoSprite;
	public GameObject thisCloneTwo;
	public GameObject cloneTwoTele;
	public GameObject cloneTwoZap;	
	public FollowerMob cloneThree;
	public SpriteRenderer cloneThreeSprite;
	public GameObject thisCloneThree;
	public GameObject cloneThreeTele;
	public GameObject cloneThreeZap;
	public FollowerMob cloneFour;
	public SpriteRenderer cloneFourSprite;
	public GameObject thisCloneFour;
	public GameObject cloneFourTele;
	public GameObject cloneFourZap;

	public bool phaseTwo;

	public int speed;

	public bool moveUpOne;
	public bool moveRightOne;
	public bool moveLeftOne;
	public bool moveDownOne;

	public bool moveUpTwo;
	public bool moveRightTwo;
	public bool moveLeftTwo;
	public bool moveDownTwo;

	public bool moveUpThree;
	public bool moveRightThree;
	public bool moveLeftThree;
	public bool moveDownThree;

	public bool moveUpFour;
	public bool moveRightFour;
	public bool moveLeftFour;
	public bool moveDownFour;

	public bool oneLock;
	public bool twoLock;
	public bool threeLock;
	public bool fourLock;

	public bool allRight;
	public bool allLeft;

	public GameObject bossHealth;

	void Start () {

		isArmored = true;
		swing = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

	
			player.energy = 0;


		if (moveUpOne == true) {
			cloneOne.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			cloneOne.animator.Play ("WalkUp");
		}
		if (moveUpTwo == true) {
			cloneTwo.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			cloneTwo.animator.Play ("WalkUp");
		}
		if (moveUpThree == true) {
			cloneThree.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			cloneThree.animator.Play ("WalkUp");
		}
		if (moveUpFour == true) {
			cloneFour.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			cloneFour.animator.Play ("WalkUp");
		}

		if (moveRightOne == true) {
			cloneOne.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			cloneOne.animator.Play ("WalkRight");
		}	
		if (moveRightTwo == true) {
			cloneTwo.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			cloneTwo.animator.Play ("WalkRight");
		}	
		if (moveRightThree == true) {
			cloneThree.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			cloneThree.animator.Play ("WalkRight");
		}	
		if (moveRightFour == true) {
			cloneFour.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			cloneFour.animator.Play ("WalkRight");
		}	

		if (moveLeftOne == true) {
			cloneOne.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			cloneOne.animator.Play ("WalkLeft");
		}	
		if (moveLeftTwo == true) {
			cloneTwo.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			cloneTwo.animator.Play ("WalkLeft");
		}	
		if (moveLeftThree == true) {
			cloneThree.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			cloneThree.animator.Play ("WalkLeft");
		}	
		if (moveLeftFour == true) {
			cloneFour.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			cloneFour.animator.Play ("WalkLeft");
		}	

		if (moveDownOne == true) {
			cloneOne.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
			cloneOne.animator.Play ("WalkDown");
		}	
		if (moveDownTwo == true) {
			cloneTwo.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
			cloneTwo.animator.Play ("WalkDown");
		}
		if (moveDownThree == true) {
			cloneThree.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
			cloneThree.animator.Play ("WalkDown");
		}
		if (moveDownFour == true) {
			cloneFour.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
			cloneFour.animator.Play ("WalkDown");
		}

		if (oneLock == true) {
			thisCloneOne.transform.position = new Vector3 (thisPlayer.transform.position.x, thisPlayer.transform.position.y + 4, 0);
		}
		if (twoLock == true) {
			thisCloneTwo.transform.position = new Vector3 (thisPlayer.transform.position.x + 4, thisPlayer.transform.position.y, 0);
		}
		if (threeLock == true) {
			thisCloneThree.transform.position = new Vector3 (thisPlayer.transform.position.x, thisPlayer.transform.position.y - 4, 0);
		}
		if (fourLock == true) {
			thisCloneFour.transform.position = new Vector3 (thisPlayer.transform.position.x - 4, thisPlayer.transform.position.y, 0);
		}

		if (allLeft == true) {
			thisCloneOne.transform.position = new Vector3 (thisPlayer.transform.position.x - 2, thisPlayer.transform.position.y + 4, 0);
			thisCloneTwo.transform.position = new Vector3 (thisPlayer.transform.position.x - 2, thisPlayer.transform.position.y + 2,0);
			thisCloneThree.transform.position = new Vector3 (thisPlayer.transform.position.x - 2, thisPlayer.transform.position.y, 0);
			thisCloneFour.transform.position = new Vector3 (thisPlayer.transform.position.x - 2, thisPlayer.transform.position.y - 2, 0);
		}
		if (allRight == true) {
			thisCloneOne.transform.position = new Vector3 (thisPlayer.transform.position.x + 2, thisPlayer.transform.position.y + 2, 0);
			thisCloneTwo.transform.position = new Vector3 (thisPlayer.transform.position.x + 2, thisPlayer.transform.position.y, 0);
			thisCloneThree.transform.position = new Vector3 (thisPlayer.transform.position.x + 2, thisPlayer.transform.position.y - 2, 0);
			thisCloneFour.transform.position = new Vector3 (thisPlayer.transform.position.x + 2, thisPlayer.transform.position.y - 4, 0);
		}

		if (mark.health <= 0)
			Die ();
		if (mark.health <= 400) {
			stage = 0;
			counter = 0;
			starting = true;
			canStage = true;
			mark.distance = 1;
			mark.range = 7;
			marksSword.SetActive (true);
			markZap.SetActive (true);
			markTele.SetActive (false);
			isArmored = false;
		}

		if (player.health <= 0) {
			bossHealth.SetActive (false);
			stage = 0;
			counter = 0;
			starting = true;
			canStage = true;
			mark.distance = 2;
			mark.range = 2;
			marksSword.SetActive (false);
			markZap.SetActive (false);
		}

		if (isArmored == false) {
			mark.armor = 0;
		}
		if (isArmored == true) {
			mark.armor = 100;
		}

		if (starting == false) {
			bossHealth.SetActive (true);
			StartCoroutine (rollDice ());
		}
		if ((stage == 1 || stage == 2 || stage == 3 || stage == 4) && canStage == false) {
			StartCoroutine (Surround ());
		}

		if ((stage == 5 || stage == 6) && canStage == false) {
			StartCoroutine (TheWall ());
		}

	}

	IEnumerator rollDice()
	{
		starting = true;
		yield return new WaitForSeconds (1);
		if (counter < 4) {
			stage = Random.Range (1, 7);
			counter += 1;
		} else 
		{
			StartCoroutine (ShieldsDown ());
		}



	}

	IEnumerator Surround()
	{
		canStage = true;
		oneLock = true;
		twoLock = true;
		threeLock = true;
		fourLock = true;
		thisCloneOne.SetActive (true);
		thisCloneTwo.SetActive (true);
		thisCloneThree.SetActive (true);
		thisCloneFour.SetActive (true);
		cloneOneSprite.enabled = false;
		cloneTwoSprite.enabled = false;
		cloneThreeSprite.enabled = false;
		cloneFourSprite.enabled = false;
		cloneOneTele.SetActive (true);
		cloneTwoTele.SetActive (true);
		cloneThreeTele.SetActive (true);
		cloneFourTele.SetActive (true);
		yield return new WaitForSeconds (.4f);
		cloneOneTele.SetActive (false);
		cloneTwoTele.SetActive (false);
		cloneThreeTele.SetActive (false);
		cloneFourTele.SetActive (false);
		cloneOneSprite.enabled = true;
		cloneTwoSprite.enabled = true;
		cloneThreeSprite.enabled = true;
		cloneFourSprite.enabled = true;
		cloneOne.animator.Play ("WalkDown");
		cloneTwo.animator.Play ("WalkLeft");
		cloneThree.animator.Play ("WalkUp");
		cloneFour.animator.Play ("WalkRight");

		yield return new WaitForSeconds (1);
		if (stage == 1) {
			cloneOneZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneTwoZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneThreeZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneFourZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			moveDownOne = true;
			oneLock = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = true;
			twoLock = false;
			yield return new WaitForSeconds (.5f);
			moveUpThree = true;
			threeLock = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = true;
			fourLock = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = false;
			yield return new WaitForSeconds (.5f);
			moveUpThree = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = false;

		}
		if (stage == 2) {
			cloneTwoZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneFourZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneOneZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneThreeZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = true;
			twoLock = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = true;
			fourLock = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = true;
			oneLock = false;
			yield return new WaitForSeconds (.5f);
			moveUpThree = true;
			threeLock = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = false;
			yield return new WaitForSeconds (.5f);
			moveUpThree = false;

		}
		if (stage == 3) {
			cloneThreeZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneFourZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneTwoZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneOneZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			moveUpThree = true;
			threeLock = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = true;
			fourLock = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = true;
			twoLock = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = true;
			oneLock = false;
			yield return new WaitForSeconds (.5f);
			moveUpThree = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = false;
		}
		if (stage == 4) {
			cloneThreeZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneTwoZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneOneZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneFourZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			moveUpThree = true;
			threeLock = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = true;
			twoLock = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = true;
			oneLock = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = true;
			fourLock = false;
			yield return new WaitForSeconds (.5f);
			moveUpThree = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = false;
			yield return new WaitForSeconds (.5f);
			moveDownOne = false;
			yield return new WaitForSeconds (.5f);
			moveRightFour = false;

		}
	
		stage = 0;
		starting = false;
		canStage = false;
		oneLock = false;
		twoLock = false;
		threeLock = false;
		fourLock = false;
		cloneOneSprite.enabled = false;
		cloneTwoSprite.enabled = false;
		cloneThreeSprite.enabled = false;
		cloneFourSprite.enabled = false;
		cloneOneTele.SetActive (true);
		cloneTwoTele.SetActive (true);
		cloneThreeTele.SetActive (true);
		cloneFourTele.SetActive (true);
		cloneOneZap.SetActive (false);
		cloneTwoZap.SetActive (false);
		cloneThreeZap.SetActive (false);
		cloneFourZap.SetActive (false);
		yield return new WaitForSeconds (.4f);
		cloneOneTele.SetActive (false);
		cloneTwoTele.SetActive (false);
		cloneThreeTele.SetActive (false);
		cloneFourTele.SetActive (false);
		thisCloneOne.SetActive (false);
		thisCloneOne.SetActive (false);
		thisCloneOne.SetActive (false);
		thisCloneOne.SetActive (false);

	}
	IEnumerator TheWall()
	{
		canStage = true;
		if (stage == 5) {
			allRight = true;
		}
		if (stage == 6) {
			allLeft = true;
		}
		thisCloneOne.SetActive (true);
		thisCloneTwo.SetActive (true);
		thisCloneThree.SetActive (true);
		thisCloneFour.SetActive (true);
		cloneOneSprite.enabled = false;
		cloneTwoSprite.enabled = false;
		cloneThreeSprite.enabled = false;
		cloneFourSprite.enabled = false;
		cloneOneTele.SetActive (true);
		cloneTwoTele.SetActive (true);
		cloneThreeTele.SetActive (true);
		cloneFourTele.SetActive (true);
		yield return new WaitForSeconds (.4f);
		cloneOneTele.SetActive (false);
		cloneTwoTele.SetActive (false);
		cloneThreeTele.SetActive (false);
		cloneFourTele.SetActive (false);
		cloneOneSprite.enabled = true;
		cloneTwoSprite.enabled = true;
		cloneThreeSprite.enabled = true;
		cloneFourSprite.enabled = true;


		if (stage == 5) {
			cloneOne.animator.Play ("WalkLeft");
			cloneTwo.animator.Play ("WalkLeft");
			cloneThree.animator.Play ("WalkLeft");
			cloneFour.animator.Play ("WalkLeft");
			cloneOneZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneTwoZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneThreeZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneFourZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			moveLeftOne = true;
			allRight = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = true;
			yield return new WaitForSeconds (.5f);
			moveLeftThree = true;
			yield return new WaitForSeconds (.5f);
			moveLeftFour = true;
			yield return new WaitForSeconds (.5f);
			moveLeftOne = false;
			yield return new WaitForSeconds (.5f);
			moveLeftTwo = false;
			yield return new WaitForSeconds (.5f);
			moveLeftThree = false;
			yield return new WaitForSeconds (.5f);
			moveLeftFour = false;

		}

		if (stage == 6) {
			cloneOne.animator.Play ("WalkRight");
			cloneTwo.animator.Play ("WalkRight");
			cloneThree.animator.Play ("WalkRight");
			cloneFour.animator.Play ("WalkRight");
			cloneFourZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneThreeZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneTwoZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			cloneOneZap.SetActive (true);
			yield return new WaitForSeconds (.5f);
			moveRightFour = true;
			allLeft = false;
			yield return new WaitForSeconds (.5f);
			moveRightThree = true;
			yield return new WaitForSeconds (.5f);
			moveRightTwo = true;
			yield return new WaitForSeconds (.5f);
			moveRightOne = true;
			yield return new WaitForSeconds (.5f);
			moveRightFour = false;
			yield return new WaitForSeconds (.5f);
			moveRightThree = false;
			yield return new WaitForSeconds (.5f);
			moveRightTwo = false;
			yield return new WaitForSeconds (.5f);
			moveRightOne = false;
		}

		yield return new WaitForSeconds (1);
		stage = 0;
		starting = false;
		canStage = false;
		oneLock = false;
		twoLock = false;
		threeLock = false;
		fourLock = false;
		allRight = false;
		allLeft = false;
		cloneOneSprite.enabled = false;
		cloneTwoSprite.enabled = false;
		cloneThreeSprite.enabled = false;
		cloneFourSprite.enabled = false;
		cloneOneTele.SetActive (true);
		cloneTwoTele.SetActive (true);
		cloneThreeTele.SetActive (true);
		cloneFourTele.SetActive (true);
		cloneOneZap.SetActive (false);
		cloneTwoZap.SetActive (false);
		cloneThreeZap.SetActive (false);
		cloneFourZap.SetActive (false);
		yield return new WaitForSeconds (.4f);
		cloneOneTele.SetActive (false);
		cloneTwoTele.SetActive (false);
		cloneThreeTele.SetActive (false);
		cloneFourTele.SetActive (false);
		thisCloneOne.SetActive (false);
		thisCloneOne.SetActive (false);
		thisCloneOne.SetActive (false);
		thisCloneOne.SetActive (false);

	}


	IEnumerator ShieldsDown()
	{
		canStage = true;
		markCollider.enabled = true;
		thisMark.SetActive (true);
		markSprite.enabled = false;
		markTele.SetActive (true);
		yield return new WaitForSeconds (.4f);
		markTele.SetActive (false);
		markSprite.enabled = true;
		isArmored = false;
		mark.animator.Play ("WalkUp");
		yield return new WaitForSeconds (5);
		if (mark.health >= 401) {
			isArmored = true;
			markTele.SetActive (true);
			markSprite.enabled = false;
			markCollider.enabled = false;
			yield return new WaitForSeconds (.4f);
			markTele.SetActive (false);
			markSprite.enabled = false;
			counter = 0;
			stage = 0;
			starting = false;
			canStage = false;

		}
	}

	public void Die()
	{
		mark.enabled = false;
		enabled = false;

	}




}

