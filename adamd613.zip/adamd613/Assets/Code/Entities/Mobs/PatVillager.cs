﻿using UnityEngine;
using System.Collections;

public class PatVillager : Entity {

	public GameObject thisPlayer;
	public Entity running;
	public Entity following;
	public float distance;
	public float range;
	public GameObject teleport;
	public bool runArround;
	public bool runAway;
	public SpriteRenderer Sprite;

	public bool righting;
	public bool lefting;
	public bool upping;
	public bool downing;


	void Start () 
	{
		animator = GetComponent<Animator> ();
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			following = thisPlayer.GetComponent<Entity> ();
		} 
		isHostile = true;
	}

	void Update ()
	{
		maxEnergy = following.maxEnergy;
		energy = following.energy;

		if (energy < maxEnergy && isRunCharming == false && isForceFielding == false && canCharge == true) 
		{
			nowCharging ();
		}

		{
			if (runAway == true) {
				if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range)) {
					GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
					direction = 0;
					StartCoroutine (stopping ());
				}
				if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range)) {
					GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
					direction = 1;
					StartCoroutine (stopping ());
				} 
				if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range)) { 
					GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
					direction = 2;
					StartCoroutine (stopping ());
				}
				if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
				if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range)) {
					GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;
					direction = 3;
					StartCoroutine (stopping ());
				}
			

			}
			if (runArround == true) {

				StartCoroutine (runArrounding ());
			}

			if (upping == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
				direction = 1;
				StartCoroutine (stopping ());
			}
			if (righting == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;
				direction = 3;
				StartCoroutine (stopping ());
			}	
			if (lefting == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
				direction = 2;
				StartCoroutine (stopping ());
			}
			if (downing == true) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
				direction = 0;
				StartCoroutine (stopping ());
			}
			if (direction == 0 && moving == true) {
				animator.Play ("WalkDown");
			}
			if (direction == 1 && moving == true) {
				animator.Play ("WalkUp");
			}
			if (direction == 2 && moving == true) {
				animator.Play ("WalkLeft");
			}
			if (direction == 3 && moving == true) {
				animator.Play ("WalkRight");
			}

			if (health <= 0)
				StartCoroutine (dying ());
		}
	}
	IEnumerator runArrounding()
	{
		runArround = false;
		righting = true;
		yield return new WaitForSeconds (2);
		righting = false;
		downing = true;
		yield return new WaitForSeconds (2);
		downing = false;
		lefting = true;
		yield return new WaitForSeconds (2);
		lefting = false;
		upping = true;
		yield return new WaitForSeconds (2);
		upping = false;
		StartCoroutine (runArrounding ());
	}

	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}	
	IEnumerator dying()
	{
		Sprite.enabled = false;
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		Die ();
	}
	public void Die()
	{
		print ("I've been killed");
		Destroy (gameObject);
	}
}

