﻿using UnityEngine;
using System.Collections;

public class FollowerMob : Entity {

	public GameObject thisPlayer;
	public Entity running;
	public Entity following;
	public float distance;
	public float range;

	void Start () 
	{
		animator = GetComponent<Animator> ();
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			following = thisPlayer.GetComponent<Entity> ();
		} 
	}
				
	void Update ()
	{
		maxEnergy = following.maxEnergy;
		energy = following.energy;

		if (energy < maxEnergy && isRunCharming == false && isForceFielding == false && canCharge == true) 
		{
			nowCharging ();
		}

		{
			if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range)) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
				direction = 1;
				StartCoroutine (stopping ());
			}
			if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range)) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
				direction = 0;
				StartCoroutine (stopping ());
			} 
			if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range)) { 
				GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;
				direction = 3;
				StartCoroutine (stopping ());
			}
			if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x - range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y - range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y + range))
			if (following.GetComponent<Rigidbody2D> ().transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x + range)) {
				GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
				direction = 2;
				StartCoroutine (stopping ());
			}

			if (direction == 0 && moving == true) {
				animator.Play ("WalkDown");
			}
			if (direction == 1 && moving == true) {
				animator.Play ("WalkUp");
			}
			if (direction == 2 && moving == true) {
				animator.Play ("WalkLeft");
			}
			if (direction == 3 && moving == true) {
				animator.Play ("WalkRight");
			}

			if (health <= 0)
				Die ();
		}
	}

	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}	

	public void Die()
	{
		print ("I've been killed");
		Destroy (gameObject);
	}
}

	