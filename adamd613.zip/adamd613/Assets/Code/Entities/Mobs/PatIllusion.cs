﻿using UnityEngine;
using System.Collections;

public class PatIllusion: Entity {

	public GameObject thisPlayer;

	public Player player;
	public float distance;
	public float range;
	public Vector2 forwardPos, backPos, sidePos;
	//public SpriteRenderer weaponSpriteParent;
	public CircleCollider2D DamageCollider2D;

	public bool canAttack;
	public bool canKill;

	public bool isDead;

	public GameObject teleport;
	public SpriteRenderer patSprite;

	public GameObject ballOne;
	public GameObject ballTwo;
	public GameObject ballThree;
	public GameObject ballFour;

	public bool isNeutral;

	void Start () {

		canAttack = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (isHostile == false) {
			armor = 100;
		}
		if (isHostile == true) {
			armor = 0;
		}

		if (health <= 0 && isDead == false)
			StartCoroutine (teleOut ());

		if (direction == 0 && moving == true)
		{
			animator.Play ("WalkDown");
		}
		if (direction == 1 && moving == true)
		{
			animator.Play ("WalkUp");
		}
		if (direction == 2 && moving == true)
		{
			animator.Play ("WalkLeft");
		}
		if (direction == 3 && moving == true)
		{
			animator.Play ("WalkRight");
		}



	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null && canAttack == false)
		{
			StartCoroutine (porting ());
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{

		}
	}	
		

	IEnumerator porting()
	{
		canAttack = true;
		isHostile = false;
		patSprite.enabled = false;
		yield return new WaitForSeconds (1f);
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		if (isNeutral == false) {
			isHostile = true;
		}
		teleport.SetActive (false);
		patSprite.enabled = true;
		if (canKill == true) {
			ballOne.SetActive (true);
			ballTwo.SetActive (true);
			ballThree.SetActive (true);
			ballFour.SetActive (true);
			yield return new WaitForSeconds (3f);
			ballOne.SetActive (false);
			ballTwo.SetActive (false);
			ballThree.SetActive (false);
			ballFour.SetActive (false);
			yield return new WaitForSeconds (.1f);
			ballOne.transform.position = patSprite.transform.position;
			ballTwo.transform.position = patSprite.transform.position;
			ballThree.transform.position = patSprite.transform.position;
			ballFour.transform.position = patSprite.transform.position;
			patSprite.enabled = false;
			teleport.SetActive (true);
			isHostile = false;
			yield return new WaitForSeconds (.4f);
			teleport.SetActive (false);
			canAttack = false;
		}

	}

	IEnumerator teleOut()
	{
		//int add = Random.Range (10, 20);
		//player.addMoney (add);
		isDead = true;
		patSprite.enabled = false;
		teleport.SetActive (true);
		isHostile = false;
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		enabled = false;
		Destroy (gameObject);
	}


}

