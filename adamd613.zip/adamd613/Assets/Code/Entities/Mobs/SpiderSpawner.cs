﻿using UnityEngine;
using System.Collections;

public class SpiderSpawner: Entity {


	public GameObject thisPlayer;

	public Player player;



	void Start () {
		isHostile = true;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update ()
	{
		if (health <= 0)
			Die ();


	}
	public void Die()
	{
		enabled = false;
		Destroy (gameObject);
	}

}

