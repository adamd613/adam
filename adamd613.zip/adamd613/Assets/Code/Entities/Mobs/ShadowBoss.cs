﻿using UnityEngine;
using System.Collections;

public class ShadowBoss: Entity {

	public GameObject thisPlayer;

	public Player player;
	public bool swing;


	public GameObject AttackOne;
	public GameObject AttackTwo;

	public bool starting;
	public int stage;
	public int mover;
	public int counter;

	public bool canStage;
	public bool rotLeft;
	public bool rotRight;
	public bool rotMix;
	public bool rotMixTwo;
	public bool moveY;
	public bool moveX;
	public GameObject shield;

	public GameObject bossHealth;

	public bool isArmored;


	void Start () {

		isArmored = true;
		isHostile = true;
		swing = false;
		shield.SetActive (true);
		AttackOne.SetActive (false);
		AttackTwo.SetActive (false);
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{


		if (health <= 0) {
			Die ();
			bossHealth.SetActive (false);
		}

		if (player.health <= 0) {
			bossHealth.SetActive (false);
		}
		if (isArmored == false) {
			armor = 0;
		}
		if (isArmored == true) {
			armor = 100;
		}

		if (starting == false) {
			bossHealth.SetActive (true);
			StartCoroutine (rollDice ());
		}
		if ((stage == 1 || stage == 2 || stage == 3 || stage == 4 || stage == 5 || stage == 6) && canStage == false) {
			StartCoroutine (LazerShow ());
		}

		if (rotLeft == true) {
			AttackOne.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.forward * 20 * Time.deltaTime);
			AttackTwo.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.forward * 20 * Time.deltaTime);
		}
		if (rotRight == true) {
			AttackOne.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.back * 20 * Time.deltaTime);
			AttackTwo.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.back * 20 * Time.deltaTime);
		}
		if (rotMix == true) {
			AttackOne.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.forward * 20 * Time.deltaTime);
			AttackTwo.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.back * 20 * Time.deltaTime);
		}
		if (rotMixTwo == true) {
			AttackOne.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.back * 20 * Time.deltaTime);
			AttackTwo.GetComponent<Rigidbody2D> ().transform.Rotate(Vector3.forward * 20 * Time.deltaTime);
		}
		if (moveY == true) {
			AttackOne.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;
			AttackTwo.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;
		}
		if (moveX == true) {
			AttackOne.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;
			AttackTwo.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;
		}
	
	}

	IEnumerator rollDice()
	{
		starting = true;
		yield return new WaitForSeconds (1);
		if (counter < 4) {
			stage = Random.Range (1, 7);
			counter += 1;
		} else 
		{
			StartCoroutine (ShieldsDown ());
		}



	}

	IEnumerator LazerShow()
	{
		AttackOne.SetActive (true);
		AttackTwo.SetActive (true);
		canStage = true;
		if (stage == 1) {
			AttackOne.transform.position = new Vector3 (89, 148f, 0);
			AttackTwo.transform.position = new Vector3 (89, 148f, 0);
			AttackOne.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackOne.transform.localRotation = Quaternion.Euler (0, 0, 90);
			AttackTwo.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackTwo.transform.localRotation = Quaternion.Euler (0, 0, 0);
			yield return new WaitForSeconds (2);
			rotLeft = true;
			AttackOne.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			AttackTwo.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			yield return new WaitForSeconds (9f);
			rotLeft = false;
		}
		if (stage == 2) {
			AttackOne.transform.position = new Vector3 (89, 148f, 0);
			AttackTwo.transform.position = new Vector3 (89, 148f, 0);
			AttackOne.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackOne.transform.localRotation = Quaternion.Euler (0, 0, 90);
			AttackTwo.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackTwo.transform.localRotation = Quaternion.Euler (0, 0, 0);
			yield return new WaitForSeconds (2);
			rotRight = true;
			AttackOne.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			AttackTwo.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			yield return new WaitForSeconds (9f);
			rotRight = false;
		}
		if (stage == 3) {
			AttackOne.transform.position = new Vector3 (89, 148f, 0);
			AttackTwo.transform.position = new Vector3 (89, 148f, 0);
			AttackOne.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackOne.transform.localRotation = Quaternion.Euler (0, 0, 90);
			AttackTwo.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackTwo.transform.localRotation = Quaternion.Euler (0, 0, 0);
			yield return new WaitForSeconds (2);
			rotMix = true;
			AttackOne.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			AttackTwo.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			yield return new WaitForSeconds (9f);
			rotMix = false;
		}
		if (stage == 4) {
			AttackOne.transform.position = new Vector3 (89, 148f, 0);
			AttackTwo.transform.position = new Vector3 (89, 148f, 0);
			AttackOne.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackOne.transform.localRotation = Quaternion.Euler (0, 0, 0);
			AttackTwo.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackTwo.transform.localRotation = Quaternion.Euler (0, 0, 0);
			yield return new WaitForSeconds (2);
			moveY = true;
			AttackOne.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			AttackTwo.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			yield return new WaitForSeconds (6f);
			moveY = false;
		}
		if (stage == 5) {
			AttackOne.transform.position = new Vector3 (89, 148f, 0);
			AttackTwo.transform.position = new Vector3 (89, 148f, 0);
			AttackOne.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackOne.transform.localRotation = Quaternion.Euler (0, 0, 90);
			AttackTwo.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackTwo.transform.localRotation = Quaternion.Euler (0, 0, 90);
			yield return new WaitForSeconds (2);
			moveX = true;
			AttackOne.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			AttackTwo.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			yield return new WaitForSeconds (6f);
			moveX = false;
		}
		if (stage == 6) {
			AttackOne.transform.position = new Vector3 (89, 148f, 0);
			AttackTwo.transform.position = new Vector3 (89, 148f, 0);
			AttackOne.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackOne.transform.localRotation = Quaternion.Euler (0, 0, 90);
			AttackTwo.transform.localScale = new Vector3 (.4f, 1.6f, 0);
			AttackTwo.transform.localRotation = Quaternion.Euler (0, 0, 0);
			yield return new WaitForSeconds (2);
			rotMixTwo = true;
			AttackOne.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			AttackTwo.transform.localScale = new Vector3 (1.6f, 1.6f, 0);
			yield return new WaitForSeconds (9f);
			rotMixTwo = false;
		}
		yield return new WaitForSeconds (1);
		AttackOne.SetActive (false);
		AttackTwo.SetActive (false);
		stage = 0;
		starting = false;
		canStage = false;
	
	}



	IEnumerator ShieldsDown()
	{
		canStage = true;
		shield.SetActive (false);
		isArmored = false;
		yield return new WaitForSeconds (7);
		shield.SetActive (true);
		isArmored = true;
		counter = 0;
		stage = 0;
		starting = false;
		canStage = false;
	}

	public void Die()
	{
		int add = Random.Range (100, 200);
		player.maxHealth += 25;
		player.addMoney (add);
		Dead ();
	}
	public void Dead()
	{
		enabled = false;
		Destroy (gameObject);
	}

}

