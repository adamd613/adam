﻿using UnityEngine;
using System.Collections;

public class FollowerDoor : MonoBehaviour {

	public GameObject thisFollower;
	public MarkHUD markHUD;
	public GameObject thisPlayer;
	public Player player;

	public float newX;
	public float newY;

	public bool outsideDoor;
	public House house;

	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	
	}
	

	void Update () 
	{
		
		if (player.progPoint == 11) {
			markHUD.enabled = false;
		}

	}
	void OnTriggerEnter2D(Collider2D c)
	{
		Entity e = c.GetComponent<Player> ();
		if (e != null) 
		{
			if (outsideDoor) {
				house.GotoRoom (e);
				thisFollower.transform.position = new Vector3(newX,newY,0);
			}
			else
			house.LeaveHouse (e);

		}
	}

}
