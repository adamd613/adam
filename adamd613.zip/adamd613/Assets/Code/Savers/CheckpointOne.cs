﻿using UnityEngine;
using System.Collections;

public class CheckpointOne : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public int levelPT;

	void Start () {
	
	}

	void Update () {

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.levelPoint = levelPT;
		}
	}
}
