﻿using UnityEngine;
using System.Collections;

public class LevelFour : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;
	public HUDController HUD;
	public BoxCollider2D thisCollider;
	public GUISkin guiSKIN;
	public bool blackout;

	public bool SceneSix;

	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			HUD = thisPlayer.GetComponent<HUDController> ();
		}

	}

	void Update () 
	{

	}
	void OnGUI()
	{
		GUI.skin = guiSKIN;
		if (blackout == true) {
			GUI.Box (new Rect (0, 0, Screen.width, Screen.height), "", "Menu");
		}
	}
	void loadLevel() 
	{
		blackout = true;
		player.levelPoint = 9;
		HUD.enabled = true;
		Application.LoadLevel("Level Four");
		if (SceneSix == false) {
			player.transform.position = new Vector3 (49.5f, 146, 0);
		} 
		if (SceneSix == true) 
		{
			player.transform.position = new Vector3 (106.5f, 139, 0);
		}
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null) {
			loadLevel ();
			HUD.ClearAll ();
		}
	}
}