﻿using UnityEngine;
using System.Collections;

public class LevelTwo : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;
	public HUDController HUD;
	public BoxCollider2D thisCollider;

	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			HUD = thisPlayer.GetComponent<HUDController> ();
		}

	}

	void Update () 
	{

	}

	void loadLevel() 
	{
		player.levelPoint = 2;
		HUD.enabled = true;
		player.transform.position = new Vector3(15, 28, 0);
		Application.LoadLevel("Level Two");
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null) {
			loadLevel ();
			HUD.ClearAll ();
		}
	}
}