﻿using UnityEngine;
using System.Collections;

public class LevelFive : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;
	public HUDController HUD;
	public BoxCollider2D thisCollider;
	public GUISkin guiSKIN;
	public bool blackout;

	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			HUD = thisPlayer.GetComponent<HUDController> ();
		}

	}

	void Update () 
	{
		
	}
	void OnGUI()
	{
		GUI.skin = guiSKIN;
		if (blackout == true) {
			GUI.Box (new Rect (0, 0, Screen.width, Screen.height), "", "Menu");
		}
	}

	void loadLevel() 
	{
		blackout = true;
		player.levelPoint = 10;
		HUD.enabled = true;
		Application.LoadLevel("Level Five");
		player.transform.position = new Vector3(16, 27, 0);
	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null) {
			loadLevel ();
			HUD.ClearAll ();
		}
	}
}