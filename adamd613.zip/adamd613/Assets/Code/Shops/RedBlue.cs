﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RedBlue : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public GameObject holding;

	public BoxCollider2D SaveCollider;

	public GameObject RedCard;
	public GameObject BlueCard;

	public bool playerInRange;
	public bool isInInventory;
	public bool isShopOpen;

	public OrderedDialogue winText;
	public OrderedDialogue lossText;
	public OrderedDialogue MainText;

	public bool showWarn;
	public string warn;
	public GUISkin gskin;

	void Start () 
	{
		playerInRange = false;
		isShopOpen = false;
		isInInventory = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if (holding == null) {
			holding = GameObject.FindGameObjectWithTag ("Holding");
		}
	}

	void Update () 
	{
		if(playerInRange)
		{
			if(Input.GetKeyDown(KeyCode.E))
				isShopOpen = !isShopOpen;
			if(Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
				isInInventory = !isInInventory;
			if (isShopOpen == true) 
			{
				holding.SetActive (false);
			}
			if (isShopOpen == false) 
			{
				holding.SetActive (true);
			}
		}
	}

	void OnTriggerEnter2D(Collider2D c)
	{
		if(c.tag == "Player" && playerInRange == false)
		{
			playerInRange = true;
			player = c.GetComponent<Player>();
		}
	}

	void OnTriggerExit2D(Collider2D c)
	{
		if(c.tag == "Player" && playerInRange)
		{
			playerInRange = false;
			player = null;
			isShopOpen = false;
			holding.SetActive (true);
			showWarn = false;
		}
	}


	void OnGUI()
	{
		GUI.skin = gskin;
		if (!isInInventory) 
		{


			if (playerInRange && !isShopOpen) 
			{
				GUI.color = new Color(15.0f, 0.0f, 0.0f);
				GUI.Label (new Rect (5, 5, 500, 100), "Press e to open the Game." );
			}

			if (isShopOpen) 
			{
				GUILayout.BeginArea (new Rect ((Screen.width / 2) - 250, 100, 500, Screen.height - 200), GUIContent.none, "box");
				GUILayout.BeginVertical ();
				GUILayout.BeginHorizontal (GUILayout.Width (500));
				GUILayout.Label ("Do you want to Play 'Red/Blue' Costs : $50?");
				GUILayout.Space (20);
				GUILayout.EndHorizontal ();
				GUILayout.BeginHorizontal (GUILayout.Width (500));

				if (GUILayout.Button ("Yes")) 
				{
					if (player.money >= 50) {
						player.money = (player.money - 50);
						StartCoroutine (PlayGame ());

					} else {
						showWarn = true;
					}

				}

				GUILayout.Space (20);

				if (GUILayout.Button ("no")) 
				{
					isShopOpen = !isShopOpen;
					showWarn = false;
				}

				GUILayout.Space (20);

				GUILayout.EndHorizontal ();

				GUILayout.EndVertical ();

				GUILayout.EndArea ();
			}

			if (showWarn && isShopOpen == true) {
				GUI.Box (new Rect (Screen.width / 2 - 250, 20, 500, 60), warn);
			}
		}
	}
	IEnumerator waitForWarning(string warning)
	{
		warn = warning;
		showWarn = true;
		yield return new WaitForSeconds(5);
		showWarn = false;
	}
	IEnumerator PlayGame()
	{
		holding.SetActive (false);
		isShopOpen = false;
		player.enabled = false;
		playerInRange = false;
		MainText.enabled = false;
		yield return new WaitForSeconds(1);
		RedCard.SetActive (true);
		yield return new WaitForSeconds(.5f);
		RedCard.SetActive (false);
		BlueCard.SetActive (true);
		yield return new WaitForSeconds(.5f);
		BlueCard.SetActive (false);
		RedCard.SetActive (true);
		yield return new WaitForSeconds(.5f);
		RedCard.SetActive (false);
		BlueCard.SetActive (true);
		yield return new WaitForSeconds(.5f);
		BlueCard.SetActive (false);
		RedCard.SetActive (true);
		yield return new WaitForSeconds(.5f);
		RedCard.SetActive (false);
		BlueCard.SetActive (true);
		yield return new WaitForSeconds(.5f);
		BlueCard.SetActive (false);
		int card = Random.Range (1, 3);
		if (card == 1) {
			RedCard.SetActive (true);
			winText.enabled = true;
			player.money = player.money + 100;

		} else if (card == 2) {
			BlueCard.SetActive (true);
			lossText.enabled = true;
		}
		yield return new WaitForSeconds(3f);
		RedCard.SetActive (false);
		BlueCard.SetActive (false);
		winText.enabled = false;
		lossText.enabled = false;
		player.enabled = true;
		MainText.enabled = true;
		isShopOpen = true;
		holding.SetActive (true);
		playerInRange = true;
	}
}
