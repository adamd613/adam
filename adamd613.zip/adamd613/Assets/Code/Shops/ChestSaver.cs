﻿using UnityEngine;
using System.Collections;

public class ChestSaver : MonoBehaviour {

	public GameObject thisPlayer;

	public Player player;

	public ChestShop chestOne;
	public ChestShop chestTwo;
	public ChestShop chestThree;
	public ChestShop chestFour;
	public ChestShop chestFive;
	public ChestShop chestSix;
	public ChestShop chestSeven;
	public ChestShop chestEight;
	public ChestShop chestNine;
	public ChestShop chestTen;
	public ChestShop chestEleven;
	public ChestShop chestTwelve;
	public ChestShop chestThirteen;
	public ChestShop chestFourteen;
	public ChestShop chestFifteen;
	public ChestShop chestSixteen;
	public ChestShop chestSeventeen;
	public ChestShop chestEighteen;
	public ChestShop chestNineteen;
	public ChestShop chestTwenty;

	public GameObject thisChestOne;
	public GameObject thisChestTwo;
	public GameObject thisChestThree;
	public GameObject thisChestFour;
	public GameObject thisChestFive;
	public GameObject thisChestSix;
	public GameObject thisChestSeven;
	public GameObject thisChestEight;
	public GameObject thisChestNine;
	public GameObject thisChestTen;
	public GameObject thischestEleven;
	public GameObject thisChestTwelve;
	public GameObject thisChestThirteen;
	public GameObject thisChestFourteen;
	public GameObject thisChestFifteen;
	public GameObject thisChestSixteen;
	public GameObject thisChestSeventeen;
	public GameObject thisChestEighteen;
	public GameObject thisChestNineteen;
	public GameObject thisChestTwenty;


	public static ChestSaver control;

	void Awake() 
	{
		if (control == null) {
			DontDestroyOnLoad (gameObject);
			control = this;
		} else if (control != this) {
			Destroy (gameObject);
		}

	}


	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}
	

	void Update () 

	{
		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		player = thisPlayer.GetComponent<Player> ();

		if (player.resetChests == false) {
			if ((player.levelPoint >= 2 && player.levelPoint <= 4) || (player.levelPoint >= 7 && player.levelPoint <= 9)) {
				thisChestOne.SetActive (true);
				thisChestTwo.SetActive (true);
				thisChestThree.SetActive (true);
				thisChestFive.SetActive (true);
				thisChestSix.SetActive (true);
				thisChestSeven.SetActive (true);
				thisChestEight.SetActive (true);
				thisChestNine.SetActive (true);
				thisChestSixteen.SetActive (true);
				thisChestSeventeen.SetActive (true);
				thisChestEighteen.SetActive (true);
			} else {
				thisChestOne.SetActive (false);
				thisChestTwo.SetActive (false);
				thisChestThree.SetActive (false);
				thisChestFive.SetActive (false);
				thisChestSix.SetActive (false);
				thisChestSeven.SetActive (false);
				thisChestEight.SetActive (false);
				thisChestNine.SetActive (false);
				thisChestSixteen.SetActive (false);
				thisChestSeventeen.SetActive (false);

				thisChestEighteen.SetActive (false);
			}	
			if (player.levelPoint >= 5 && player.levelPoint <= 6) {
				thisChestFour.SetActive (true);

			} else {
				thisChestFour.SetActive (false);

			}	

			if (player.levelPoint >= 10 && player.levelPoint <= 13) {
				thisChestTen.SetActive (true);
				thischestEleven.SetActive (true);
				thisChestTwelve.SetActive (true);
				thisChestNineteen.SetActive (true);
			} else {
				thisChestTen.SetActive (false);
				thischestEleven.SetActive (false);
				thisChestTwelve.SetActive (false);
				thisChestNineteen.SetActive (false);
			}	
			if (player.levelPoint >= 14 && player.levelPoint <= 17) {
				thisChestThirteen.SetActive (true);
				thisChestFourteen.SetActive (true);
				thisChestFifteen.SetActive (true);
			}
			else {
				thisChestFifteen.SetActive (false);
				thisChestThirteen.SetActive (false);
				thisChestFourteen.SetActive (false);
			}	
				
			thisChestTwenty.SetActive (false);

			}
		if (player.resetChests == true) {
			thisChestOne.SetActive (true);
			thisChestTwo.SetActive (true);
			thisChestThree.SetActive (true);
			thisChestFour.SetActive (true);
			thisChestFive.SetActive (true);
			thisChestSix.SetActive (true);
			thisChestSeven.SetActive (true);
			thisChestEight.SetActive (true);
			thisChestNine.SetActive (true);
			thisChestTen.SetActive (true);
			thischestEleven.SetActive (true);
			thisChestTwelve.SetActive (true);
			thisChestThirteen.SetActive (true);
			thisChestFourteen.SetActive (true);
			thisChestFifteen.SetActive (true);
			thisChestSixteen.SetActive (true);
			thisChestSeventeen.SetActive (true);
			thisChestEighteen.SetActive (true);
			thisChestNineteen.SetActive (true);
			thisChestTwenty.SetActive (true);
		}

	}
}
