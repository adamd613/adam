﻿using UnityEngine;
using System.Collections;

public class BossHealth : MonoBehaviour {
	
	public Texture healthbar;
	public Texture healthbarOuter;
	public float percentage;
	public float bossMaxHealth;

	public SpiderBoss spider;
	public ShadowBoss shadow;
	public MeleeShadowGuard mark;
	public LoganBoss loganTwo;
	public AttackingPat pat;
	public AttackingLogan loganOne;

	public Player player;
	public GameObject thisPlayer;

	public bool isSpider;
	public bool isShadow;
	public bool isMark;
	public bool isLoganOne;
	public bool isPat;
	public bool isLoganTwo;

	public bool playerIsHere;


	public GUISkin guiSKIN;

	void Start () {

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update () {
		if (isSpider == true) {
			bossMaxHealth = spider.maxHealth;
			percentage = Mathf.Clamp (spider.health * (250 / spider.maxHealth), 0, 250);
			if (spider.health <= 0)
				playerIsHere = false;
		}
		if (isShadow == true) {
			bossMaxHealth = shadow.maxHealth;
			percentage = Mathf.Clamp (shadow.health * (250 / shadow.maxHealth), 0, 250);
			if (shadow.health <= 0)
				playerIsHere = false;
		}
		if (isMark == true) {
			bossMaxHealth = mark.maxHealth;
			percentage = Mathf.Clamp (mark.health * (250 / mark.maxHealth), 0, 250);
			if (mark.health <= 0)
				playerIsHere = false;
		}
		if (isLoganOne == true) {
			bossMaxHealth = loganOne.maxHealth;
			percentage = Mathf.Clamp (loganOne.health * (250 / loganOne.maxHealth), 0, 250);
			if (loganOne.health <= 0)
				playerIsHere = false;
		}
		if (isPat == true) {
			bossMaxHealth = pat.maxHealth;
			percentage = Mathf.Clamp (pat.health * (250 / pat.maxHealth), 0, 250);
			if (pat.health <= 0)
				playerIsHere = false;
		}
		if (isLoganTwo == true) {
			bossMaxHealth = loganTwo.maxHealth;
			percentage = Mathf.Clamp (loganTwo.health * (250 / loganTwo.maxHealth), 0, 250);
			if (loganTwo.health <= 0)
				playerIsHere = false;
		}

		if (player.health <= 0)
			playerIsHere = false;
	}

	void OnGUI()
	{
		GUI.skin = guiSKIN;
		health ();
	}
	void health()
	{
		if (playerIsHere == true && player.HUD.isInInventory == false) {
			GUI.Label (new Rect (20, 5, 320, 100), "  Boss Health:");
			GUI.DrawTexture (new Rect (55, 75, percentage, 60), healthbar);
			GUI.DrawTexture (new Rect (20, 55, 320, 100), healthbarOuter);

			if (isSpider == true)
				GUI.Label (new Rect (140, 55, 320, 100), spider.health.ToString () + "/" + spider.maxHealth.ToString ());
			if (isShadow == true)
				GUI.Label (new Rect (140, 55, 320, 100), shadow.health.ToString () + "/" + shadow.maxHealth.ToString ());
			if (isMark == true)
				GUI.Label (new Rect (140, 55, 320, 100), mark.health.ToString () + "/" + mark.maxHealth.ToString ());
			if (isLoganOne == true)
				GUI.Label (new Rect (140, 55, 320, 100), loganOne.health.ToString () + "/" + loganOne.maxHealth.ToString ());
			if (isPat == true)
				GUI.Label (new Rect (140, 55, 320, 100), pat.health.ToString () + "/" + pat.maxHealth.ToString ());
			if (isLoganTwo == true)
				GUI.Label (new Rect (140, 55, 320, 100), loganTwo.health.ToString () + "/" + loganTwo.maxHealth.ToString ());
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			if (player.health >= 1)
				playerIsHere = true;

		}
	}
	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
				playerIsHere = false;
		}
	}
}
