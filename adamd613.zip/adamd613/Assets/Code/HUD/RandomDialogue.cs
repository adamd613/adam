﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class RandomDialogue : MonoBehaviour {

	private bool showingDialogue;

	public Level levelManager;

	private string dialogueMessage;
	public List<Dialogue> dialogueMessages = new List<Dialogue>();

	public bool isInInventory;

	public GUISkin skinn;

	void Start () 
	{
		levelManager = GameObject.FindGameObjectWithTag("levelManager").GetComponent<Level>();
		isInInventory = false;
	}

	void Update () 
	{
		if(Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
			isInInventory = !isInInventory;

		if(showingDialogue)
		{
			if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetMouseButtonDown (1))
				GenerateDialogue();
		}
	}

	void OnGUI()
	{
		GUI.skin = skinn;
		GUI.depth = 0;
		if (!isInInventory) 
		{
			if (showingDialogue) {
				GUI.Box (new Rect (Screen.width - 650, Screen.height - 120, Screen.width - 130, 100), dialogueMessage, "Dialogue");
				GUI.Label (new Rect (Screen.width - 440, Screen.height - 190, 500, 100), "(Right Click/Enter) for Next.");
			}
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null && showingDialogue == false)
		{
			GenerateDialogue();
			showingDialogue = true;
		}
	}

	public void GenerateDialogue()
	{
		int random = Random.Range(0, dialogueMessages.Count - 1);
		dialogueMessage = dialogueMessages[random].dialogue;
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			showingDialogue = false;
		}
	}
}
	
[System.Serializable]
public class Dialogue
{
	public string dialogue;
}