﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class OrderedDialogue : MonoBehaviour {

	private bool showingDialogue;

	public Level levelManager;

	public int textNum;

	public bool isInInventory;

	private string dialogueMessage;

	public List<Dialogue> dialogueMessages = new List<Dialogue>();

	public GUISkin skinn;



	void Start () 
	{
		levelManager = GameObject.FindGameObjectWithTag("levelManager").GetComponent<Level>();
		isInInventory = false;

	}

	void Update () 
	{
		if(Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
			isInInventory = !isInInventory;
		if(showingDialogue)
		{
			if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetMouseButtonDown (1))
				textNum += 1;
			
			if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetMouseButtonDown (1))
			GenerateDialogue();
		}
		else
		{
			textNum = 0;
		}
	}

	void OnGUI()
	{
		GUI.skin = skinn;
		GUI.depth = 0;
		if (!isInInventory) {
			if (showingDialogue) {
				GUI.Box (new Rect (Screen.width - 650, Screen.height - 120, Screen.width - 130, 100), dialogueMessage, "Dialogue");

				if (textNum >= dialogueMessages.Count -1) {
					GUI.Label (new Rect (Screen.width - 215, Screen.height - 190, 500, 100), "End of Text.");
				}
				if (dialogueMessages.Count >= 2) 
					{
						if (textNum < dialogueMessages.Count -1) {
							GUI.Label (new Rect (Screen.width - 440, Screen.height - 190, 500, 100), "(Right Click/Enter) for Next.");
						}
					}

			}
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null && showingDialogue == false)
		{
			GenerateDialogue();
			showingDialogue = true;
		}
	}

	public void GenerateDialogue()
	{
		dialogueMessage = dialogueMessages[textNum].dialogue;
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			showingDialogue = false;
		}
	}
}

