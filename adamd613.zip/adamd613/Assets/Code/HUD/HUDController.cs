﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class HUDController : MonoBehaviour {

	public Player thisplayer;

	public Texture healthbar;
	public Texture healthbarOuter;
	public Texture coin;
	public Texture energyIcon;

	public bool isInInventory = false;

	public float percentage;
	public float myMaxHealth;

	public GUISkin guiSKIN;

	public int currentlySelected;
	public int maxSelected;

	//public Item itemRunningCharm;
	public Poison itemPoison;
	public Sword itemIronSword;
	public Potion itemPotion;
	public GameObject thisPoison;
	public PoisonDamage itemPoisonDamage;
	public BoStaff itemBoStaff;
	public Pistol itemPistol;
	public Key itemKey;
	public Saber itemSaber;
	public EnergyPot itemEnergyPot;

	public bool cantPause;

	public RunningCharm abilityRunning;
	public ForceField abilityForceField;
	public Incorporeal abilityIncorpreal;

	public GameObject holding;

	public GameObject thisPlayer;
	public Player player;


	void Start () {
		currentlySelected = 1;
		myMaxHealth = thisplayer.maxHealth;
		if (thisPlayer == null) 
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		}
		if(thisPoison == null)
		{
			thisPoison = GameObject.FindGameObjectWithTag ("PoisonDamage");
			itemPoisonDamage = thisPoison.GetComponent<PoisonDamage> ();
		} 
		if (holding == null) {
			holding = GameObject.FindGameObjectWithTag ("Holding");
		}

	}

	void Update () {
		percentage = Mathf.Clamp(thisplayer.health * (250/thisplayer.maxHealth), 0, 250);

		if(Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
			isInInventory = !isInInventory;

		if(isInInventory && cantPause == false)
			Time.timeScale = 0.0f;
		else
			Time.timeScale = 1.0f;
		if (isInInventory == true) {
			if (Input.GetKeyDown (KeyCode.S) || Input.GetKeyDown (KeyCode.DownArrow)) {
				if (maxSelected > 1) {
					if (currentlySelected == maxSelected) {
						currentlySelected = 1;
					} else {
						currentlySelected++;
					}
				}
			}
			if (Input.GetKeyDown (KeyCode.W) || Input.GetKeyDown (KeyCode.UpArrow)) {
				if (maxSelected > 1) {
					if (currentlySelected == 1) {
						currentlySelected = maxSelected;
					} else {
						currentlySelected--;
					}
				}
			}
		}
	}

	void OnGUI()
	{
		GUI.skin = guiSKIN;
		if(!isInInventory)
		{
			health ();
			money ();
			energy ();
			equipped ();
			abilities ();
			if(player.enabled == true && player.progPoint != 13)
			holding.SetActive (true);
		
		}

		if (isInInventory) {
			Inventory ();
			if(player.enabled == true && player.progPoint != 13)
			holding.SetActive (false);
		}
	
	}

	void energy()
	{
		GUI.DrawTexture(new Rect(320, Screen.height - 120, 60, 60), energyIcon);
		GUI.Label(new Rect(390, Screen.height - 120, 200, 60), thisplayer.energy.ToString());
	}

	void health()
	{
		GUI.Label(new Rect(20, Screen.height - 180, 320, 100), "  (R/Esc) for inventory");
		GUI.DrawTexture(new Rect(55, Screen.height - 100, percentage, 60), healthbar);
		GUI.DrawTexture(new Rect(20, Screen.height - 120, 320, 100), healthbarOuter);
		GUI.Label(new Rect(140, Screen.height - 120, 320, 100), thisplayer.health.ToString() + "/" + thisplayer.maxHealth.ToString());
	}

	void equipped()
	{
		
		GUI.Label(new Rect(Screen.width - 440, 25, 200, 60), "(Click/Shift):");
		GUI.Label(new Rect(Screen.width - 440, 55, 200, 60), "(Space Bar):");


		if(itemBoStaff.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemBoStaff.itemName);
		}
		if(itemPoison.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemPoison.itemName);
		}
		if(itemPotion.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemPotion.itemName);
		}
		if(itemIronSword.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemIronSword.itemName);
		}
		if(itemPistol.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemPistol.itemName);
		}
		if(itemKey.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemKey.itemName);
		}
		if(itemSaber.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemSaber.itemName);
		}
		if(itemEnergyPot.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 25, 400, 60), itemEnergyPot.itemName);
		}

			
	}

	void abilities()
	{
		

		if(abilityRunning.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 55, 200, 60), abilityRunning.itemName);
		}
		if(abilityForceField.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 55, 200, 60), abilityForceField.itemName);
		}
		if(abilityIncorpreal.isEquip == true)
		{
			GUI.color = new Color(15.0f, 0.0f, 0.0f);
			GUI.Label(new Rect(Screen.width - 260, 55, 200, 60), abilityIncorpreal.itemName);
		}


	}

	void money()
	{
		GUI.DrawTexture(new Rect(320, Screen.height - 80, 60, 60), coin);
		GUI.Label(new Rect(390, Screen.height - 80, 200, 60), thisplayer.money.ToString());
	}
	public void ClearAll ()
	{
		itemBoStaff.enemyInRange.Clear();
		itemIronSword.enemyInRange.Clear();
		itemPistol.enemyInRange.Clear();
		itemPoisonDamage.enemyInRange.Clear();
		itemSaber.enemyInRange.Clear();
		itemKey.doorInRange.Clear();
	}


	void Inventory()
	{
		GUI.Box (new Rect(0, 0, Screen.width, Screen.height), "", "invbg");
		GUI.Box (new Rect(Screen.width-((Screen.width/100f)*50f), 0, ((Screen.width/100f)*50f), ((Screen.height/100f)*75f)), "", "item-box");
		GUI.Box (new Rect(0, Screen.height-((Screen.height/100f)*25f), Screen.width, ((Screen.height/100f)*25f)), "", "info-box");

		List<inventory> playerInv = thisplayer.ipManager.items;


		maxSelected = playerInv.Count;
		GUILayout.BeginVertical ();
		GUILayout.Space (32.5f);
		GUILayout.EndVertical ();
		for(int i = 1; i < playerInv.Count+1; i++)
		{	
			GUI.color = new Color(0.0f, 0.0f, 0.0f);
			GUILayout.BeginHorizontal (GUILayout.Width (30));
			GUILayout.Space ((Screen.width / 2));
	
			if (GUILayout.Button ("Equip")) {
				if(playerInv[i - 1].item.equipped == "Equipped")
				{
					itemPoison.UnEquipAll ();
					itemPotion.UnEquipAll ();
					itemIronSword.UnEquipAll ();
					itemBoStaff.UnEquipAll ();
					itemPistol.UnEquipAll ();
					itemKey.UnEquipAll ();
					itemSaber.UnEquipAll ();
					itemEnergyPot.UnEquipAll ();
				}
				if(playerInv[i - 1].item.equipped == "Using")
				{
					abilityForceField.UnEquipAll ();
					abilityRunning.UnEquipAll ();
					abilityIncorpreal.UnEquipAll ();

				}
				currentlySelected = i;
				playerInv [i - 1].item.Equip();
				playerInv [i - 1].item.isEquip = true;

		
			//	GUI.Label(new Rect(20, Screen.height-((Screen.height/100f)*25f)+ 20, 1000, 30), playerInv[i-1].item.itemDescription);
			}

			GUILayout.EndHorizontal ();
			GUILayout.BeginVertical ();
			GUILayout.Space (1);
			GUILayout.EndVertical ();
		

			if(i == currentlySelected)
			{
				if (playerInv [i - 1].item.isEquip == true) 
				{
					GUI.color = new Color (15.0f, 0.0f, 0.0f);
					GUI.Label (new Rect (240, Screen.height - ((Screen.height / 100f) * 25f) + 50, 500, 30), playerInv [i - 1].item.equipped);
				}

				GUI.color = new Color(15.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*50f)+60, (i*32), 500, 30), playerInv[i-1].item.itemName + " x " + playerInv[i-1].amountOfItem);

				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(20, Screen.height-((Screen.height/100f)*25f)+ 20, 1000, 30), playerInv[i-1].item.itemDescription);

				GUI.color = new Color(150.0f, 0.0f, 150.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*100f)+10, 20, 500, 30), "[Item Screen]");

				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*100f)+10, 60, 500, 30), "Use 'W' and 'S' to select items.");

				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*100f)+10, 100, 500, 30), "'E' to Equip, 'Q' to Unequip.");

				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*100f)+10, 140, 500, 30), "Or click the 'Equip' button to Equip.");

				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*100f)+10, 180, 500, 30), "L Click or Shift to use equipped items.");

				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*100f)+10, 220, 500, 30), "Press 'esc' to exit inventory.");

				GUI.color = new Color (0.0f, 0.0f, 0.0f);
				GUI.Label (new Rect (20, Screen.height - ((Screen.height / 100f) * 25f) + 50, 500, 30), "Currently Held:");


				if(Input.GetKeyDown(KeyCode.E))
				{
					if(playerInv[i - 1].item.equipped == "Equipped")
					{
						itemPoison.UnEquipAll ();
						itemPotion.UnEquipAll ();
						itemIronSword.UnEquipAll ();
						itemBoStaff.UnEquipAll ();
						itemPistol.UnEquipAll ();
						itemKey.UnEquipAll ();
						itemSaber.UnEquipAll ();
						itemEnergyPot.UnEquipAll ();
					}
					if(playerInv[i - 1].item.equipped == "Using")
					{
						abilityForceField.UnEquipAll ();
						abilityRunning.UnEquipAll ();
						abilityIncorpreal.UnEquipAll ();

					}

					playerInv [i - 1].item.Equip();

				}

					
			
				if (Input.GetKeyDown (KeyCode.Q)) 
				{
					playerInv [i - 1].item.UnEquip();
				}
			}
			else
			{
				GUI.color = new Color(0.0f, 0.0f, 0.0f);
				GUI.Label(new Rect(Screen.width-((Screen.width/100f)*50f)+50, (i*32), 500, 30), playerInv[i-1].item.itemName + " x " + playerInv[i-1].amountOfItem);
			}

		}
	}
}
