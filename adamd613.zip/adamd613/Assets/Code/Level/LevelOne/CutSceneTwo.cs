﻿using UnityEngine;
using System.Collections;

public class CutSceneTwo: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public Entity player;
	public EndingDialogue dialogue;
	public GameObject oldCamera;
	public GameObject newCamera;
	public GameObject holding;


	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
			newCamera = GameObject.FindGameObjectWithTag ("newCamera");
			oldCamera = GameObject.FindGameObjectWithTag ("MainCamera");
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{
		if (dialogue.textNum >= 6) 
		{
			holding.SetActive (true);
			oldCamera.transform.position = newCamera.transform.position;
			player.enabled = true;
			levelManager.GetComponent<AudioSource> ().UnPause();
			dialogue.toggleOff ();
			cutScene.SetActive (false);

		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.GetComponent<Player> () != null) {
			player.enabled = false;
			AudioSource trapMusic = GetComponent<AudioSource> ();
			holding.SetActive (false);
			trapMusic.Play ();
			levelManager.GetComponent<AudioSource> ().Pause ();

			oldCamera.transform.position = new Vector3 (88, 43, -15);
		}
	}
}

