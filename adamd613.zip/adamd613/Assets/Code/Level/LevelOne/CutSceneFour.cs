﻿using UnityEngine;
using System.Collections;

public class CutSceneFour: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public FollowerMob follower;
	public GameObject followerThree;
	public GameObject followerTwo;
	public Entity player;
	public EndingDialogue dialogue;
	public GameObject associatedItem;
	public GameObject holding;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{
		if (dialogue.textNum >= 7) 
		{
			player.enabled = true;
			levelManager.GetComponent<AudioSource> ().UnPause();
			follower.speed += 2;
			follower.range -= 4;
			dialogue.toggleOff ();
			cutScene.SetActive (false);
			associatedItem.SetActive (true);
			holding.SetActive (true);

		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			holding.SetActive (false);
			followerThree.SetActive (true);
			followerTwo.SetActive (false);
			player.enabled = false;
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
}

