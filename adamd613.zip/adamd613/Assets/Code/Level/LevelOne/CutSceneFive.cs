﻿using UnityEngine;
using System.Collections;

public class CutSceneFive: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject followerThree;
	public FollowerMob followerDude;
	public GameObject followerFour;
	public Entity player;
	public EndingDialogue dialogue;
	public GameObject holding;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{
		if (dialogue.textNum >= 4) 
		{
			dialogue.toggleOff ();
			StartCoroutine (PeaceOut ());
			followerDude.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 6 * Time.deltaTime;	
			followerDude.animator.Play ("WalkRight");



		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			holding.SetActive (false);

			player.enabled = false;
			followerThree.transform.position = new Vector3(thisPlayer.transform.position.x + 2,thisPlayer.transform.position.y);
			followerDude.distance = 2;
			followerDude.range = 2;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator PeaceOut()
	{
		yield return new WaitForSeconds (4f);
		player.enabled = true;
		levelManager.GetComponent<AudioSource> ().UnPause();
		cutScene.SetActive (false);
		holding.SetActive (true);
		followerThree.SetActive (false);
		followerFour.SetActive (true);
	}
}

