﻿using UnityEngine;
using System.Collections;

public class CutSceneNineteen: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;
	public GameObject thisDia;

	public Collider2D thisCollider;

	public GUISkin guiSKIN;
	public HUDController HUD;

	public int thisProg;
	public int nextProg;
	public int textTrigger;
	public bool righting;
	public bool upping;

	public bool blackout;



	void Start () 
	{

		cutScene = gameObject;

		equipment = GameObject.FindGameObjectWithTag ("Equipment");
		holding = GameObject.FindGameObjectWithTag ("Holding");


		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{
		HUD = thisPlayer.GetComponent<HUDController> ();

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}
		if (player.health <= 0) {
			Destroy (thisPlayer);
			player.HUD.enabled = false;
			player.levelPoint = 0;
			Application.LoadLevel ("Menu");
			player.health = player.maxHealth;
			player.energy = player.maxEnergy;
			player.playerDead = false;
			player.speed = 4;
		}
			
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;

			player.shadowsOn = false;
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
			StartCoroutine (nextLevel ());

		}
	}
	void OnGUI()
	{
		GUI.skin = guiSKIN;
		if (blackout == true) {
			GUI.Box (new Rect (0, 0, Screen.width, Screen.height), "", "Menu");
		}
	}

	IEnumerator nextLevel()
	{
		blackout = true;
		HUD.ClearAll ();

	//	player.levelPoint = 7;
		//AudioSource trapMusic = GetComponent<AudioSource>();	
		//trapMusic.Stop();
		AudioSource boSmack = GetComponent<AudioSource>();	
		boSmack.Play();
		yield return new WaitForSeconds (2.5f);
		thisDia.SetActive (true);
		yield return new WaitForSeconds (2.5f);
		holding.SetActive (true);
		equipment.SetActive (true);
		player.speed = 4;
		player.progPoint = nextProg;
		player.enabled = true;
		player.transform.position = new Vector3(-227.3f, 52, 0);	
		Application.LoadLevel("Level Four");

	}
}



