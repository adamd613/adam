﻿using UnityEngine;
using System.Collections;

public class CutSceneEighteen: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisMark;
	public FollowerMob mark;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public GameObject teleport;
	public SpriteRenderer mainSprite;
	public GameObject upSprite;
	public GameObject downSprite;
	public GameObject spider;

	public bool resetMark;
	public bool left;
	public bool right;

	public int thisProg;
	public int nextProg;
	public int textTrigger;
	public bool righting;
	public bool upping;

	public bool shadowsOn;
	public bool canEnd;


	void Start () 
	{

		cutScene = gameObject;

		equipment = GameObject.FindGameObjectWithTag ("Equipment");
		holding = GameObject.FindGameObjectWithTag ("Holding");


		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisMark.GetComponent<FollowerMob> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if (player.progPoint == thisProg ) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}
		if (righting == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 4 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
		if (upping == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			player.animator.Play ("WalkUp");
		}

	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			if (resetMark == true && left == false && right == false) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x,thisPlayer.transform.position.y - 3);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && left == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x - 3,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && right == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x + 3,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
			StartCoroutine (goRight ());

		}
	}
	IEnumerator goRight()
	{
		righting = true;
		holding.SetActive (false);
		equipment.SetActive (false);
		yield return new WaitForSeconds(.5f);
		righting = false;
	}
	IEnumerator ending()
	{
		canEnd = true;
		player.shadowsOn = true;
		mainSprite.enabled = false;
		upSprite.SetActive (false);
		downSprite.SetActive (false);
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		spider.SetActive (true);

		yield return new WaitForSeconds(1f);
		player.enabled = true;
		player.speed = 1;
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}



