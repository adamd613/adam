﻿using UnityEngine;
using System.Collections;

public class SpiderBossManager: MonoBehaviour {

	public GameObject cutScene;

	public GameObject thisLogan;
	public FollowerMob logan;

	public GameObject thisJOB;
	public FollowerMob JOB;

	public GameObject thisWarrar;
	public GameObject thisChira;
	public GameObject thisKaren;
	public FollowerMob karen;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public BoxCollider2D topStair;

	public SpriteRenderer BossBody;
	public GameObject spiderBossLocation;
	public GameObject ScareFace;
	public GameObject AttackAnim;
	public SpiderBoss spiderBoss;

	public GameObject JOBSecondDia;
	public GameObject KarenSecondDia;
	public OrderedDialogue JOBDia;
	public OrderedDialogue KarenDia;
	public GameObject Crystal;
	public GameObject Chest;

	public GameObject thisDetector;
	public PlayerDetector detector;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool endNow;
	public bool canEnd;
	public bool canLaunch;

	public bool JOBdown;
	public bool canMoveJOB;

	public Transform launchTarget;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}

		if (player.progPoint >= 21) 
		{

			JOBDia.enabled = false;
			JOB.animator.Play ("WalkRight");
			thisJOB.transform.position = new Vector3 (-228.69f, 25.20f, 0);
			KarenDia.enabled = false;
			karen.animator.Play ("WalkUp");
			thisKaren.transform.position = new Vector3 (-238.31f, 22.59f, 0);
			JOBSecondDia.SetActive (true);
			KarenSecondDia.SetActive (true);
			Crystal.SetActive (false);


		}
		if (player.progPoint >= 22) 
		{
			thisLogan.transform.position = new Vector3 (200, 200, 0);
		}
		if (player.progPoint >= 32) 
		{
			thisWarrar.SetActive (true);
		}
		if (player.progPoint >= 37) {
			thisChira.SetActive (true);
		}


		if (dialogue.textNum >= textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}

		if (player.health <= 0) {
			StartCoroutine (resetBoss ());
		}
		if (spiderBoss.health <= 0 && canMoveJOB == false) 
		{	
			thisDetector.SetActive (true);
			thisJOB.transform.position = new Vector3 (157.5f, 156, 0);
			thisJOB.GetComponent<Rigidbody2D> ().isKinematic = true;
			if (endNow == false && detector.playerHere == true) {
				JOB.animator.Play ("WalkDown");
				canMoveJOB = true;
				endNow = true;
				dialogue.enabled = true;
				player.enabled = false;
				holding.SetActive (false);
			}

		}

		if (JOBdown == true) 
		{
			JOB.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			JOB.animator.Play ("WalkDown");
		}


		if (canLaunch == true) {
			spiderBossLocation.transform.position = Vector3.MoveTowards(spiderBossLocation.transform.position, launchTarget.position, 4 * Time.deltaTime);
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			spiderBoss.enabled = true;
			spiderBossLocation.SetActive (true);
			spiderBossLocation.transform.position = new Vector3 (156.1f,154.5f, 0);
		}
	}

	IEnumerator resetBoss()
	{
		spiderBossLocation.transform.position = new Vector3 (156.1f,154.5f, 0);
		spiderBoss.health = spiderBoss.maxHealth;
		yield return new WaitForSeconds(.01f);
		spiderBoss.enabled = false;
		yield return new WaitForSeconds(.01f);
		spiderBossLocation.SetActive (false);
	}



	IEnumerator ending()
	{
		canEnd = true;
		JOBdown = true;
		dialogue.enabled = false;
		yield return new WaitForSeconds(2f);
		Chest.SetActive (true);
		topStair.enabled = true;
		JOBdown = false;
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);

	}
}


