﻿using UnityEngine;
using System.Collections;

public class CutSceneTwentyTwo: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisLogan;
	public FollowerMob logan;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;


	public int thisProg;
	public int nextProg;
	public int textTrigger;



	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}
		if (player.progPoint == 17 || player.progPoint == 18) 
		{
			logan.range = 5;
			logan.distance = 2;
			thisLogan.GetComponent<Rigidbody2D> ().isKinematic = false;

		}


		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;

		}
	}


	IEnumerator ending()
	{
		
		yield return new WaitForSeconds(.5f);
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);

	}
}


