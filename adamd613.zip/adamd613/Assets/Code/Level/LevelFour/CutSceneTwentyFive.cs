﻿using UnityEngine;
using System.Collections;

public class CutSceneTwentyFive: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisLogan;
	public FollowerMob logan;

	public GameObject thisJOB;
	public FollowerMob JOB;

	public GameObject thisKaren;
	public FollowerMob karen;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public BoxCollider2D topStair;
	public BoxCollider2D JOBcollider;
	public CircleCollider2D JOBtextCollider;

	public SpriteRenderer BossBody;
	public GameObject spiderBossLocation;
	public GameObject ScareFace;
	public GameObject AttackAnim;
	public SpiderBoss spiderBoss;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool moveLeft;
	public bool JOBleft;
	public bool JOBdown;
	public bool moveRight;

	public bool cantMove;
	public bool canEnd;
	public bool endNow;

	public bool canLaunch;

	public GameObject crystal;
	public Transform launchTarget;
	public GameObject music;


	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}
		if (player.progPoint == 20) 
		{
			thisJOB.GetComponent<Rigidbody2D> ().isKinematic = true;
			thisJOB.transform.position = new Vector3 (149,200, 0);

			thisKaren.GetComponent<Rigidbody2D> ().isKinematic = true;
			thisKaren.transform.position = new Vector3 (151, 200, 0);

			thisLogan.GetComponent<Rigidbody2D> ().isKinematic = true;
			thisLogan.transform.position = new Vector3 (153, 200, 0);

			topStair.enabled = false;
			crystal.SetActive (false);
		}



		if (dialogue.textNum >= textTrigger && endNow == false) 
		{
			StartCoroutine (ending ());
		}

		if (moveLeft == true) 
		{
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkLeft");
			karen.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			karen.animator.Play ("WalkLeft");
			JOB.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			JOB.animator.Play ("WalkLeft");
		}
		if (JOBleft == true) 
		{
			JOB.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			JOB.animator.Play ("WalkLeft");
		}
		if (JOBdown == true) 
		{
			JOB.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			JOB.animator.Play ("WalkDown");
		}
		if (moveRight == true) 
		{
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 4 * Time.deltaTime;	
			logan.animator.Play ("WalkRight");
			karen.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 4 * Time.deltaTime;	
			karen.animator.Play ("WalkRight");
	
		}

		if ((dialogue.textNum == 4 || dialogue.textNum == 5 ||dialogue.textNum == 6) && cantMove == false) 
		{

			StartCoroutine (JOBmovesUp ());
		}
		if (Input.GetKeyDown (KeyCode.Return) || Input.GetKeyDown (KeyCode.KeypadEnter) || Input.GetMouseButtonDown (1)) {
			cantMove = false;
		}

		if ((dialogue.textNum == 7) && canEnd == false) 
		{
			StartCoroutine (SummonBoss ());
		}
		if (canLaunch == true) {
			spiderBossLocation.transform.position = Vector3.MoveTowards(spiderBossLocation.transform.position, launchTarget.position, 4 * Time.deltaTime);
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			thisKaren.transform.position = new Vector3 (156,150.5f, 0);
			thisJOB.transform.position = new Vector3 (156, 147.5f, 0);
			thisLogan.transform.position = new Vector3 (156, 149, 0);
			logan.range = 2;
			logan.distance = 2;
			topStair.enabled = false;
			JOBcollider.enabled = false;
			JOBtextCollider.enabled = false;
			music.GetComponent<AudioSource> ().Pause();
			StartCoroutine (startScene ());

		}
	}

	IEnumerator SummonBoss()
	{
		dialogue.enabled = false;
		canEnd = true;
		spiderBossLocation.SetActive (true);
		BossBody.enabled = false;
		spiderBossLocation.transform.position = new Vector3 (142,148, 0);
		AttackAnim.SetActive (true);
		yield return new WaitForSeconds(1.25f);
		dialogue.enabled = true;
	}
	IEnumerator JOBmovesUp()
	{
		dialogue.enabled = false;
		cantMove = true;
		JOBleft = true;
		yield return new WaitForSeconds(1.25f);
		dialogue.enabled = true;
		JOBleft = false;
		cantMove = true;
	}

	IEnumerator startScene()
	{
		moveLeft = true;
		yield return new WaitForSeconds(2f);
		moveLeft = false;
		dialogue.enabled = true;
	}

	IEnumerator ending()
	{
		endNow = true;
		moveRight = true;
		yield return new WaitForSeconds(1.25f);
		moveRight = false;
		thisKaren.GetComponent<Rigidbody2D> ().isKinematic = true;
		thisKaren.transform.position = new Vector3 (151, 200, 0);
		thisLogan.GetComponent<Rigidbody2D> ().isKinematic = true;
		thisLogan.transform.position = new Vector3 (153, 200, 0);
		ScareFace.SetActive (true);
		crystal.SetActive (false);
		yield return new WaitForSeconds(1f);
		AttackAnim.SetActive (false);
		yield return new WaitForSeconds(1f);
		dialogue.enabled = false;
		BossBody.enabled = true;
		canLaunch = true;
		ScareFace.SetActive (false);
		thisJOB.transform.position = new Vector3 (149,200, 0);
		yield return new WaitForSeconds(4f);
		music.GetComponent<AudioSource> ().Play();
		canLaunch = false;
		dialogue.enabled = false;
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);

	}
}


