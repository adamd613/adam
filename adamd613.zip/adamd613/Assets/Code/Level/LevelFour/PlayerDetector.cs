﻿using UnityEngine;
using System.Collections;

public class PlayerDetector : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;
	public bool playerHere;

	void Start () {


		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update () {
	
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			playerHere = true;
		}
	}
	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			playerHere = false;
		}
	}

}
