﻿using UnityEngine;
using System.Collections;

public class CutSceneTwentySeven: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisLogan;
	public FollowerMob logan;
	public GameObject loganCharm;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;


	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool LoganDown;
	public bool LoganRight;
	public bool cantEnd;

	public bool toggleMusic;

	public GameObject sea;

	public GameObject bridge;


	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (player.progPoint == thisProg ) 
		{
			
			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg ) 
		{

			cutScene.SetActive (false);

		}
			
		if (player.progPoint >= 22 ) 
		{
			sea.SetActive(false);
			bridge.SetActive(true);	
		}

		if ((dialogue.textNum == 3 || dialogue.textNum == 10 )&& toggleMusic == false) {
			levelManager.GetComponent<AudioSource> ().Pause ();
			toggleMusic = true;
		}
		else if ((dialogue.textNum == 6 || dialogue.textNum == 11)&& toggleMusic == true) {
			levelManager.GetComponent<AudioSource> ().Play ();
			toggleMusic = false;
		}
		if (dialogue.textNum >= textTrigger && cantEnd == false) 
		{
			StartCoroutine (ending ());
		}

		if (LoganDown == true) 
		{
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkDown");
		}
		if (LoganRight == true) 
		{
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkRight");
		}

	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			logan.range = 20;
			logan.speed = 2;
			thisLogan.transform.position = new Vector3 (83, 58, 0);
			loganCharm.SetActive (false);
			thisLogan.GetComponent<BoxCollider2D> ().enabled = false;
		}
	}


	IEnumerator ending()
	{
		cantEnd = true;
		player.ipManager.addToItemInventory (9, 1);
		logan.range = 2;
		LoganRight = true;
		yield return new WaitForSeconds(.75f);
		LoganRight = false;
		LoganDown = true;
		yield return new WaitForSeconds(6f);
		LoganDown = false;
		thisLogan.transform.position = new Vector3 (200, 200, 0);
		loganCharm.SetActive (true);
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		thisLogan.GetComponent<BoxCollider2D> ().enabled = true;
		nextScene.SetActive (true);
	
	}
}


