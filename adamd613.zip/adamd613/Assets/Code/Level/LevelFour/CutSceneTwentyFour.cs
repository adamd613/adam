﻿using UnityEngine;
using System.Collections;

public class CutSceneTwentyFour: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisLogan;
	public FollowerMob logan;

	//public GameObject thisJOB;
	public FollowerMob JOB;

	//public GameObject thisKaren;
	public FollowerMob karen;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;


	public int thisProg;
	public int nextProg;
	public int textTrigger;



	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}
		if (player.progPoint == 19) 
		{

			thisLogan.GetComponent<Rigidbody2D> ().isKinematic = true;
			thisLogan.transform.position = new Vector3 (149, 69, 0);


		}


		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}

		if (dialogue.textNum == 3) 
		{
			JOB.animator.Play ("WalkDown");
		}

		if (dialogue.textNum == 4) 
		{
			karen.animator.Play ("WalkDown");
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			thisLogan.transform.position = new Vector3 (154, 69, 0);
			logan.range = 8;
			logan.distance = 2;
			dialogue.enabled = true;

		}
	}


	IEnumerator ending()
	{
		logan.animator.Play ("WalkDown");
		logan.range = 2;
		logan.distance = 2;
		yield return new WaitForSeconds(.5f);
		dialogue.enabled = false;
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);

	}
}


