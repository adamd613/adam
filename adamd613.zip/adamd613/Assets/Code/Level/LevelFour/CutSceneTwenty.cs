﻿using UnityEngine;
using System.Collections;

public class CutSceneTwenty: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisNPC;
	public FollowerMob NPC;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public bool resetMark;
	public bool walkDown;
	public bool lefting;

	public int thisProg;
	public int nextProg;
	public int textTrigger;



	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}
		if (player.progPoint >= 15 && player.progPoint <= 18 ) {
			thisNPC.transform.position = new Vector3 (84, 52, 0);
			NPC.distance = 2;
			NPC.range = 2;
		}


		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}

		if (dialogue.textNum >= 5 && lefting == false) 
		{
			levelManager.GetComponent<AudioSource> ().Pause();
			StartCoroutine (turnLeft ());
		}
		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}

		if (walkDown == true) {
			NPC.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			NPC.animator.Play ("WalkDown");
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.levelPoint = 7;

			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator turnLeft()
	{
		lefting = true;
		yield return new WaitForSeconds(.1f);
		NPC.animator.Play ("WalkLeft");
	}

	IEnumerator ending()
	{

		walkDown = true;
		yield return new WaitForSeconds(1f);
		thisNPC.transform.position = new Vector3(84,52,0);
		NPC.distance = 2;
		NPC.range = 2;
		levelManager.GetComponent<AudioSource> ().Play();
		walkDown = false;
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


