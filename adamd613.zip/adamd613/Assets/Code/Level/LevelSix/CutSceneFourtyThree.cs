﻿using UnityEngine;
using System.Collections;

public class CutSceneFourtyThree: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;
	private bool PlayerWalkLeft;

	public GameObject nextScene;

	public SpriteRenderer playerSprite;
	public SpriteRenderer foSprite;
	public EndingDialogue dialogue;
	public EndingDialogue dialogueTwo;
	public EndingDialogue dialogueThree;
	public EndingDialogue dialogueFour;
	public EndingDialogue dialogueFive;
	public EndingDialogue dialogueSix;
	public EndingDialogue dialogueSeven;
	public EndingDialogue dialogueEight;
	public EndingDialogue dialogueNine;
	public EndingDialogue dialogueTen;
	public EndingDialogue dialogueEleven;
	public GameObject credits;
	public SpriteRenderer creditSprites;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	private bool cantReset;
	private bool canEnd;
	private bool canEndOne;
	private bool canEndTwo;
	private bool canEndThree;
	private bool canEndFour;
	private bool canEndFive;
	private bool canEndSix;
	private bool canEndSeven;
	private bool canEndEight;
	private bool canEndNine;
	private bool canEndTen;
	private bool canEndEleven;
	//	private bool canEndTwelve;

	public bool markFade;
	public bool patFade;
	public bool loganFade;

	public GameObject fences;

	public bool blackout;
	public GUISkin guiSKIN;
	public bool sceneActive;


	public GameObject thisfoPlayer;
	public FollowerMob foPlayer;

	public GameObject thisMark;
	public FollowerMob mark;

	public GameObject thisYider;
	public FollowerMob yider;

	public GameObject thisChira;
	public FollowerMob chira;

	public GameObject thisWarrar;
	public FollowerMob warrar;

	public GameObject thisJOB;
	public FollowerMob JOB;

	public GameObject thisKaren;
	public FollowerMob karen;

	private bool foWalkLeft;
	private bool YiderWalkRight;
	private bool YiderWalkLeft;
	private bool ChiraWalkRight;
	private bool ChiraWalkLeft;
	private bool WarrarWalkRight;
	private bool WarrarWalkLeft;
	private bool JOBWalkRight;
	private bool JOBWalkLeft;
	private bool KarenWalkRight;
	private bool KarenWalkLeft;

	public SpriteRenderer loganSprite;
	public GameObject thisLogan;
	public FollowerMob logan;
	public GameObject thisPat;
	public FollowerMob pat;
	public bool PatWalkUp;

	private bool LoganWalkRight;
	private bool LoganWalkDown;
	private bool MarkUp;
	public GameObject teleport;
	public SpriteRenderer patSprite;

	public SpriteRenderer markSprite;
	public GameObject tele;

	public Camera playerCamera;
	public GameObject theCamera;

	public bool canTele;

	public float fadeAmount;

	public bool creditsFade;

	public GameObject stone;

	public bool steadyCam;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");
		theCamera = GameObject.FindGameObjectWithTag ("MainCamera");
		playerCamera = theCamera.GetComponent<Camera> ();
		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			playerSprite = thisPlayer.GetComponent<SpriteRenderer> ();
		} 
	
	
	}

	void Update ()
	{
		

		if (player.progPoint == thisProg) 
		{
			if (canTele == false) {
				StartCoroutine (teleIn ());
			}
			cutScene.SetActive (true);
			fences.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (markFade == true) {
	
			markSprite.color = new Color (1f, 1f, 1f, fadeAmount);
		}
		if (patFade == true) {

			patSprite.color = new Color (1f, 1f, 1f, fadeAmount);
		}
		if (loganFade == true) {

			loganSprite.color = new Color (1f, 1f, 1f, fadeAmount);
		}
		if (creditsFade == true) {

			creditSprites.color = new Color (1f, 1f, 1f, fadeAmount);
		}
		if ( LoganWalkRight == true) {
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkRight");
		}
		if ( LoganWalkDown == true) {
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 1 * Time.deltaTime;	
			logan.animator.Play ("WalkDown");
		}
		if (PatWalkUp == true) {
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 1 * Time.deltaTime;	
			pat.animator.Play ("WalkUp");
		}
		if ( YiderWalkRight == true) {
			yider.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			yider.animator.Play ("WalkRight");
		}
		if ( YiderWalkLeft == true) {
			yider.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			yider.animator.Play ("WalkLeft");
		}
		if ( foWalkLeft == true) {
			foPlayer.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			foPlayer.animator.Play ("WalkLeft");
		}
		if ( ChiraWalkRight == true) {
			chira.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			chira.animator.Play ("WalkRight");
		}
		if ( ChiraWalkLeft == true) {
			chira.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			chira.animator.Play ("WalkLeft");
		}
		if (WarrarWalkRight == true) {
			warrar.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			warrar.animator.Play ("WalkRight");
		}
		if (WarrarWalkLeft == true) {
			warrar.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			warrar.animator.Play ("WalkLeft");
		}
		if (JOBWalkRight == true) {
			JOB.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			JOB.animator.Play ("WalkRight");
		}
		if (JOBWalkLeft == true) {
			JOB.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			JOB.animator.Play ("WalkLeft");
		}
		if (KarenWalkRight == true) {
			karen.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			karen.animator.Play ("WalkRight");
		}
		if (KarenWalkLeft == true) {
			karen.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			karen.animator.Play ("WalkLeft");
		}
		if (PlayerWalkLeft == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			player.animator.Play ("WalkLeft");
		}
		if (dialogue.textNum >= 3 && canEndOne == false) 
		{
			StartCoroutine (endingOne ());
		}

		if (dialogueTwo.textNum >= 7 && canEndTwo == false) 
		{
			StartCoroutine (endingTwo ());
		}
		if (dialogueThree.textNum >= 1 && canEndThree == false) 
		{
			StartCoroutine (endingThree ());
		}
		if (dialogueFour.textNum >= 3 && canEndFour == false) 
		{
			StartCoroutine (endingFour ());
		}
		if (dialogueFive.textNum >= 3 && canEndFive == false) 
		{
			StartCoroutine (endingFive ());
		}
		if (dialogueSix.textNum >= 4 && canEndSix == false) 
		{
			StartCoroutine (endingSix ());
		}
		if (dialogueSeven.textNum >= 3 && canEndSeven == false) 
		{
			StartCoroutine (endingSeven ());
		}
		if (dialogueEight.textNum >= 3 && canEndEight == false) 
		{
			StartCoroutine (endingEight());
		}
		if (dialogueNine.textNum >= 12 && canEndNine == false) 
		{
			StartCoroutine (endingNine());
		}
		if (dialogueTen.textNum >= 2 && canEndTen == false) 
		{
			StartCoroutine (endingTen());
		}
		if (dialogueEleven.textNum >= 1 && canEndEleven == false) 
		{
			StartCoroutine (endingEleven());
		}
	}
	void OnGUI()
	{
		GUI.skin = guiSKIN;
		if (blackout == true) {
			GUI.Box (new Rect (0, 0, Screen.width, Screen.height), "", "Menu");
		}
	}
	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
		
			StartCoroutine (enter ());
			player.enabled = false;
			levelManager.GetComponent<AudioSource> ().Pause();
			//StartCoroutine (ending ());
		}
	}

	IEnumerator enter()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);

		yield return new WaitForSeconds(2f);
	// 	AudioSource trapMusic = GetComponent<AudioSource>();

		//trapMusic.Play();
		//dialogue.enabled = true;
	}	
	IEnumerator endingOne()
	{
		canEndOne = true;
		dialogue.enabled = false;
		player.animator.Play ("WalkLeft");
		yield return new WaitForSeconds(1f);
		player.animator.Play ("WalkRight");
		yield return new WaitForSeconds(1f);
		player.animator.Play ("WalkUp");
		yield return new WaitForSeconds(1f);
		dialogueTwo.enabled = true;
	}

	IEnumerator endingTwo()
	{
		canEndTwo = true;
		dialogueTwo.enabled = false;
		markFade = true;
		StartCoroutine (fadeOut());
		yield return new WaitForSeconds(2f);
		markFade = false;
		yield return new WaitForSeconds(2f);
		blackout = true;
		player.transform.position = new Vector3(thisMark.transform.position.x, thisMark.transform.position.y, 0);	
		player.transform.localRotation = Quaternion.Euler (0, 0, -90);
		playerCamera.transform.localRotation = Quaternion.Euler (0, 0, 90);
		player.animator.Play ("WalkLeft");
		AudioSource boSmack = GetComponent<AudioSource>();	
		boSmack.Play();
		stone.SetActive (false);
		yield return new WaitForSeconds(4f);
		blackout = false;
		yield return new WaitForSeconds(4f);
		thisLogan.SetActive (true);
		LoganWalkRight = true;
		yield return new WaitForSeconds(3.5f);
		LoganWalkRight = false;
		dialogueThree.enabled = true;
	}
	IEnumerator endingThree()
	{
		canEndThree = true;
		dialogueThree.enabled = false;
		thisPat.SetActive (true);
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		patSprite.enabled = true;
		yield return new WaitForSeconds (1f);
		dialogueFour.enabled = true;
	}
	IEnumerator endingFour()
	{
		canEndFour = true;
		dialogueFour.enabled = false;
		thisJOB.SetActive (true);
		thisKaren.SetActive (true);
		JOBWalkRight = true;
		KarenWalkRight = true;
		yield return new WaitForSeconds(4.5f);
		JOBWalkRight = false;
		KarenWalkRight = false;
		dialogueFive.enabled = true;
	}
	IEnumerator endingFive()
	{
		canEndFive = true;
		dialogueFive.enabled = false;
		thisChira.SetActive (true);
		ChiraWalkRight = true;
		yield return new WaitForSeconds(4.5f);
		ChiraWalkRight = false;
		dialogueSix.enabled = true;
	}
	IEnumerator endingSix()
	{
		canEndSix = true;
		dialogueSix.enabled = false;
		thisWarrar.SetActive (true);
		WarrarWalkRight = true;
		yield return new WaitForSeconds(4.5f);
		WarrarWalkRight = false;
		dialogueSeven.enabled = true;
	}
	IEnumerator endingSeven()
	{
		canEndSeven = true;
		dialogueSeven.enabled = false;
		thisYider.SetActive (true);
		YiderWalkRight = true;
		yield return new WaitForSeconds(4.5f);
		YiderWalkRight = false;
		dialogueEight.enabled = true;
	}

	IEnumerator endingEight()
	{
		canEndEight = true;
		dialogueEight.enabled = false;
		player.transform.localRotation = Quaternion.Euler (0, 0, 0);
		playerCamera.transform.localRotation = Quaternion.Euler (0, 0, 0);
		yield return new WaitForSeconds(2);
		player.animator.Play ("WalkDown");
		yield return new WaitForSeconds(2);
		player.animator.Play ("WalkLeft");
		dialogueNine.enabled = true;
	}
	IEnumerator endingNine()
	{
		canEndNine = true;
		dialogueNine.enabled = false;
		yield return new WaitForSeconds(2);
		logan.animator.Play ("WalkLeft");
		pat.animator.Play ("WalkRight");
		yield return new WaitForSeconds(2);
		pat.animator.Play ("WalkLeft");
		logan.animator.Play ("WalkRight");
		yield return new WaitForSeconds(2);
		pat.animator.Play ("WalkUp");
		logan.animator.Play ("WalkDown");
		yield return new WaitForSeconds(2);
		dialogueTen.enabled = true;
	}
	IEnumerator endingTen()
	{
		canEndTen = true;
		dialogueTen.enabled = false;
		yield return new WaitForSeconds(2);
		PatWalkUp = true;
		LoganWalkDown = true;
		loganFade = true;
		patFade = true;
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3);
		thisLogan.SetActive (false);
		thisPat.SetActive (false);
		dialogueEleven.enabled = true;

	}
	IEnumerator endingEleven()
	{
		canEndEleven = true;
		dialogueEleven.enabled = false;
		yield return new WaitForSeconds(2);
		playerSprite.enabled = false;
		foSprite.enabled = true;
		foWalkLeft = true;
		yield return new WaitForSeconds(4);
		JOBWalkLeft = true;
		KarenWalkLeft = true;
		yield return new WaitForSeconds(2);
		ChiraWalkLeft = true;
		yield return new WaitForSeconds(2);
		WarrarWalkLeft = true;
		yield return new WaitForSeconds(2);
		YiderWalkLeft = true;
		yield return new WaitForSeconds(6);
		thisJOB.SetActive (false);
		thisChira.SetActive (false);
		thisYider.SetActive (false);
		thisWarrar.SetActive (false);
		thisKaren.SetActive (false);
		thisfoPlayer.SetActive (false);
		StartCoroutine (ending ());
	
	}
	IEnumerator teleIn()
	{
		canTele = true;
		tele.SetActive (true);
		yield return new WaitForSeconds (.4f);
		tele.SetActive (false);
		markSprite.enabled = true;
	}

	IEnumerator ending()
	{
		creditSprites.enabled = true;
		fadeAmount = 0;		
		creditsFade = true;
		yield return new WaitForSeconds (.1f);
		player.HUD.enabled = false;
		credits.SetActive (true);


		credits.GetComponent<AudioSource> ().Play();

		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(9f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(3f);
		StartCoroutine (fadeIn ());
		yield return new WaitForSeconds(18f);
		StartCoroutine (fadeOut ());
		yield return new WaitForSeconds(9f);

		Destroy (thisPlayer);
	//	player.HUD.enabled = false;
		player.levelPoint = 0;
		Application.LoadLevel ("Menu");
		player.health = player.maxHealth;
		player.energy = player.maxEnergy;
		player.playerDead = false;
		player.speed = 4;

	}

	IEnumerator fadeOut()
	{
		fadeAmount = 1;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .9f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .8f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .7f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .6f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .5f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .4f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .3f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .2f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .1f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = 0;

	}
	IEnumerator fadeIn()
	{
		fadeAmount = 0;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .1f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .2f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .3f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .4f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .5f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .6f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .7f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .8f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = .9f;
		yield return new WaitForSeconds(.2f);
		fadeAmount = 1;

	}
}


