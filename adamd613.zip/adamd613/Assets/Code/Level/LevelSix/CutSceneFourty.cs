﻿using UnityEngine;
using System.Collections;

public class CutSceneFourty: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public Collider2D thisCollider;

	public GameObject Door;

	public GameObject thisLogan;
	public FollowerMob logan;

	public bool walkLeft;
	public bool walkUp;
	public bool playerUp;

	public int thisProg;
	public int nextProg;
	public int textTrigger;
	public bool sceneActive;

	public bool canEnd;


	void Start () 
	{

		cutScene = gameObject;

		equipment = GameObject.FindGameObjectWithTag ("Equipment");
		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{


		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 


		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{
			cutScene.SetActive (false);
			logan.transform.position = new Vector3 (24, 31.4f, 0);

		}


		if (dialogue.textNum >= textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}

		if ( walkUp == true) {
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkUp");
		}
		if ( walkLeft == true) {
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkLeft");
		}

		if ( playerUp == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			player.animator.Play ("WalkUp");
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			StartCoroutine (enter ());


			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator enter()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
		playerUp = true;
		yield return new WaitForSeconds(2f);
		playerUp = false;
	}

	IEnumerator ending()
	{
		canEnd = true;
		walkLeft = true;
		yield return new WaitForSeconds(1.5f);
		walkLeft = false;
		walkUp = true;
		yield return new WaitForSeconds(1f);
		walkUp = false;
		walkLeft = true;
		Door.SetActive (false);
		yield return new WaitForSeconds(1f);
		walkLeft = false;
		logan.animator.Play ("WalkDown");
		equipment.SetActive (true);
		holding.SetActive (true);
		player.enabled = true;
		player.progPoint = nextProg;
	}

}


