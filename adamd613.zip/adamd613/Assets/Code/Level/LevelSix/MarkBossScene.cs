﻿using UnityEngine;
using System.Collections;

public class MarkBossScene: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	//public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;
	public Collider2D markCollider;



	public int thisProg;
	public int nextProg;
	//public int textTrigger;

	public bool cantReset;
	public bool canEnd;
	public GameObject fences;

	public bool isAlive;
	public bool sceneActive;

	public GameObject MarkBoss;
	public GameObject Shield;
	public SpriteRenderer DarkRenderer;
	public MarkBoss thisBoss;
	public MeleeShadowGuard mark;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{
		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}

		if (player.health <= 0 && cantReset == false) {
			StartCoroutine (resetBoss ());
			thisCollider.enabled = false;
			isAlive = false;
			thisBoss.enabled = false;
		
		}
		if (player.health >= 1 && isAlive == false) {
			thisCollider.enabled = true;
			cantReset = false;
		}

	if (mark.health <= 0) {
			StartCoroutine (ending ());
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			fences.SetActive (true);
			isAlive = true;
			MarkBoss.SetActive (true);
			StartCoroutine (enter ());
			player.enabled = false;
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}

	IEnumerator enter()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
		levelManager.GetComponent<AudioSource> ().Pause();
		thisBoss.markSprite.enabled = true;
		yield return new WaitForSeconds(2f);
		AudioSource trapMusic = GetComponent<AudioSource>();

		trapMusic.Play();
		player.enabled = true;
		equipment.SetActive (true);
		holding.SetActive (true);
		thisCollider.enabled = false;
		thisBoss.markZap.SetActive (false);
		thisBoss.marksSword.SetActive (false);
		thisBoss.markTele.SetActive (true);
		thisBoss.markSprite.enabled = false;
		yield return new WaitForSeconds (.4f);
		thisBoss.markTele.SetActive (false);
		thisBoss.enabled = true;
	}


	IEnumerator resetBoss()
	{
		cantReset = true;
		levelManager.GetComponent<AudioSource> ().Play();
		AudioSource trapMusic = GetComponent<AudioSource>();

		trapMusic.Pause();
		yield return new WaitForSeconds(.2f);
		fences.SetActive (false);
		thisBoss.stage = 0;
		thisBoss.counter = 0;
		thisBoss.starting = false;
		thisBoss.canStage = false;
		thisBoss.mark.distance = 2;
		thisBoss.mark.range = 2;
		thisBoss.marksSword.SetActive (false);
		thisBoss.markZap.SetActive (false);
		thisBoss.mark.health = thisBoss.mark.maxHealth;
		thisBoss.markCollider.enabled = false;
		thisBoss.thisMark.transform.position = new Vector3 (160, 10, 0);
		yield return new WaitForSeconds(.2f);
		MarkBoss.SetActive (false);
	

	}

	IEnumerator ending()
	{
		yield return new WaitForSeconds(.2f);
		thisBoss.markTele.SetActive (true);
		thisBoss.markSprite.enabled = false;
		thisBoss.markZap.SetActive (false);
		thisBoss.marksSword.SetActive (false);
		yield return new WaitForSeconds (.4f);
		thisBoss.markTele.SetActive (false);
		thisBoss.thisMark.SetActive (false);
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


