﻿using UnityEngine;
using System.Collections;

public class CutSceneFourtyOne: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogueThree;
	public EndingDialogue dialogueTwo;
	public EndingDialogue dialogue;
	public Collider2D thisCollider;

	public GameObject thisLogan;
	public FollowerMob logan;

	public GameObject thisPat;
	public FollowerMob pat;

	public GameObject thisMark;
	public FollowerMob mark;

	public bool walkLeft;
	public bool walkRight;
	public bool MarkUp;
	public GameObject markStatic;
	public GameObject teleport;
	public SpriteRenderer patSprite;
	public bool playerRight;

	public int thisProg;
	public int nextProg;
	public int textTrigger;
	public bool sceneActive;

	public bool canEnd;
	public bool canEndTwo;
	public bool canEndThree;

	private bool canAnimate;
	private bool canAnimateTwo;
	private bool canAnimateThree;

	public GameObject nextScene;

	void Start () 
	{

		cutScene = gameObject;

		equipment = GameObject.FindGameObjectWithTag ("Equipment");
		holding = GameObject.FindGameObjectWithTag ("Holding");


		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 


	}

	void Update ()
	{


		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 


		if (player.progPoint <= thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint > thisProg) 
		{
			cutScene.SetActive (false);
		}


		if (dialogue.textNum >= 3 && canEnd == false) 
		{
			StartCoroutine (endingOne ());
		}

		if (dialogueTwo.textNum >= 4 && canEndTwo == false) 
		{
			StartCoroutine (endingTwo ());
		}

		if (dialogueThree.textNum >= 2 && canEndThree == false) 
		{
			StartCoroutine (endingThree ());
		}
		if (dialogueTwo.textNum == 1 && canAnimate == false) {
			mark.animator.Play ("WalkLeft");
			canAnimate = true;
		}

		if (dialogueTwo.textNum == 2  && canAnimateTwo == false) {
			pat.animator.Play ("WalkRight");
			canAnimateTwo = true;
		}

		if (dialogueTwo.textNum == 3  && canAnimateThree == false) {
			logan.animator.Play ("WalkDown");
			canAnimateThree = true;
		}

		if ( walkRight == true) {
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			logan.animator.Play ("WalkRight");
		}
		if ( walkLeft == true) {
			logan.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 4 * Time.deltaTime;	
			logan.animator.Play ("WalkLeft");
		}
		if ( MarkUp == true) {
			mark.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			mark.animator.Play ("WalkUp");
		}

		if ( playerRight == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			StartCoroutine (enter ());


			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator enter()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
		playerRight = true;
		yield return new WaitForSeconds(5f);
		playerRight = false;
		thisLogan.SetActive (true);
		walkRight = true;
		yield return new WaitForSeconds(3.5f);
		walkRight = false;
		dialogue.enabled = true;
		mark.animator.Play ("WalkLeft");

	}


	IEnumerator endingOne()
	{
		canEnd = true;
		dialogue.enabled = false;
		thisPat.SetActive (true);
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		patSprite.enabled = true;
		yield return new WaitForSeconds (1f);
		dialogueTwo.enabled = true;
	}

	IEnumerator endingTwo()
	{
		

		canEndTwo = true;
		dialogueTwo.enabled = false;
		MarkUp = true;
		yield return new WaitForSeconds(1.5f);
		MarkUp = false;
		dialogueThree.enabled = true;
	}

	IEnumerator endingThree()
	{
		dialogueThree.enabled = false;
		markStatic.SetActive (true);
		yield return new WaitForSeconds(1f);
		walkLeft = true;
		yield return new WaitForSeconds(1.6f);
		walkLeft = false;
		patSprite.enabled = false;
		thisLogan.SetActive (false);
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		thisPat.SetActive (false);
		yield return new WaitForSeconds(1f);
		equipment.SetActive (true);
		holding.SetActive (true); 
		thisMark.SetActive (false);
		player.enabled = true;
		nextScene.SetActive (true);
		player.progPoint = nextProg;
	}
		
}


