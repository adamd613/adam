﻿using UnityEngine;
using System.Collections;

public class CutSceneThirtyFour: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisMark;
	public FollowerMob mark;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public bool resetMark;
	public bool left;
	public bool right;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool freeze;


	public bool righting;
	public bool upping;
	public bool canEnd;


	public bool sceneActive;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");
		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisMark.GetComponent<FollowerMob> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{



		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}
		if (player.progPoint == 29) {
			thisMark.SetActive (false);
		}

		if (righting == true) {
			mark.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 4 * Time.deltaTime;	
			mark.animator.Play ("WalkRight");
		}
		if (upping == true) {
			mark.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 4 * Time.deltaTime;	
			mark.animator.Play ("WalkUp");
		}
		if (dialogue.textNum >= textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			holding.SetActive (false);
		//	equipment.SetActive (false);

			if (resetMark == true && left == false && right == false) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x,thisPlayer.transform.position.y - 2);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && left == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x - 2,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && right == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x + 2,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
			StartCoroutine (startScene ());
		}
	}

	IEnumerator startScene()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
	}
	IEnumerator ending()
	{
		canEnd = true;
		yield return new WaitForSeconds(.5f);

		if(freeze == true)
			thisMark.GetComponent<BoxCollider2D> ().isTrigger = true;
		mark.distance = 2;
		mark.range = 2;
		dialogue.enabled = false;
		StartCoroutine (endingTwo ());

	}

	IEnumerator endingTwo()
	{
		righting = true;
		yield return new WaitForSeconds(1.75f);
		righting = false;
		upping = true;
		yield return new WaitForSeconds(3f);
		upping = false;
		thisMark.SetActive (false);
		player.enabled = true;
		holding.SetActive (true);
		equipment.SetActive (true);
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


