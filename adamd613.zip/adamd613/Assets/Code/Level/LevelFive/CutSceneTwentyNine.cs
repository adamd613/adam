﻿using UnityEngine;
using System.Collections;

public class CutSceneTwentyNine: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisMark;
	public FollowerMob mark;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public bool resetMark;
	public bool left;
	public bool right;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public GameObject ShadowMan;
	public bool sceneActive;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");
		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisMark.GetComponent<FollowerMob> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{



		
		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			holding.SetActive (false);
		//	equipment.SetActive (false);
			ShadowMan.transform.position = new Vector3(30,63,0);

			if (resetMark == true && left == false && right == false) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x,thisPlayer.transform.position.y - 3);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && left == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x - 3,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && right == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x + 3,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
			StartCoroutine (startScene ());
		}
	}
	IEnumerator startScene()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
	}

	IEnumerator ending()
	{
		yield return new WaitForSeconds(.5f);
		player.enabled = true;
		holding.SetActive (true);
		equipment.SetActive (true);
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


