﻿using UnityEngine;
using System.Collections;

public class BlockReset : MonoBehaviour {

	public GameObject BlockOne;
	public GameObject BlockTwo;
	public GameObject BlockThree;
	public GameObject BlockFour;
	public GameObject BlockFive;
	public GameObject BlockSix;

	public FloorSwitch switchOne;

	public bool resetTwo;

	void Start () {
	
	}
	

	void Update () {
		if (switchOne.isOn == true) {
			BlockOne.transform.position = new Vector3 (94,86,0);
			BlockTwo.transform.position = new Vector3 (100,86,0);
			BlockThree.transform.position = new Vector3 (92,94,0);
			BlockFour.transform.position = new Vector3 (100,89,0);
			BlockFive.transform.position = new Vector3 (92,98,0);
			BlockSix.transform.position = new Vector3 (100,92,0);
		}
		if (switchOne.isOn == true && resetTwo == true) {
			BlockOne.transform.position = new Vector3 (146,52,0);
			BlockTwo.transform.position = new Vector3 (156,56,0);
			BlockThree.transform.position = new Vector3 (162,64,0);
			BlockFour.transform.position = new Vector3 (146,60,0);
			BlockFive.transform.position = new Vector3 (155,64,0);
			BlockSix.transform.position = new Vector3 (155,64,0);
		}
	}
}
