﻿using UnityEngine;
using System.Collections;

public class CutSceneThirtyFive: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisMark;
	public FollowerMob mark;
	public GameObject thisPat;
	public FollowerMob pat;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public EndingDialogue dialogueTwo;
	public EndingDialogue dialogueThree;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public bool resetMark;
	public bool left;
	public bool right;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool freeze;
	public bool HUDOff;

	public bool righting;
	public bool playerRighting;
	public bool PatDown;
	public bool PatLeft;

	public bool canEnd;
	public GameObject porting;
	public SpriteRenderer PatSprite;

	public GameObject BallOne;
	public GameObject BallTwo;
	public GameObject BallThree;
	public GameObject BallFour;
	public GameObject Killing;

	public GameObject Stone;

	public bool sceneActive;

	public GameObject DarkBoss;
	public GameObject Shield;
	public SpriteRenderer DarkRenderer;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");
	
		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisMark.GetComponent<FollowerMob> ();
		} 

	}

	void Update ()
	{
		if (player.progPoint >= 30) {
			thisPat.SetActive(false);
			Stone.SetActive (false);
		
		}
		if (player.progPoint == 30) {
			thisMark.SetActive(false);
		}
	
		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (righting == true) {
			mark.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			mark.animator.Play ("WalkRight");
		}
		if (playerRighting == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
		if (PatDown == true) {
			pat.animator.Play ("WalkDown");
		}
		if (PatLeft == true) {
			pat.animator.Play ("WalkLeft");
		}
		if (dialogue.textNum == textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}
		if (dialogueThree.textNum >= 4 && canEnd == false) 
		{
			StartCoroutine (endingTwo ());
		}
		if (dialogueTwo.textNum >= 5 && canEnd == false) 
		{
			StartCoroutine (endingThree ());
		}
		if (dialogueThree.textNum == 2) {
			canEnd = false;
		}

	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			holding.SetActive (false);
			thisMark.SetActive (false);
			StartCoroutine (enter ());
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}

	IEnumerator enter()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
		playerRighting = true;
		yield return new WaitForSeconds(4f);
		playerRighting = false;
	}


	IEnumerator ending()
	{
		canEnd = true;
		dialogue.textNum = 1;
		dialogue.enabled = false;
		PatDown = true;
		yield return new WaitForSeconds(.1f);
		PatDown = false;
		yield return new WaitForSeconds(2f);
		PatLeft = true;
		yield return new WaitForSeconds(.1f);
		PatLeft = false;
		dialogueThree.enabled = true;
		levelManager.GetComponent<AudioSource> ().Pause();




	}

	IEnumerator endingTwo()
	{

		canEnd = true;
		yield return new WaitForSeconds(.01f);
		dialogueThree.textNum = 1;
		dialogueThree.enabled = false;
		player.armor = 100;
		Killing.SetActive (true);
		BallOne.SetActive (true);
		yield return new WaitForSeconds(.75f);
		BallTwo.SetActive (true);
		yield return new WaitForSeconds(.75f);
		BallThree.SetActive (true);
		yield return new WaitForSeconds(.75f);
		BallFour.SetActive (true);
		yield return new WaitForSeconds(4f);
		BallOne.SetActive (false);
		BallTwo.SetActive (false);
		BallThree.SetActive (false);
		BallFour.SetActive (false);
		Killing.SetActive (false);
		player.armor = 0;
		dialogueTwo.enabled = true;
		thisMark.SetActive (true);
		if (resetMark == true && left == true && right == false) {
			thisMark.transform.position = new Vector3(thisPlayer.transform.position.x - 9,thisPlayer.transform.position.y);
			mark.distance = 2;
			mark.range = 2;

		}

		if(freeze == true)
			thisMark.GetComponent<BoxCollider2D> ().isTrigger = true;
		righting = true;
		yield return new WaitForSeconds(3f);
		righting = false;
		canEnd = false;


	
	}
	IEnumerator endingThree()
	{
		dialogueTwo.enabled = false;
		canEnd = true;
		righting = true;
		yield return new WaitForSeconds(2.5f);
		DarkBoss.SetActive (true);
		DarkRenderer.enabled = false;
		righting = false;
		Shield.SetActive (true);
		yield return new WaitForSeconds(2f);
		thisMark.SetActive (false);
		DarkRenderer.enabled = true;
		Shield.SetActive (false);
		yield return new WaitForSeconds(1f);
		porting.SetActive (true);
		PatSprite.enabled = false;
		yield return new WaitForSeconds(.4f);
		porting.SetActive (false);
		thisPat.transform.position = new Vector3(300,300);
		player.enabled = true;
		holding.SetActive (true);
		equipment.SetActive (true);
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


