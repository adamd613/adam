﻿using UnityEngine;
using System.Collections;

public class KillPlayerStopper: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public bool sceneActive;

	public OrderedDialogue dialogue;
	public Collider2D thisCollider;

	public bool walkDown;
	public bool walkRight;

	public int thisProg;
	public int textTrigger;

	public GameObject MobOne;
	public GameObject MobTwo;
	public GameObject MobThree;
	public GameObject MobFour;
	public GameObject MobFive;
	public GameObject MobSix;
	public GameObject MobSeven;

	public GameObject nextScene;

	public bool canEnd;

	public bool goRight;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");
		equipment = GameObject.FindGameObjectWithTag ("Equipment");
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 


		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}
		else
		{

			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= textTrigger) 
		{
			if (goRight == false) {
				StartCoroutine (ending ());
			} else {
				StartCoroutine (endingTwo ());
			}


		}
		if ((MobOne == null && MobTwo == null && MobThree == null && MobFour == null && MobFive == null && MobSix == null && MobSeven == null) && canEnd == false)
			StartCoroutine (finish ());

		if (walkDown == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			player.animator.Play ("WalkDown");
		}
		if (walkRight == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;
			holding.SetActive (false);
			StartCoroutine (enter ());
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator enter()
	{

		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);

	}

	IEnumerator ending()
	{

		walkDown = true;
		yield return new WaitForSeconds(1f);
		walkDown = false;
		player.enabled = true;
		equipment.SetActive (true);
		holding.SetActive (true);
	}
	IEnumerator endingTwo()
	{

		walkRight = true;
		yield return new WaitForSeconds(1f);
		walkRight = false;
		player.enabled = true;
		equipment.SetActive (true);
		holding.SetActive (true);
	}
	IEnumerator finish()
	{
		canEnd = true;
		yield return new WaitForSeconds(.1f);
		nextScene.SetActive (true);
		player.progPoint = player.progPoint + 1;
	}
}


