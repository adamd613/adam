﻿using UnityEngine;
using System.Collections;

public class CutSceneThirtySeven: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisMark;
	public FollowerMob mark;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public GameObject fences;

	public GameObject thisChest;

	public bool resetMark;
	public bool left;
	public bool right;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool freeze;
	public bool HUDOff;

	public bool lefting;

	public bool canEnd;


	public bool sceneActive;

	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisMark.GetComponent<FollowerMob> ();
		} 

	}

	void Update ()
	{
		if (player.progPoint >= 32) {
			thisMark.SetActive(false);
			fences.SetActive (false);

		}

		if (resetMark == true) {
			mark.transform.position = new Vector3(89,148,0);
			mark.range = 2;
			mark.distance = 2;
			resetMark = false;
		}

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (lefting == true) {
			mark.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			mark.animator.Play ("WalkLeft");
		}

		if (dialogue.textNum == textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			resetMark = true;
			player.moving = false;
			holding.SetActive (false);
			fences.SetActive (false);
			thisMark.SetActive (true);
			StartCoroutine (enter ());
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}

	IEnumerator enter()
	{
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
	}


	IEnumerator ending()
	{
		canEnd = true;
		lefting = true;
		dialogue.enabled = false;
		yield return new WaitForSeconds(8f);
		lefting = false;
		player.enabled = true;
		equipment.SetActive (true);
		holding.SetActive (true);
		player.progPoint = nextProg;
		thisChest.SetActive (true);
		nextScene.SetActive (true);

	}


	
}


