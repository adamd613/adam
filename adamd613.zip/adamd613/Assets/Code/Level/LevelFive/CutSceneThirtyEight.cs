﻿using UnityEngine;
using System.Collections;

public class CutSceneThirtyEight: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisChira;
	public PatVillager chira;

	public GameObject PatVillagerOne;
	public GameObject PatVillagerTwo;
	public GameObject PatVillagerThree;
	public GameObject PatVillagerFour;
	public GameObject PatVillagerFive;
	public GameObject PatVillagerSix;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public GameObject equipment;

	public EndingDialogue dialogue;
	public EndingDialogue dialogueTwo;
	//public EndingDialogue dialogueThree;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public bool ChiraLeft;
	public bool ChiraDown;

	public int thisProg;
	public int nextProg;
	public int textTrigger;

	public bool playerRighting;
	public bool playerUpping;

	public bool canEnd;
	public bool canPlay;

	public GameObject MageOne;
	public GameObject MageTwo;

	public bool sceneActive;


	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		equipment = GameObject.FindGameObjectWithTag ("Equipment");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisChira == null)
		{
			thisChira = GameObject.FindGameObjectWithTag ("Chira");
			chira = thisChira.GetComponent<PatVillager> ();
		} 

	}

	void Update ()
	{


		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
			thisChira.SetActive (true);
			PatVillagerOne.SetActive (true);
			PatVillagerTwo.SetActive (true);
			PatVillagerThree.SetActive (true);
			PatVillagerFour.SetActive (true);
			PatVillagerFive.SetActive (true);
			PatVillagerSix.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}

		if (playerRighting == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 4 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
		if (playerUpping == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 4 * Time.deltaTime;	
			player.animator.Play ("WalkUp");
		}
		if (ChiraDown == true) {
			chira.animator.Play ("WalkDown");
		}
		if (ChiraLeft == true) {
			chira.animator.Play ("WalkLeft");
		}
		if (dialogueTwo.textNum == textTrigger && canEnd == false) 
		{
			StartCoroutine (ending ());
		}
		if (dialogue.textNum == textTrigger && canPlay == false) 
		{
			StartCoroutine (moving ());
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			player.moving = false;

			StartCoroutine (enter ());
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}

	IEnumerator enter()
	{
		MageOne.SetActive (false);
		MageTwo.SetActive (false);
		yield return new WaitForSeconds(.1f);
		equipment.SetActive (false);
		holding.SetActive (false);
		playerRighting = true;
		yield return new WaitForSeconds(7f);
		playerRighting = false;
		playerUpping = true;
		yield return new WaitForSeconds(2f);
		playerUpping = false;
	}


	IEnumerator moving()
	{
		canPlay = true;
		dialogue.enabled = false;
		ChiraLeft = true;
		yield return new WaitForSeconds(.1f);
		ChiraLeft = false;
		yield return new WaitForSeconds(2f);
		ChiraDown = true;
		yield return new WaitForSeconds(.1f);
		ChiraDown = false;
		dialogueTwo.enabled = true;
		levelManager.GetComponent<AudioSource> ().Pause();


	}
		
	IEnumerator ending()
	{
		canEnd = true;
		yield return new WaitForSeconds(1f);
		player.enabled = true;
		equipment.SetActive (true);
		holding.SetActive (true);
		dialogueTwo.enabled = false;
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


