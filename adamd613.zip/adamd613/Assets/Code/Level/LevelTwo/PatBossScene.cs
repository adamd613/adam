﻿using UnityEngine;
using System.Collections;

public class PatBossScene : MonoBehaviour {

		public GameObject thisPlayer;
		public GameObject cutScene;
		public GameObject thisPat;
		public AttackingPat pat;
		public Player player;
		public GameObject mainDia;
		public EndingDialogue dialogue;
		//public GameObject thisSecondDia;
		public EndingDialogue deathLog;
		public GameObject holding;
		public GameObject smack;
		
		public GUISkin guiSKIN;
		//public GameObject nextScene;
		public SpriteRenderer patSprite;
		public Collider2D thisCollider;

		public GameObject teleport;
		public HUDController HUD;
		public AttackingMob EnemyOne;
		public AttackingMob EnemyTwo;
		public AttackingMob EnemyThree;

		public GameObject diaOne;
		public GameObject diaTwo;

		public bool blackout;
		public bool canNext;

		public bool musicRestart;

		public GameObject levelManager;

		void Start () 
		{
			holding = GameObject.FindGameObjectWithTag ("Holding");
			
			if(thisPlayer == null)
			{
				thisPlayer = GameObject.FindGameObjectWithTag ("Player");
				player = thisPlayer.GetComponent<Player> ();
			} 
			levelManager = GameObject.FindGameObjectWithTag ("levelManager");
			
		}

		void OnGUI()
		{
			GUI.skin = guiSKIN;
		if (blackout == true) {
			GUI.Box (new Rect (0, 0, Screen.width, Screen.height), "", "Menu");
		}
		}

		void Update ()
		{
		HUD = thisPlayer.GetComponent<HUDController> ();

		if (player.health <= 0) 
		{
			pat.enabled = false;
			thisPat.transform.position = new Vector3(-232, 55, 0);
			patSprite.enabled = false;
			dialogue.textNum = 0;
			pat.stage = 0;
			pat.counter = 0;
			pat.starting = false;
			pat.canStage = false;
			pat.health = pat.maxHealth;
			pat.ballFive.transform.position = new Vector3(-238, 60, 0);
			pat.ballSix.transform.position = new Vector3(-236, 60, 0);
			pat.ballSeven.transform.position = new Vector3(-234, 60, 0);
			pat.ballEight.transform.position = new Vector3(-232, 60, 0);
			pat.ballNine.transform.position = new Vector3(-230, 60, 0);
			pat.ballTen.transform.position = new Vector3(-228, 60, 0);
			pat.ballEleven.transform.position = new Vector3(-226, 60, 0);
			pat.ballTwelve.transform.position = new Vector3(-226, 49, 0);
			pat.ballThirteen.transform.position = new Vector3(-228, 49, 0);
			pat.ballFourteen.transform.position = new Vector3(-230, 49, 0);
			pat.ballFifteen.transform.position = new Vector3(-232, 49, 0);
			pat.ballSixteen.transform.position = new Vector3(-234, 49, 0);
			pat.ballSeventeen.transform.position = new Vector3(-236, 49, 0);
			pat.ballEighteen.transform.position = new Vector3(-238, 49, 0);
			pat.ballOne.transform.position = patSprite.transform.position;
			pat.ballTwo.transform.position = patSprite.transform.position;
			pat.ballThree.transform.position = patSprite.transform.position;
			pat.ballFour.transform.position = patSprite.transform.position;
			if(musicRestart == true)
				StartCoroutine (restartMusic ());;
		}

			if (player.progPoint == 5) 
			{
				cutScene.SetActive (true);

			EnemyOne.health = 0;
			EnemyTwo.health = 0;
			EnemyThree.health = 0;
			diaOne.SetActive (false);
			diaTwo.SetActive (false);
			}

			if (player.progPoint != 5) 
			{
				cutScene.SetActive (false);
			}


			if (dialogue.textNum >= 1) 
			{

			dialogue.enabled = false;

		//	holding.SetActive (true);

		//	player.enabled = true;

			StartCoroutine (ending ());
			}
		if (pat.health <= 0 && deathLog.textNum <= 2) 
		{
			holding.SetActive (false);
			patSprite.enabled = true;
			teleport.SetActive (false);


		}
		if (deathLog.textNum >= 3 && canNext == false) 
		{
			StartCoroutine (nextLevel ());

		}
		}

		void OnTriggerEnter2D(Collider2D col)
		{
		if(col.GetComponent<Player>() != null && player.health > 0)
			{
				player.moving = false;
				StartCoroutine (taunt ());
				
				levelManager.GetComponent<AudioSource> ().Pause();
			}
		}
		IEnumerator taunt()
		{
			pat.isHostile = false;
			yield return new WaitForSeconds (4f);
			teleport.SetActive (true);
	
			yield return new WaitForSeconds (.4f);
			pat.isHostile = true;
			teleport.SetActive (false);
			patSprite.enabled = true;
			AudioSource trapMusic = GetComponent<AudioSource>();	
			trapMusic.Play();
			musicRestart = true;
			dialogue.enabled = true;
			
			holding.SetActive (false);

			player.enabled = false;
		}

		IEnumerator restartMusic()
	{
		musicRestart = false;
		yield return new WaitForSeconds (.1f);
		AudioSource trapMusic = GetComponent<AudioSource>();	
		trapMusic.Stop();
		levelManager.GetComponent<AudioSource> ().Play();

	}

		IEnumerator nextLevel()
	{
		canNext = true;
		player.enabled = true;
		holding.SetActive (true);
		teleport.SetActive (true);
		patSprite.enabled = false;
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		blackout = true;
		deathLog.enabled = false;
		HUD.ClearAll ();
		AudioSource trapMusic = GetComponent<AudioSource>();	
		trapMusic.Stop();
		AudioSource boSmack = smack.GetComponent<AudioSource>();	
		boSmack.Play();
		yield return new WaitForSeconds (5f);
		player.progPoint = 6;
		player.transform.position = new Vector3(48, 87, 0);	
		Application.LoadLevel("Level Three");

	}


		IEnumerator ending()
		{
			dialogue.textNum = 0;
			yield return new WaitForSeconds (.5f);
			teleport.SetActive (true);
			patSprite.enabled = false;
			yield return new WaitForSeconds (.4f);
			teleport.SetActive (false);
			player.enabled = true;
			holding.SetActive (true);
			pat.enabled = true;
			pat.isHostile = false;
		}
	}

