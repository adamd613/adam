﻿using UnityEngine;
using System.Collections;

public class MusicChanger : MonoBehaviour {

	public GameObject currentMusic;
	public GameObject thisMusic;

	void Start () 
	{

	}
	

	void Update () {
	
	}
	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<CorpPlayer>() != null)
		{
			thisMusic.GetComponent<AudioSource>().Play();
			currentMusic.GetComponent<AudioSource> ().Pause();
		}
	}
}
