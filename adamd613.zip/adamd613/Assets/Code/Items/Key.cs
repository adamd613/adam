﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Key : Item {

	public GameObject key;

	public SpriteRenderer weaponSpriteParent;
	public Vector2 forwardPos, backPos, sidePos;

	public List<LockedDoor> doorInRange = new List<LockedDoor>();

	void Start () 
	{

	}

	void Update () 
	{
		if (ipManager.items [4].amountOfItem > 0) 
		{
			weaponSpriteParent.enabled = true;
		}
		else if (ipManager.items [4].amountOfItem == 0) 
		{
			key.SetActive(false);
			isEquip = false;
		}
		if (Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift))  
		{
			StartCoroutine (flashSprite ());
		}

		if (player.direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = forwardPos;
		}
		if (player.direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			weaponSpriteParent.transform.localPosition = backPos;
		}
		if (player.direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			weaponSpriteParent.transform.localPosition = sidePos;
		}
		if (player.direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = sidePos;
		}
	}

	IEnumerator flashSprite()
	{
		useKey ();
		weaponSpriteParent.enabled = false;
		yield return new WaitForSeconds (.1f);
		weaponSpriteParent.enabled = true;
	}

	public void useKey ()
	{
		foreach (LockedDoor d in doorInRange) 
		{
			//d.Unlock ();
			d.locked = false;
		}
	}
		

	void OnTriggerEnter2D(Collider2D other) 
	{
		LockedDoor tempEnt = other.GetComponent<LockedDoor> ();
		if(tempEnt != null)
		{
			if (doorInRange.Contains (tempEnt))
				return;
			doorInRange.Add (tempEnt);
		}
	}

	void OnTriggerExit2D(Collider2D other)
	{
		LockedDoor tempEnt = other.GetComponent<LockedDoor> ();
		if (tempEnt != null) 
		{
			int index = doorInRange.IndexOf (tempEnt);
			doorInRange.Remove (doorInRange [index]);
		}
	}
}

