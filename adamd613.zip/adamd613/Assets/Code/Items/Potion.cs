﻿using UnityEngine;
using System.Collections;

public class Potion : Item {

	public Entity healing;

	public GameObject potion;

	public SpriteRenderer weaponSpriteParent;
	public Vector2 forwardPos, backPos, sidePos;

	void Start () 
	{

	}

	void Update () 
	{
		player.attackSpeed = .1f;

		if (ipManager.items [1].amountOfItem > 0) 
		{
			weaponSpriteParent.enabled = true;
		}
		else if (ipManager.items [1].amountOfItem == 0) 
		{
			potion.SetActive(false);
			isEquip = false;
		}
		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && player.usable == true)  
		{
			if (player.health < player.maxHealth) {
				StartCoroutine (waitForHeal ());
			}
		}


		if (player.direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = forwardPos;
		}
		if (player.direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			weaponSpriteParent.transform.localPosition = backPos;
		}
		if (player.direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			weaponSpriteParent.transform.localPosition = sidePos;
		}
		if (player.direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = sidePos;
		}
	}
		
	public void heal ()
	{
		int add = (25);
		healing.addHealth(add);
	}

	IEnumerator waitForHeal()
	{
		if (ipManager.items [1].amountOfItem > 0) 
		{
			StartCoroutine (flashSprite ());
		}
		yield return new WaitForSeconds (.02f);
		ipManager.removeItemFromInventory (3, 1);
	}
	IEnumerator flashSprite()
	{
		heal ();
		weaponSpriteParent.enabled = false;
		yield return new WaitForSeconds (.1f);
		weaponSpriteParent.enabled = true;
	}
}

