﻿using UnityEngine;
using System.Collections;

public class Incorporeal : Item {

	public Entity entity;
	public GameObject CorpSelf;
	public GameObject Camera;
	public GameObject Holding;

	public Animator playerAnimator;

	public bool waitFor;

	void Start () 
	{
		waitFor = true;
	}

	void OnAwake()
	{
		waitFor = true;
	}

	void Update ()
	{
		if (entity.health <= 0) {
			waitFor = true;
			CorpSelf.transform.position = new Vector3 (thisPlayer.transform.position.x, thisPlayer.transform.position.y);
		}

		if (entity.isIncorpreal == true && waitFor == true && entity.energy <= entity.maxEnergy)
		{
			StartCoroutine (isUsingNow ());
		}
		{	
			if (Input.GetKey (KeyCode.Space) && entity.energy >= 1 && entity.enabled == true) 
			{
				on ();
			} 
			else 
			{
				off ();
			}
		}

		if (Input.GetKeyUp (KeyCode.Space))
		{
			off ();
			Holding.SetActive (true);
		}
			
	}

	public void on ()
	{
		entity.speed = 0;
		entity.isIncorpreal = true;
		CorpSelf.SetActive (true);
		Camera.SetActive (false);
		playerAnimator.enabled = false;
		Holding.SetActive (false);
		entity.GetComponent<BoxCollider2D> ().isTrigger = true;




	}
	public void off()
	{
		CorpSelf.SetActive (false);
		thisPlayer.transform.position = new Vector3(CorpSelf.transform.position.x,CorpSelf.transform.position.y);
		CorpSelf.transform.position = new Vector3(thisPlayer.transform.position.x,thisPlayer.transform.position.y);
		entity.GetComponent<BoxCollider2D> ().isTrigger = false;
		waitFor = true;
		entity.isIncorpreal = false;
		Camera.SetActive (true);
		entity.speed = 4;
		playerAnimator.enabled = true;
	

	}
	IEnumerator isUsingNow()
	{
		waitFor = false;
		entity.energy -= 1;
		yield return new WaitForSeconds (.25f);
		waitFor = true;
	}

}
