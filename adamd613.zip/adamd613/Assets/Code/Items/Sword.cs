﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Sword : Item {


	public int minDamage;
	public int maxDamage;
	private int realDamage;
	public SpriteRenderer weaponSpriteParent;

	public bool attackAnimTwo;

	public AudioClip swing;

	public Vector2 forwardPos, backPos, sidePos;

	public CircleCollider2D DamageCollider2D;

	public List<Entity> enemyInRange = new List<Entity>();


	void Start () 
	{

	}

	void Update () 
	{
		if (player.health <= 0 || (player.transform.position.x == 15 && player.transform.position.y == 28)) 
		{
			enemyInRange.Clear();
		}

		player.attackSpeed = .2f;


		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && player.usable == true)  
		{
			StartCoroutine (partTwo ());
			attack ();
		}
	
	

		if (player.direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;	
			weaponSpriteParent.transform.localPosition = forwardPos;
			DamageCollider2D.offset = new Vector2 (-.5f, -.2f);
			if (player.attackAnim == true) 
			{
				if (attackAnimTwo == false) {
					weaponSpriteParent.sortingOrder = 21;
					Quaternion Rot = Quaternion.Euler (0, 0, 20f);
					weaponSpriteParent.transform.localRotation = Rot;	
					weaponSpriteParent.transform.localPosition = forwardPos;
				} else if (attackAnimTwo == true) {
					weaponSpriteParent.sortingOrder = 21;
					Quaternion Rot = Quaternion.Euler (0, 0, -5f);
					weaponSpriteParent.transform.localRotation = Rot;	
					weaponSpriteParent.transform.localPosition = forwardPos;
				}
			}
		}
		if (player.direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = backPos;
			DamageCollider2D.offset = new Vector2 (.8f, .5f);
			if (player.attackAnim == true)  
			{
				if (attackAnimTwo == false)
				{
					weaponSpriteParent.sortingOrder = 19;
					Quaternion Rot = Quaternion.Euler (0, 0, 80f);
					weaponSpriteParent.transform.localRotation = Rot;	
					weaponSpriteParent.transform.localPosition = backPos;
				} 
				else if (attackAnimTwo == true) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 95);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = backPos;
					}
			}
		}
		if (player.direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (0, 0, 90);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (0, .6f);
			if (player.attackAnim == true) 
			{
				if (attackAnimTwo == false) {
					weaponSpriteParent.sortingOrder = 19;
					Quaternion Rot = Quaternion.Euler (0, 0, 115);
					weaponSpriteParent.transform.localRotation = Rot;	
					weaponSpriteParent.transform.localPosition = sidePos;
				}
				else if (attackAnimTwo == true) {
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 0, 140);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
				}
			}
		}
		if (player.direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (.6f, 0);
			if (player.attackAnim == true) 
			{
				if (attackAnimTwo == false) {
					weaponSpriteParent.sortingOrder = 21;
					Quaternion Rot = Quaternion.Euler (0, 0, -25);
					weaponSpriteParent.transform.localRotation = Rot;	
					weaponSpriteParent.transform.localPosition = sidePos;
				} else if (attackAnimTwo == true) {
					weaponSpriteParent.sortingOrder = 21;
					Quaternion Rot = Quaternion.Euler (0, 0, -50);
					weaponSpriteParent.transform.localRotation = Rot;	
					weaponSpriteParent.transform.localPosition = sidePos;
				}
			}
		}
	}

	IEnumerator partTwo()
	{
		yield return new WaitForSeconds (player.attackSpeed/2f);
		attackAnimTwo = true;
		yield return new WaitForSeconds (player.attackSpeed/2f);
		attackAnimTwo = false;
	}

	public void attack()
	{

		realDamage = Random.Range (minDamage, maxDamage);
		foreach (Entity e in enemyInRange) 
			e.takeHealth (realDamage);
		AudioSource swing = GetComponent<AudioSource> ();
		swing.Play ();
	
	}

	void OnTriggerEnter2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			if (tempEnt.isHostile) 
			{
				if (enemyInRange.Contains (tempEnt))
					return;
				enemyInRange.Add (tempEnt);
			}
		}
	}

	void OnTriggerExit2D(Collider2D other)
	{
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			int index = enemyInRange.IndexOf (tempEnt);
			enemyInRange.Remove (enemyInRange[index]);
		}
	}
}
