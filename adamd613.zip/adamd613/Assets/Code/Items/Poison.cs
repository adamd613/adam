﻿using UnityEngine;
using System.Collections;


public class Poison : Item {


	public GameObject poison;

	public int minDamage;
	public int maxDamage;
	private int realDamage;
	public SpriteRenderer weaponSpriteParent;
	//public SpriteRenderer throwingPotion;
	//public SpriteRenderer landingPotion;

	public Vector2 forwardPos, backPos, sidePos;

	public GameObject PoisonDamage;
	public PoisonDamage PoisonScriptDamage;

	public CircleCollider2D DamageCollider2D;

	public Animator throwingAnim;

	void Start () 
	{

		if(PoisonDamage == null)
		{
			PoisonDamage = GameObject.FindGameObjectWithTag ("PoisonDamage");
			PoisonScriptDamage = PoisonDamage.GetComponent<PoisonDamage> ();
			DamageCollider2D = PoisonDamage.GetComponent<CircleCollider2D> ();
		} 

		
	}

	void Update () 
	{

		player.attackSpeed = .5f;

		if (ipManager.items [2].amountOfItem > 0) 
		{
			weaponSpriteParent.enabled = true;
		}
		else if (ipManager.items [2].amountOfItem == 0) 
		{
			poison.SetActive(false);
			isEquip = false;
		}

		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && player.usable == true)  
		{
			if (ipManager.items [2].amountOfItem > 0) {
				StartCoroutine (flashSprite ());
			} 
		}
		if (player.direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = forwardPos;
			weaponSpriteParent.transform.localPosition = forwardPos;
			//DamageCollider2D.offset = new Vector2 (-.35f, -4);
		}
		if (player.direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			weaponSpriteParent.transform.localPosition = backPos;
			weaponSpriteParent.transform.localPosition = backPos;
			//DamageCollider2D.offset = new Vector2 (.35f, 4);
		}
		if (player.direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			weaponSpriteParent.transform.localPosition = sidePos;
			weaponSpriteParent.transform.localPosition = sidePos;
			//DamageCollider2D.offset = new Vector2 (-4, 0);
		}
		if (player.direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = sidePos;
			weaponSpriteParent.transform.localPosition = sidePos;
			//DamageCollider2D.offset = new Vector2 (4, 0);
		}
	}
		

	IEnumerator flashSprite()
	{
		weaponSpriteParent.enabled = false;

		if (player.direction == 1) {
			throwingAnim.Play ("WalkUp");
			PoisonDamage.transform.position = new Vector3 (thisPlayer.transform.position.x, thisPlayer.transform.position.y + 4);
		}
		if (player.direction == 2) {
			throwingAnim.Play ("WalkLeft");
			PoisonDamage.transform.position = new Vector3 (thisPlayer.transform.position.x - 4, thisPlayer.transform.position.y);
		}
		if (player.direction == 3) {
			throwingAnim.Play ("WalkRight");
			PoisonDamage.transform.position = new Vector3 (thisPlayer.transform.position.x + 4, thisPlayer.transform.position.y);
		}
		if (player.direction == 0) {
			throwingAnim.Play ("WalkDown");
			PoisonDamage.transform.position = new Vector3 (thisPlayer.transform.position.x, thisPlayer.transform.position.y - 4);
		}
		yield return new WaitForSeconds (.25f);
		PoisonScriptDamage.enabled = true;
		PoisonScriptDamage.thisSprite.enabled = true;
		AudioSource trapMusic = GetComponent<AudioSource>();

		trapMusic.Play();
		yield return new WaitForSeconds (.25f);
		PoisonScriptDamage.enabled = false;
		PoisonScriptDamage.thisSprite.enabled = false;
		weaponSpriteParent.enabled = true;
		ipManager.removeItemFromInventory (1, 1);
	}

}
