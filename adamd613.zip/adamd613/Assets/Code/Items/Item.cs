﻿using UnityEngine;
using System.Collections;

public class Item : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public ItemPlayerManager ipManager;

	public string itemName;
	public string itemDescription;
	public bool isEquip = false;
	public string equipped;
	public int id;

	public GameObject associatedItem;
	public Sprite itemSprite;

	void Start () 
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			ipManager = thisPlayer.GetComponent<ItemPlayerManager> ();
		} 
	}
	

	void Update () 
	{
		

	}

	public void UnEquipAll()
	{

		isEquip = false;
		associatedItem.SetActive (false);
	}
	public void Equip()
	{
		

		isEquip = true;
		associatedItem.SetActive (true);
	}
	public void UnEquip()
	{

		isEquip = false;
		associatedItem.SetActive (false);
	}
}
