﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class PoisonDamage : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public SpriteRenderer thisSprite;

	public int minDamage;
	public int maxDamage;
	private int realDamage;

	public bool canAttack;

	public List<Entity> enemyInRange = new List<Entity>();

	void Start () {
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 


	}

	void Update () {
		
		if (player.health <= 0 || (player.transform.position.x == 15 && player.transform.position.y == 28)) 
		{
			enemyInRange.Clear();
		}
		if (canAttack == false)
			StartCoroutine(attacking ());
	}
	void OnTriggerEnter2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			if (tempEnt.isHostile) 
			{
				if (enemyInRange.Contains (tempEnt))
					return;
				enemyInRange.Add (tempEnt);
			}
		}

	}

	void OnTriggerExit2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			int index = enemyInRange.IndexOf (tempEnt);
			enemyInRange.Remove (enemyInRange[index]);
		}
	}

	IEnumerator attacking()
	{
		canAttack = true;
		realDamage = Random.Range (minDamage, maxDamage);
		foreach (Entity e in enemyInRange) 
		{
			e.takeHealth (realDamage);
		}
		yield return new WaitForSeconds (.125f);
		canAttack = false;
	}

}
