﻿using UnityEngine;
using System.Collections;

public class RunningCharm : Item {

	public Entity running;

	public bool waitFor;

	void Start () 
	{
		waitFor = true;
	}

	void OnAwake()
	{
		waitFor = true;
	}
		
	void Update ()
	{
		if (running.health <= 0)
			waitFor = true;

		if (running.isRunCharming == true && waitFor == true && running.moving == true && running.energy <= running.maxEnergy) {
			StartCoroutine (isUsingNow ());
		}
		{	
		if (Input.GetKey (KeyCode.Space) && running.energy >= 1  ) 
		{
			run ();
		} 
		else 
		{
			slow ();
		}
	}

		if (Input.GetKeyUp (KeyCode.Space))
		{
			slow ();

		}
	}

	public void run ()
	{
		running.speed = 6;
		if(running.moving == true)
			running.isRunCharming = true;
	}
	public void slow()
	{
		waitFor = true;
		running.speed = 4;
		running.isRunCharming = false;

	}
	IEnumerator isUsingNow()
	{
		waitFor = false;
		running.energy -= 1;
		yield return new WaitForSeconds (.25f);
		waitFor = true;
	}
}
