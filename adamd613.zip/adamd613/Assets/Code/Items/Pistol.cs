﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Pistol : Item {

	public GameObject pistol;

	public AudioClip shoot;

	public int minDamage;
	public int maxDamage;
	private int realDamage;
	public SpriteRenderer weaponSpriteParent;
	//public SpriteRenderer throwingPotion;
	//public SpriteRenderer landingPotion;
	public SpriteRenderer shootingSpriteParent;

	public Vector2 forwardPos, backPos, sidePos;

	public BoxCollider2D DamageCollider2D;

	public List<Entity> enemyInRange = new List<Entity>();

	void Start () 
	{
		
		shootingSpriteParent.enabled = false;
	}

	void Update () 
	{

		if (player.health <= 0 || (player.transform.position.x == 15 && player.transform.position.y == 28)) 
		{
			enemyInRange.Clear();
		}
		player.attackSpeed = .15f;

		if (ipManager.items [3].amountOfItem > 0) 
		{
			weaponSpriteParent.enabled = true;
		}
		else if (ipManager.items [3].amountOfItem == 0) 
		{
			pistol.SetActive(false);
			isEquip = false;
		}
		if (player.isUsing == false) {
			weaponSpriteParent.enabled = true;
			shootingSpriteParent.enabled = false;
		}

		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && player.usable == true)  
		{
			StartCoroutine (usePoison ());
		}
		if (player.direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			shootingSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, -90);
			weaponSpriteParent.transform.localRotation = newRot;	
			weaponSpriteParent.transform.localPosition = forwardPos;
			DamageCollider2D.offset = new Vector2 (3, -.25f);
			DamageCollider2D.size = new Vector2 (5f, .5f);
		}
		if (player.direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			shootingSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (0, 0, 90);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = backPos;
			DamageCollider2D.offset = new Vector2 (3, -.25f);
			DamageCollider2D.size = new Vector2 (5f, .5f);
				
		}
		if (player.direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			shootingSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (180, 0, 180);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (3, 0);
			DamageCollider2D.size = new Vector2 (5f, .5f);

		}
		if (player.direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			shootingSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (3, 0);
			DamageCollider2D.size = new Vector2 (5f, .5f);

		}
	}

	public void attack()
	{
		realDamage = Random.Range (minDamage, maxDamage);
		foreach (Entity e in enemyInRange) 
		{
			e.takeHealth (realDamage);
		}
		AudioSource shoot = GetComponent<AudioSource> ();
		shoot.Play ();

	}

	IEnumerator flashSprite()
	{
		attack ();
		weaponSpriteParent.enabled = false;
		shootingSpriteParent.enabled = true;
		yield return new WaitForSeconds (.1f);
		weaponSpriteParent.enabled = true;
		shootingSpriteParent.enabled = false;
	}
	IEnumerator usePoison()
	{
		if (ipManager.items [3].amountOfItem > 0) {
			StartCoroutine (flashSprite ());
		} 
		yield return new WaitForSeconds (.02f);
		ipManager.removeItemFromInventory (5, 1);
	}

	void OnTriggerEnter2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			if (tempEnt.isHostile) 
			{
				if (enemyInRange.Contains (tempEnt))
					return;
				enemyInRange.Add (tempEnt);
			}
		}
	}

	void OnTriggerExit2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			int index = enemyInRange.IndexOf (tempEnt);
			enemyInRange.Remove (enemyInRange[index]);
		}
	}
}
