﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class ItemPlayerManager : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;

	public ItemManager iManager;

	public List<inventory> items = new List<inventory>();

	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update () 
	{

	}

	public void addToItemInventory(int itemId, int amount)
	{
		if (player.refreshingInv == false) {
			if (itemId == 1)
				player.poisons += amount;
			if (itemId == 3)
				player.potions += amount;
			if (itemId == 5)
				player.pistols += amount;
			if (itemId == 6)
				player.keys += amount;
			if (itemId == 10)
				player.energyPots += amount;
		}
	
		for(int i = 0; i < iManager.items.Count; i++)
		{
			if(iManager.items[i].itemTransform.GetComponent<Item>().id == itemId)
			{
				bool isItemInList = false;
				int index = 0;
				for(int j = 0; j < items.Count; j++)
				{
					if(items[j].item.id == itemId)
					{
						isItemInList = true;
						index = j;

					}
				}

				if(isItemInList)
				{
					items[index].amountOfItem += amount;
					if (items [index].amountOfItem > 50)
						items [index].amountOfItem = 50;
			
				}
				else
				{
					inventory inv = new inventory(iManager.items[i].itemTransform.GetComponent<Item>(), amount);
					items.Add (inv);
					if (player.refreshingInv == false) {
						if (itemId == 2)
							player.ironSwords += amount;
						if (itemId == 4)
							player.boStaffs += amount;
						if (itemId == 7)
							player.sabers += amount;
						if (itemId == 8)
							player.forceFields += amount;
						if (itemId == 9)
							player.incorpreals += amount;
					}
				}


			}
		}
	}

	public void removeItemFromInventory(int itemId, int amount)
	{
		if (itemId == 1)
			player.poisons -= amount;
		if (itemId == 2)
			player.ironSwords -= amount;
		if (itemId == 3)
			player.potions -= amount;
		if (itemId == 4)
			player.boStaffs -= amount;
		if (itemId == 5)
			player.pistols -= amount;
		if (itemId == 6)
			player.keys -= amount;
		if (itemId == 7)
			player.sabers -= amount;
		if (itemId == 8)
			player.forceFields -= amount;
		if (itemId == 9)
			player.incorpreals -= amount;
		if (itemId == 10)
			player.energyPots -= amount;
		for(int i = 0; i < iManager.items.Count; i++)
		{
			if(iManager.items[i].itemTransform.GetComponent<Item>().id == itemId)
			{
				bool isItemInList = false;
				int index = 0;
				for(int j = 0; j < items.Count; j++)
				{
					if(items[j].item.id == itemId)
					{
						isItemInList = true;
						index = j;
					}
				}
				if(isItemInList)
				{
					items [index].amountOfItem -= amount;
					if (items [index].amountOfItem < 0)
						items [index].amountOfItem = 0;
				}
			}
		}
	}
}

[System.Serializable]
public class inventory
{
	public Item item;
	public float amountOfItem;

	public inventory(Item item, int itemQuant)
	{
		this.item = item;
		this.amountOfItem = itemQuant;
	}
}

