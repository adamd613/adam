﻿using UnityEngine;
using System.Collections;

public class SceneLoader : MonoBehaviour {

	public string sceneName;
	public string sceneDescription;
	public bool onScene = false;
	public int id;


	public GameObject associatedLevel;

	void Start () {
	
	}
	
	void Update () {
	
	}

	public void loadScene()
	{

		if (Input.GetKeyDown (KeyCode.E)) 
		{
			onScene = true;
		}
	}
}
