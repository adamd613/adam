﻿using UnityEngine;
using System.Collections;

public class LoadGame : SceneLoader {


	void Start ()
	{

	}

	void Update () 
	{
		if (onScene == true)
			loadLevel();

	}

	void loadLevel() 
	{
		Application.LoadLevel("Menu");
	}
}