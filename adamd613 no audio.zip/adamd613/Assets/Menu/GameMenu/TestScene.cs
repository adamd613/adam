﻿using UnityEngine;
using System.Collections;

public class TestScene : SceneLoader {

	void Start () {
	
	}
	
	void Update () 
	{
		if (onScene == true)
			loadLevel();
			
	}

	void loadLevel() 
	{
		Application.LoadLevel("Test Scene");
	}
}
