﻿using UnityEngine;
using System.Collections;

public class LevelOne : SceneLoader {

	public GameObject thisPlayer;
	public Entity player;
	public HUDController HUD;

	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
			HUD = thisPlayer.GetComponent<HUDController> ();

		}
	}

	void Update () 
	{
		if (onScene == true)
			loadLevel();

	}

	void loadLevel() 
	{
		HUD.enabled = true;
		player.transform.position = new Vector3(116, 12, 0);
		Application.LoadLevel("Level One");
	}
}