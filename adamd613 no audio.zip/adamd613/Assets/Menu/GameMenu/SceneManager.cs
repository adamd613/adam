﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class SceneManager : MonoBehaviour {

	public List<Scenes> levels = new List<Scenes>();

	void Start () {
		//DontDestroyOnLoad(gameObject);
	}


	void Update () {

	}
}

[System.Serializable]
public class Scenes
{
	public Transform sceneTransform;
}