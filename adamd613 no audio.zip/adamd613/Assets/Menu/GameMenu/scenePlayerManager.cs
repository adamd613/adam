﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class scenePlayerManager : MonoBehaviour {

	public SceneManager sManager;

	public List<sceneven> levels = new List<sceneven>();

	void Start () {

	}

	void Update () 
	{

	}

	public void addSceenToLoader(int sceneId, int amount)
	{
		for(int i = 0; i < sManager.levels.Count; i++)
		{
			if(sManager.levels[i].sceneTransform.GetComponent<SceneLoader>().id == sceneId)
			{
				bool isItemInList = false;
				int index = 0;
				for(int j = 0; j < levels.Count; j++)
				{
					if(levels[j].level.id == sceneId)
					{
						isItemInList = true;
						index = j;
					}
				}
				if(isItemInList)
				{
					levels[index].amountOfScene += amount;

				}
				else
				{
					sceneven inv = new sceneven(sManager.levels[i].sceneTransform.GetComponent<SceneLoader>(), amount);
					levels.Add (inv);
				}
			}
		}
	}

	public void removeSceneFromLoader(int sceneId, int amount)
	{
		for(int i = 0; i < sManager.levels.Count; i++)
		{
			if(sManager.levels[i].sceneTransform.GetComponent<SceneLoader>().id == sceneId)
			{
				bool isItemInList = false;
				int index = 0;
				for(int j = 0; j < levels.Count; j++)
				{
					if(levels[j].level.id == sceneId)
					{
						isItemInList = true;
						index = j;
					}
				}
				if(isItemInList)
				{
					levels [index].amountOfScene -= amount;
					if (levels [index].amountOfScene < 0)
						levels [index].amountOfScene = 0;
				}
			}
		}
	}
}

[System.Serializable]
public class sceneven
{
	public SceneLoader level;
	public float amountOfScene;

	public sceneven(SceneLoader level, int sceneQuant)
	{
		this.level = level;
		this.amountOfScene = sceneQuant;
	}
}

