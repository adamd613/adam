﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class menuScreen : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;

	public GUISkin guiSKIN;

	public scenePlayerManager spM;

	private int currentlySelected;
	private int maxSelected;

	void Start () {
		currentlySelected = 1;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update () {
		
			Time.timeScale = 0.0f;

		if (Input.GetKeyDown (KeyCode.S) || Input.GetKeyDown (KeyCode.DownArrow)) 
		{
			if(maxSelected > 1)
			{
				if(currentlySelected == maxSelected)
				{
					currentlySelected = 1;
				}
				else
				{
					currentlySelected++;
				}
			}
		}
		if (Input.GetKeyDown (KeyCode.W) || Input.GetKeyDown (KeyCode.UpArrow))
		{
			if(maxSelected > 1)
			{
				if(currentlySelected == 1)
				{
					currentlySelected = maxSelected;
				}
				else
				{
					currentlySelected--;
				}
			}
		}
	}

	void OnGUI()
	{
		GUI.skin = guiSKIN;


		Selection();
	}

	void Selection()
	{
		GUI.Box (new Rect(0, 0, Screen.width, Screen.height), "", "Menu");

		List<sceneven> playerScenes = spM.levels;

		maxSelected = playerScenes.Count;

		for (int i = 1; i < playerScenes.Count + 1; i++) 
		{
			if (i == currentlySelected) 
			{
				GUI.color = new Color (15.0f, 0.0f, 0.0f);
				GUI.Label (new Rect (Screen.width - ((Screen.width / 100f) * 50f) + 10, (i * 20), 500, 30), playerScenes [i - 1].level.sceneName);

				GUI.color = new Color (0.0f, 15.0f, 0.0f);
				GUI.Label (new Rect (20, Screen.height - ((Screen.height / 100f) * 25f) + 20, 800, 30), playerScenes [i - 1].level.sceneDescription);

				GUI.color = new Color (150.0f, 0.0f, 150.0f);
				GUI.Label (new Rect (Screen.width - ((Screen.width / 100f) * 100f) + 10, 20, 500, 30), "[Scene Selection]");

				GUI.color = new Color (200.0f, 200.0f, 200.0f);
				GUI.Label (new Rect (Screen.width - ((Screen.width / 100f) * 100f) + 10, 60, 500, 30), "Use 'W' and 'S' to select scenes.");

				GUI.color = new Color (200.0f, 200.0f, 200.0f);
				GUI.Label (new Rect (Screen.width - ((Screen.width / 100f) * 100f) + 10, 100, 500, 30), "Press 'E' to select.");

				if (Input.GetKeyDown (KeyCode.E)) {
					playerScenes [i - 1].level.loadScene ();
				}
			}
			else
			{
				GUI.color = new Color(200.0f, 200.0f, 200.0f);
				GUI.Label (new Rect (Screen.width - ((Screen.width / 100f) * 50f) + 10, (i * 20), 500, 30), playerScenes [i - 1].level.sceneName);
			}
		}
	}
}
