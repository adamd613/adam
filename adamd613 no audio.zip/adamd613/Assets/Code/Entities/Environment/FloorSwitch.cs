﻿using UnityEngine;
using System.Collections;

public class FloorSwitch : MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;

	public FollowerMob mark;
	public GameObject thisMark;

	public SpriteRenderer onSprite;
	public SpriteRenderer offSprite;

	public bool isOn;

	void Start () {
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisPlayer.GetComponent<FollowerMob> ();
		} 
	}

	void Update () {
	
	}
	void OnTriggerStay2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<FollowerMob>() != null)
		{

			isOn = true;
			offSprite.enabled = false;
			onSprite.enabled = true;

		}
	}
	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<FollowerMob>() != null)
		{
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();

		}
	}
	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null || col.GetComponent<FollowerMob>() != null)
		{
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();

			isOn = false;
			offSprite.enabled = true;
			onSprite.enabled = false;

		}
	}
}
