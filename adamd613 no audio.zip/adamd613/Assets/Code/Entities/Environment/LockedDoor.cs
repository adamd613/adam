﻿using UnityEngine;
using System.Collections;

public class LockedDoor : MonoBehaviour {

	public GameObject thisPlayer;
	public ItemPlayerManager ipManager;
	public GameObject Door;

	public bool locked = true;

	void Start () 
	{

		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		ipManager = thisPlayer.GetComponent<ItemPlayerManager> ();

	}

	void Update () 
	{
		if (locked == false)
			Unlock ();
		
	}

	public void Unlock()
	{
		Destroy (gameObject);
		ipManager.removeItemFromInventory (6, 1);
	}

}
