﻿using UnityEngine;
using System.Collections;

public class MobsDeadDoor : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;
	public GameObject Door;

	public GameObject MobOne;
	public GameObject MobTwo;
	public GameObject MobThree;
	public GameObject MobFour;
	public GameObject MobFive;
	public GameObject MobSix;
	public GameObject MobSeven;

	public int thisProg;

	public bool locked = true;


	void Start () 
	{

		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		player = thisPlayer.GetComponent<Player> ();

	}

	void Update ()
	{
		if (locked == false)
			Unlock ();

		if (player.progPoint >= thisProg)
			locked = false;

		if (MobOne == null && MobTwo == null && MobThree == null && MobFour == null && MobFive == null && MobSix == null && MobSeven == null)
			locked = false;
	}

	public void Unlock()
	{
		Destroy (gameObject);
	}


}
