﻿using UnityEngine;
using System.Collections;

public class SwitchDoor : MonoBehaviour {

	public GameObject thisPlayer;
	public Player player;
	public GameObject Door;

	public FloorSwitch switchOne;
	public FloorSwitch switchTwo;

	public int thisProg;



	public bool locked = true;

	void Start () 
	{

		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		player = thisPlayer.GetComponent<Player> ();

	}

	void Update ()
	{
		if (locked == false)
			Unlock ();

		if (player.progPoint >= thisProg)
			locked = false;

		if (switchOne.isOn == true && switchTwo.isOn == true) {
			locked = false;
		}
	}
	
	public void Unlock()
	{
		Destroy (gameObject);
	}
}
