﻿using UnityEngine;
using System.Collections;

public class LoganBoss: Entity {

	public GameObject lazers;
	public GameObject DeathLog;
	public GameObject prizeChest;

	public GameObject thisOldLogan;
	public AttackingLogan oldLogan;
	public GameObject thisPlayer;
	public Entity attacking;
	public Player loot;
	public Animator animator;

	public EndingDialogue dialogueOne;
	public EndingDialogue dialogueTwo;

	public GameObject deadSprite;

	public bool lefting;
	public bool downing;
	public bool righting;
	public bool upping;

	void Start () {

		lefting = false;
		downing = false;
		righting = false;
		upping = false;

		animator = GetComponent<Animator> ();
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			attacking = thisPlayer.GetComponent<Entity> ();
			loot = thisPlayer.GetComponent<Player> ();
		} 
		transform.position = new Vector3(oldLogan.transform.position.x, oldLogan.transform.position.y, oldLogan.transform.position.z);
		oldLogan = thisOldLogan.GetComponent<AttackingLogan> ();
		StartCoroutine (RunningAway ());
	}

	void Update ()
	{
		if (lefting == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
			animator.Play ("WalkLeft");
			StartCoroutine (stopping ());
		}
		if (downing == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			animator.Play ("WalkDown");
			StartCoroutine (stopping ());
		}
		if (righting == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			animator.Play ("WalkRight");
			StartCoroutine (stopping ());
		}
		if (upping == true) {
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			animator.Play ("WalkUp");
			StartCoroutine (stopping ());
		}
		if (dialogueOne.textNum >= 1) {
			dialogueOne.toggleOff ();
		}
		if (dialogueTwo.textNum >= 5) {
			dialogueTwo.enabled = false;
		}

		{
			if (attacking.health <= 0)
				health = maxHealth;
			
			if (health <= 0)
				Die ();
		}
	}
		
	IEnumerator RunningAway()
	{
		lefting = !lefting;
		yield return new WaitForSeconds (2f);
		lazers.SetActive (true);
		yield return new WaitForSeconds (3f);
		lefting = !lefting;
		downing = !downing;
		yield return new WaitForSeconds (1f);
		downing = !downing;
		speed = 4;
		StartCoroutine (Waiting ());
	}

	IEnumerator Waiting()
	{
		
		downing = !downing;
		yield return new WaitForSeconds (2.5f);
		downing = !downing;
		if (GetComponent<Rigidbody2D> ().isKinematic == false){
			GetComponent<Rigidbody2D> ().isKinematic = true;
	}
		righting = !righting;
		yield return new WaitForSeconds (2.7f);
		righting = !righting;
		upping = !upping;
		yield return new WaitForSeconds (2.5f);
		upping = !upping;
		lefting = !lefting;
		yield return new WaitForSeconds (2.7f);
		lefting = !lefting;
		StartCoroutine (Waiting ());
	}

		


	public void Die()
	{
		GetComponent<Rigidbody2D> ().isKinematic = false;
		spriteParent.enabled = false;
		deadSprite.SetActive (true);
		dialogueOne.enabled = false;
		transform.position = new Vector3(155, 47, 0);
		lazers.SetActive (false);
		DeathLog.SetActive (true);
		prizeChest.SetActive (true);
		animator.enabled = false;
		GetComponent<Rigidbody2D> ().isKinematic = true;
		int add = Random.Range (100, 200);
		loot.maxHealth += 25;
		loot.addMoney (add);
		Dead ();
	}
	public void Dead()
	{
		enabled = false;
	}
	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
}

