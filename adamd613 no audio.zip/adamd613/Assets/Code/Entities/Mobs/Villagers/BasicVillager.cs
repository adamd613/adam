﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class BasicVillager : Villager {

	public Transform target;
	public List<ListOfShops> listOfShops = new List<ListOfShops>();
	public Transform shop;

	public bool goToTarget = false;
	public bool goHome = false;
	public bool generateTarget = false;

	public Animator animator;


	public int distance;

	void Start () 
	{
		shop = GameObject.FindGameObjectWithTag ("Shop").transform;
		animator = GetComponent<Animator> ();
	}

	void Update () 
	{
		if (direction == 0 && moving == true)
		{
			animator.Play ("WalkDown");
		}
		if (direction == 1 && moving == true)
		{
			animator.Play ("WalkUp");
		}
		if (direction == 2 && moving == true)
		{
			animator.Play ("WalkLeft");
		}
		if (direction == 3 && moving == true)
		{
			animator.Play ("WalkRight");
		}

		if(goToTarget == true)
			GoToTarget();
		else if(goHome == true)
			GoHome();
		else if(generateTarget == true)
			StartCoroutine(GenerateTarget());
	}

	IEnumerator GenerateTarget()
	{
		generateTarget = false;
		yield return new WaitForSeconds(1);
		int r = Random.Range(0, 100);
		if(r > 70)
			newShopTarget();
		generateTarget = true;
	}

	public void newShopTarget()
	{
		//int j = Random.Range(0, listOfShops.Count);
		target = shop;
		goToTarget = true;
	}

	public void GoToTarget()
	{
		
		if(Vector2.Distance(transform.position, target.position) < 4)
		{
			goHome = true;
			goToTarget = false;
			//target = null;

		}

		if (target.transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			direction = 1;
			StartCoroutine (stopping());
		}
		if (target.transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y)) 
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;	
			direction = 0;
			StartCoroutine (stopping());
		} 
		if (target.transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x))
		{ 
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			direction = 3;
			StartCoroutine (stopping());
		}
		if (target.transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			direction = 2;
			StartCoroutine (stopping());
		}
	}

	public void GoHome()
	{
		if (home.transform.position.y > (GetComponent<Rigidbody2D> ().transform.position.y + distance))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;	
			direction = 1;
			StartCoroutine (stopping());
		}
		if (home.transform.position.y < (GetComponent<Rigidbody2D> ().transform.position.y - distance)) 
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			direction = 0;
			StartCoroutine (stopping());
		} 
		if (home.transform.position.x > (GetComponent<Rigidbody2D> ().transform.position.x + distance))
		{ 
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;	
			direction = 3;
			StartCoroutine (stopping());
		}
		if (home.transform.position.x < (GetComponent<Rigidbody2D> ().transform.position.x - distance))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;	
			direction = 2;
			StartCoroutine (stopping());
		}
		if (Vector2.Distance (transform.position, home.position) < 6) 
		{
			goHome = false;
		}
	}
	IEnumerator stopping()
	{
		moving = true;
		yield return new WaitForSeconds (1);
		moving = false;
	}
}

[System.Serializable]
public class ListOfShops
{
	public string shopName;
	public Transform shopT;
}
