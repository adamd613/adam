﻿using UnityEngine;
using System.Collections;

public class Villager : Entity {

	public Transform home;
	public string firstname;
	public string lastname;

	void Start () {

	}

	void Update () {

	}
}