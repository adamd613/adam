﻿using UnityEngine;
using System.Collections;

public class MarkHUD: MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public GameObject holding;

	public FollowerMob thisMark;
	public CircleCollider2D PlayerCollider;

	public bool playerInRange;
	public bool isInInventory;
	public bool isShopOpen;

	public GUISkin gskin;

	void Start () 
	{
		playerInRange = false;
		isShopOpen = false;
		isInInventory = false;
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if (holding == null) {
			holding = GameObject.FindGameObjectWithTag ("Holding");
		}
	}

	void Update () 
	{
		if (player.progPoint <= 6) {
			enabled = false;
		}

		if(playerInRange)
		{
			if(Input.GetKeyDown(KeyCode.E))
				isShopOpen = !isShopOpen;
			if(Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
				isInInventory = !isInInventory;
			if (isShopOpen == true) 
			{
				holding.SetActive (false);
			}
			if (isShopOpen == false) 
			{
				holding.SetActive (true);
			}
		}
	}

	void OnTriggerEnter2D(Collider2D c)
	{
		if(c.tag == "Player" && playerInRange == false)
		{
			playerInRange = true;
		//	player = c.GetComponent<Player>();
		}
	}

	void OnTriggerExit2D(Collider2D c)
	{
		if(c.tag == "Player" && playerInRange)
		{
			playerInRange = false;
			//player = null;
			isShopOpen = false;
			holding.SetActive (true);
		}
	}

	void OnGUI()
	{
		GUI.skin = gskin;
		if (!isInInventory) 
		{


			if (playerInRange && !isShopOpen) 
			{
				GUI.color = new Color(15.0f, 0.0f, 0.0f);
				GUI.Label (new Rect (5, 5, 500, 100), "Press e to interact with Mark" );
			}

			if (isShopOpen) 
			{
				GUILayout.BeginArea (new Rect ((Screen.width / 2) - 250, 100, 500, Screen.height - 200), GUIContent.none, "box");
				GUILayout.BeginVertical ();
				GUILayout.BeginHorizontal (GUILayout.Width (500));
				GUILayout.Label ("Do you want Mark to stay here?");
				GUILayout.Space (20);
				GUILayout.EndHorizontal ();
				GUILayout.BeginHorizontal (GUILayout.Width (500));

				if (GUILayout.Button ("Yes")) 
				{
					thisMark.range = .5f;
					thisMark.distance = .5f;
					isShopOpen = !isShopOpen;
				}

				GUILayout.Space (20);

				if (GUILayout.Button ("no")) 
				{
					thisMark.range = 5;
					thisMark.distance = 2;
					isShopOpen = !isShopOpen;
				}

				GUILayout.Space (20);

				GUILayout.EndHorizontal ();

				GUILayout.EndVertical ();

				GUILayout.EndArea ();
			}

		}
	}
}
