﻿using UnityEngine;
using System.Collections;

public class GhostNPC: Entity {

	public GameObject thisPlayer;

	public Player player;
	//public SpriteRenderer weaponSpriteParent;
	public CircleCollider2D DamageCollider2D;

	public GameObject spider;

	public bool isDead;
	public bool turnUp;
	public bool turnDown;

	public GameObject teleport;
	public SpriteRenderer mainSprite;
	public GameObject upSprite;
	public GameObject downSprite;

	public GameObject dialogue;

	public bool canPort;

	void Start () {

	
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

	}

	void Update ()
	{
		
		if (isHostile == false) {
			armor = 100;
		}
		if (isHostile == true) {
			armor = 0;
		}
			

	}
	void OnTriggerEnter2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{
			if (player.shadowsOn == false) 
			{
				if (turnUp == true) {
					mainSprite.enabled = false;
					upSprite.SetActive (true);
				}
				if (turnDown == true) {
					mainSprite.enabled = false;
					downSprite.SetActive (true);
				}
			} 

			if (player.shadowsOn == true && canPort == false)
			{
				StartCoroutine (porting ());
			}
		}
	}

	void OnTriggerExit2D (Collider2D col)
	{
		if (col.GetComponent<Player> () != null)
		{

		}
	}	


	IEnumerator porting()
	{
		dialogue.SetActive (false);
		canPort = true;
		mainSprite.enabled = false;
		upSprite.SetActive (false);
		downSprite.SetActive (false);
		teleport.SetActive (true);
		yield return new WaitForSeconds (.4f);
		teleport.SetActive (false);
		spider.SetActive (true);


	}


}

