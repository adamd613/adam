﻿using UnityEngine;
using System.Collections;

public abstract class Entity : MonoBehaviour {

	public float speed;

	public bool isHostile;

	public int energy;
	public int maxEnergy;

	public bool moving;

	public float health;
	public float maxHealth;

	public int direction;

	public bool canSound;

	public bool canCharge;
	public bool isRunCharming;
	public bool isForceFielding;

	public int armor;

	public SpriteRenderer spriteParent;
	public GameObject armorSound;


	void Start () 
	{

		canCharge = true;
		isRunCharming = false;
		isForceFielding = false;
		if(armorSound == null)
		{
			armorSound = GameObject.FindGameObjectWithTag ("newCamera");
		} 

	}
	void OnEnable()
	{
		
		canCharge = true;
		isRunCharming = false;
		isForceFielding = false;

	}



	void Update ()
	{



	}

	public void takeHealth(int amount)
	{
		if (armor < amount) 
		{
			health = health - (amount - armor);
			if (health > 0)
			{
				StartCoroutine (flashDamage ());
			}
		} 
			
		if (canSound == true) 
		{
			if (armor == 0) {

				AudioSource takeDamage = GetComponent<AudioSource> ();
				takeDamage.Play ();
			}
			if (armor > 0) {
				AudioSource block = armorSound.GetComponent<AudioSource> ();
				block.Play ();
			}
		}

	}

	public void addHealth(int amount)
	{
		health = health + amount;
	}

	public void TPToPos(Vector2 pos)
	{
		GetComponent<Rigidbody2D> ().transform.position = pos; 
	}

	IEnumerator flashDamage()
	{
		spriteParent.enabled = false;
		yield return new WaitForSeconds (.1f);
		spriteParent.enabled = true;
	}

	public void nowCharging()
	{
		StartCoroutine (isCharging ());
	
	}

	IEnumerator isCharging()
	{
		canCharge = false;
		energy += 1;
		yield return new WaitForSeconds (.75f);
		canCharge = true;
	}


	public void isRunning(int amount)
	{
		speed = speed + amount;
	}

}