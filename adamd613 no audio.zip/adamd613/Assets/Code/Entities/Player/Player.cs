﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;
using System;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;

public class Player : Entity {
	
	public static Player control;

	public HUDController HUD;

	public ItemPlayerManager ipManager;

	public GameObject Holding;
	public GameObject Equipment;

	public Animator animator;

	public GameObject thisChests;
	public ChestSaver chests;

	public int levelPoint;
	public int progPoint;
	public bool resetChests;

	public int money;

	//public int itemOne;

	public GUISkin gskin;

	public bool playerDead;
	public bool refreshingInv;
	public bool attackAnim;

	public AudioClip takeDamage;

	public int sabers;
	public int poisons;
	public int ironSwords;
	public int potions;
	public int boStaffs;
	public int pistols;
	public int keys;
	public int forceFields;

	public float attackSpeed;

	public bool shadowsOn;
	public bool usable;
	public bool isUsing;

	//public string testLevel;

	void Start () 
	{	
		if(thisChests == null)
		{
			thisChests = GameObject.FindGameObjectWithTag ("ChestSaver");
			chests = thisChests.GetComponent<ChestSaver> ();
		} 

		canSound = true;
		attackAnim = false;
		attackSpeed = .2f;
		isUsing = false;
		usable = true;
		energy = 20;
		speed = 4;
		DontDestroyOnLoad (gameObject);
		playerDead = false;
		HUD = GetComponent<HUDController> ();
		ipManager.addToItemInventory (0, 1);
		ipManager.addToItemInventory (3, 0);
		ipManager.addToItemInventory (1, 0);
		ipManager.addToItemInventory (5, 0);
		ipManager.addToItemInventory (6, 0);
		animator = GetComponent<Animator> ();

	}

	void Update ()
	{
		if (energy < maxEnergy && isRunCharming == false && isForceFielding == false && canCharge == true) 
		{
			nowCharging ();
		}

		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && usable == true) 
		{
			StartCoroutine (usingItem ());
		}


		if (Input.GetKey (KeyCode.W) || Input.GetKey (KeyCode.UpArrow))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.up * speed * Time.deltaTime;
			moving = true;
			direction = 1;
		}
		if (Input.GetKey (KeyCode.S) || Input.GetKey (KeyCode.DownArrow))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.down * speed * Time.deltaTime;
			moving = true;
			direction = 0;
		}
		if (Input.GetKey (KeyCode.A) || Input.GetKey (KeyCode.LeftArrow))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.left * speed * Time.deltaTime;
			moving = true;
			direction = 2;
		}
		if (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow))
		{
			GetComponent<Rigidbody2D> ().transform.position += Vector3.right * speed * Time.deltaTime;
			moving = true;
			direction = 3;
		}

		if (Input.GetKeyUp (KeyCode.D) || Input.GetKeyUp (KeyCode.RightArrow) || Input.GetKeyUp (KeyCode.W) || Input.GetKeyUp (KeyCode.UpArrow) || Input.GetKeyUp (KeyCode.A) || Input.GetKeyUp (KeyCode.LeftArrow) || Input.GetKeyUp (KeyCode.S) || Input.GetKeyUp (KeyCode.DownArrow)) 
		{
			moving = false;
		}


		if (health <= 0)
			Die ();	
		
		if (direction == 0 && (Input.GetKey (KeyCode.S) || Input.GetKey (KeyCode.DownArrow)))
		{
			animator.Play ("WalkDown");
		}
		if (direction == 1 && (Input.GetKey (KeyCode.W) || Input.GetKey (KeyCode.UpArrow))) 
		{
			animator.Play ("WalkUp");
		}
		if (direction == 2 && (Input.GetKey (KeyCode.A) || Input.GetKey (KeyCode.LeftArrow)))
		{
			animator.Play ("WalkLeft");
		}
		if (direction == 3 && (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow)))
		{
			animator.Play ("WalkRight");
		}
		if (health >= maxHealth)
			health = maxHealth;


		if (poisons >= 50)
			poisons = 50;
		if (keys >= 50)
			keys = 50;
		if (ironSwords >= 50)
			ironSwords = 50;
		if (potions >= 50)
			potions = 50;
		if (boStaffs >= 50)
			boStaffs = 50;
		if (pistols >= 50)
			pistols = 50;
		if (sabers >= 50)
			sabers = 50;
		if (forceFields >= 50)
			forceFields = 50;
	
	}

	public void Die()
	{
		print ("I've been killed");
		speed = 0;
		health = 0;
		Holding.SetActive (false);
		Equipment.SetActive (false);
		playerDead = true;
	}

	void OnGUI()
	{
		GUI.skin = gskin;
		if (playerDead == true) {
			GUILayout.BeginArea (new Rect ((Screen.width / 2) - 250, 100, 500, Screen.height - 200), GUIContent.none, "box");
			GUILayout.BeginVertical ();
			GUILayout.BeginHorizontal (GUILayout.Width (500));
			GUILayout.Label ("Awww he dead. Respawn?");
			GUILayout.Space (20);
			GUILayout.EndHorizontal ();
			GUILayout.BeginHorizontal (GUILayout.Width (500));

			if (GUILayout.Button ("Yes")) {
				Respawn ();
			}

			GUILayout.Space (20);

			if (GUILayout.Button ("no")) {
				Destroy (gameObject);
				HUD.enabled = false;
				levelPoint = 0;
				Application.LoadLevel ("Menu");
				health = maxHealth;
				energy = maxEnergy;
				playerDead = false;
				speed = 4;
			}

			GUILayout.Space (20);

			GUILayout.EndHorizontal ();

			GUILayout.EndVertical ();

			GUILayout.EndArea ();
		}
	}
		
	public void addMoney(int am)
	{
		money = money + am;
	}

	public void takeMoney(int am)
	{
		money = money - am;
		if (money < 0)
			money = 0;
	}

	void Awake() 
	{
		if (control == null) {
			DontDestroyOnLoad (gameObject);
			control = this;
		} else if (control != this) {
			Destroy (gameObject);
		}

	}
		
	void Respawn()
	{
		playerDead = false;
		speed = 4;
		energy = 20;
		Holding.SetActive (true);
		Equipment.SetActive (true);
		health = maxHealth;
		if(levelPoint == 0)
		transform.position = new Vector3(116, 12, 0);
		if (levelPoint == 1)
		transform.position = new Vector3 (167, 6, 0);
		if(levelPoint == 2)
		transform.position = new Vector3(15, 28, 0);	
		if(levelPoint == 3)
		transform.position = new Vector3(83, 43, 0);	
		if(levelPoint == 4)
		transform.position = new Vector3(42, 60, 0);	
		if (levelPoint == 5) 
		transform.position = new Vector3(23, 133, 0);		
		if (levelPoint == 6) 
		transform.position = new Vector3(16, 17, 0);
		if (levelPoint == 7) 
		transform.position = new Vector3(83, 43, 0);	
		}





	public void Save()
	{
		BinaryFormatter bf = new BinaryFormatter ();
		FileStream file = File.Create(Application.persistentDataPath + "/playerInfo.dat");

		PlayerData data = new PlayerData ();

		data.levelPoint = levelPoint;
		data.money = money;
		data.maxHealth = maxHealth;
		data.maxEnergy = maxEnergy;
		data.poisons = poisons;
		data.ironSwords = ironSwords;
		data.potions = potions;
		data.boStaffs = boStaffs;
		data.pistols = pistols;
		data.keys = keys;
		data.health = health;
		data.sabers = sabers;
		data.forceFields = forceFields;
		data.progPoint = progPoint;
		data.chestOne = chests.chestOne.isChestLooted;
		data.chestTwo = chests.chestTwo.isChestLooted; 
		data.chestThree = chests.chestThree.isChestLooted;
		data.chestFour = chests.chestFour.isChestLooted; 
		data.chestFive = chests.chestFive.isChestLooted; 
		data.chestSix = chests.chestSix.isChestLooted;
		data.chestSeven = chests.chestSeven.isChestLooted; 
		data.chestEight = chests.chestEight.isChestLooted;
		data.chestNine = chests.chestNine.isChestLooted; 
		data.chestTen = chests.chestTen.isChestLooted; 

		bf.Serialize (file, data);
		file.Close ();
	}

	public void Load()
	{
		if(File.Exists(Application.persistentDataPath + "/playerInfo.dat"))
		{
			BinaryFormatter bf = new BinaryFormatter();
			FileStream file = File.Open(Application.persistentDataPath + "/playerInfo.dat", FileMode.Open);
			PlayerData data = (PlayerData)bf.Deserialize(file);
			file.Close ();

			levelPoint = data.levelPoint;
			money = data.money;
			maxHealth = data.maxHealth;
			maxEnergy = data.maxEnergy;
			health = data.health;
			poisons = data.poisons;
			ironSwords = data.ironSwords;
			potions = data.potions;
			boStaffs = data.boStaffs;
			pistols = data.pistols;
			keys = data.keys;
			sabers = data.sabers;
			forceFields = data.forceFields;
			progPoint = data.progPoint;
			chests.chestOne.isChestLooted = data.chestOne;
			chests.chestTwo.isChestLooted = data.chestTwo;
			chests.chestThree.isChestLooted = data.chestThree;
			chests.chestFour.isChestLooted = data.chestFour;
			chests.chestFive.isChestLooted = data.chestFive;
			chests.chestSix.isChestLooted = data.chestSix;
			chests.chestSeven.isChestLooted = data.chestSeven;
			chests.chestEight.isChestLooted = data.chestEight;
			chests.chestNine.isChestLooted = data.chestNine;
			chests.chestTen.isChestLooted = data.chestTen;

			StartCoroutine (resetTheChests ());

			StartCoroutine (RefreshInv ());

		}
	}
	IEnumerator RefreshInv()
	{
		
		refreshingInv = true;

		if (poisons >= 1)
		{
		ipManager.addToItemInventory (1, poisons);
		}

		if(ironSwords >= 1)
		{
		ipManager.addToItemInventory (2, ironSwords);
		}
	
		if(potions >= 1)
		{
		ipManager.addToItemInventory (3, potions);
		}
	
		if(boStaffs >= 1)
		{
		ipManager.addToItemInventory (4, boStaffs);
		}

		if(pistols >= 1)
		{
		ipManager.addToItemInventory (5, pistols);
		}
		if(keys >= 1)
		{
		ipManager.addToItemInventory (6, keys);
		}

		if(sabers >= 1)
		{
		ipManager.addToItemInventory (7, sabers);
		}

		if(forceFields >= 1)
		{
		ipManager.addToItemInventory (8, forceFields);
		}
		yield return new WaitForSeconds (.01f);
		refreshingInv = false;
	}



	IEnumerator usingItem()
	{
		isUsing = true;
		yield return new WaitForSeconds (.001f);
		usable = false;
		attackAnim = true;
		yield return new WaitForSeconds (attackSpeed);
		isUsing = false;
		usable = true;
		attackAnim = false;
	}

	IEnumerator resetTheChests()
	{
		resetChests = true;
		yield return new WaitForSeconds (.4f);
		resetChests = false;
	}
}

[Serializable]
class PlayerData

{
	public int progPoint;
	public int levelPoint;
	public int money;
	public float maxHealth;
	public float health;
	public int maxEnergy;

	public int poisons;
	public int ironSwords;
	public int potions;
	public int boStaffs;
	public int pistols;
	public int keys;
	public int sabers;
	public int forceFields;

	public int chestOne;
	public int chestTwo;
	public int chestThree;
	public int chestFour;
	public int chestFive;
	public int chestSix;
	public int chestSeven;
	public int chestEight;
	public int chestNine;
	public int chestTen;
}
