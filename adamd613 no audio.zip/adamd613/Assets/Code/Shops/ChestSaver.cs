﻿using UnityEngine;
using System.Collections;

public class ChestSaver : MonoBehaviour {

	public GameObject thisPlayer;

	public Player player;

	public ChestShop chestOne;
	public ChestShop chestTwo;
	public ChestShop chestThree;
	public ChestShop chestFour;
	public ChestShop chestFive;
	public ChestShop chestSix;
	public ChestShop chestSeven;
	public ChestShop chestEight;
	public ChestShop chestNine;
	public ChestShop chestTen;


	public GameObject thisChestOne;
	public GameObject thisChestTwo;
	public GameObject thisChestThree;
	public GameObject thisChestFour;
	public GameObject thisChestFive;
	public GameObject thisChestSix;
	public GameObject thisChestSeven;
	public GameObject thisChestEight;
	public GameObject thisChestNine;
	public GameObject thisChestTen;


	public static ChestSaver control;

	void Awake() 
	{
		if (control == null) {
			DontDestroyOnLoad (gameObject);
			control = this;
		} else if (control != this) {
			Destroy (gameObject);
		}

	}


	void Start ()
	{
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}
	

	void Update () 

	{
		thisPlayer = GameObject.FindGameObjectWithTag ("Player");
		player = thisPlayer.GetComponent<Player> ();

		if(player.levelPoint >= 2 && player.levelPoint <= 4)
		{
			thisChestOne.SetActive(true);
			thisChestTwo.SetActive(true);
			thisChestThree.SetActive(true);
		}
		else
		{
			thisChestOne.SetActive(false);
			thisChestTwo.SetActive(false);
			thisChestThree.SetActive(false);
		}	
		if(player.levelPoint >= 5 && player.levelPoint <= 6)
		{
			thisChestFour.SetActive(true);
			//thisChestFive.SetActive(true);
			//thisChestSix.SetActive(true);
		}
		else
		{
			thisChestFour.SetActive(false);
			//thisChestFive.SetActive(false);
			//thisChestSix.SetActive(false);
		}	
		if(player.levelPoint >= 7 && player.levelPoint <= 9)
		{
			thisChestOne.SetActive(true);
			thisChestTwo.SetActive(true);
			thisChestThree.SetActive(true);
		}
		else
		{
			thisChestOne.SetActive(false);
			thisChestTwo.SetActive(false);
			thisChestThree.SetActive(false);
		}	


	}
}
