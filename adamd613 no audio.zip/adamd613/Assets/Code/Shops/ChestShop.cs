﻿using UnityEngine;
using System.Collections;

public class ChestShop : Shop {

	public GameObject thisPlayer;

	public Player player;

	public bool turnOff;

	public int isChestLooted;

	public int totalItems;

	void Start () 
	{
	
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	}

	void Update ()
	{
		if (isChestLooted == 1) {
			if (player.resetChests == true) {
				sellingItems.Clear ();
			}
		}
		if (turnOff == true)
			gameObject.SetActive (false);
		
		if(sellingItems.Count < totalItems)
			isChestLooted = 1;
	}
}
