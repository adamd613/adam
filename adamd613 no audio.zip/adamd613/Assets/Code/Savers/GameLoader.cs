﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameLoader: MonoBehaviour {

	public Player player;
	public GameObject thisPlayer;
	public HUDController HUD;

	public GUISkin guiSKIN;


	void Start () {
		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			HUD = thisPlayer.GetComponent<HUDController> ();
		} 
		HUD.enabled = false;

	}

	void Update () 
	{
		if (player.levelPoint == 2) 
		{
			HUD.enabled = true;
			player.transform.position = new Vector3(15, 28, 0);
			Application.LoadLevel("Level Two");
		}
		if (player.levelPoint == 3) 
		{
			HUD.enabled = true;
			player.transform.position = new Vector3(83, 43, 0);	
			Application.LoadLevel("Level Two");
		}
		if (player.levelPoint == 5) 
		{
			HUD.enabled = true;
			player.transform.position = new Vector3(23, 133, 0);		
			Application.LoadLevel("Level Three");
		}
		if (player.levelPoint == 6) 
		{
			HUD.enabled = true;
			player.transform.position = new Vector3(16, 17, 0);		
			Application.LoadLevel("Level Three");
		}
		if (player.levelPoint == 7) 
		{
			HUD.enabled = true;
			player.transform.position = new Vector3(83, 43, 0);	
			Application.LoadLevel("Level Four");
		}
	}

	void OnGUI()
	{
		GUI.skin = guiSKIN;

		{

		
			GUILayout.BeginArea (new Rect ((Screen.width / 2) - 250, 100, 500, Screen.height - 200));
				GUILayout.BeginVertical ();
				GUILayout.BeginHorizontal (GUILayout.Width (500));
				GUI.color = new Color (0.0f, 15.0f, 0.0f);
				GUILayout.Label ("Welcome to the game dawg!");
				GUILayout.Space (20);
				GUILayout.EndHorizontal ();
				GUILayout.BeginHorizontal (GUILayout.Width (500));

				if (GUILayout.Button ("Load Game")) 
				{
				
					player.Load ();
				}

				GUILayout.Space (20);

				if (GUILayout.Button ("New Game")) 
			
				{
	
				HUD.enabled = true;
				player.transform.position = new Vector3(116, 12, 0);
				Application.LoadLevel("Level One");

				}
				
				GUILayout.Space (20);

				GUILayout.EndHorizontal ();

				GUILayout.EndVertical ();

				GUILayout.EndArea ();


		}
	}
}
