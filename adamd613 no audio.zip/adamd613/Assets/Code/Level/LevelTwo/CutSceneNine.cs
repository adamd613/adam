﻿using UnityEngine;
using System.Collections;

public class CutSceneNine: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject thisPat;
	public FollowerMob pat;
	public Player player;
	public EndingDialogue dialogue;
	public GameObject holding;
	public GameObject nextScene;

	public bool righting;


	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
	
	}

	void Update ()
	{


		if (player.progPoint == 2) 
		{
			cutScene.SetActive (true);
			thisPat.SetActive (true);
		}

		if (player.progPoint != 2) 
		{
			cutScene.SetActive (false);
			thisPat.SetActive (false);
		}
			
		if (righting == true) {
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			pat.animator.Play ("WalkRight");
		}


		if (dialogue.textNum >= 4) 
		{
			StartCoroutine (walkThrough ());
			StartCoroutine (ending ());

		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{

			holding.SetActive (false);
			player.enabled = false;

		}
	}
		

	IEnumerator walkThrough()
	{
		righting = true;
		yield return new WaitForSeconds (1.8f);
		righting = false;
	}


	IEnumerator ending()
	{
		yield return new WaitForSeconds (2f);
		thisPat.SetActive (false);
		player.enabled = true;
		holding.SetActive (true);
		nextScene.SetActive (true);
		player.progPoint = 3;
	}
}

