﻿using UnityEngine;
using System.Collections;

public class CutSceneSeven: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject thisPat;
	public FollowerMob pat;
	public Player player;
	public EndingDialogue dialogue;
	public GameObject holding;
	public GameObject nextScene;
	public bool moving;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{
		if (moving == true) {
			pat.animator.Play ("WalkUp");
		}
		if (player.progPoint >= 1) 
		{
			thisPat.SetActive (false);
			cutScene.SetActive (false);
		}

		if (dialogue.textNum == 4) 
		{
			moving = true;
			AudioSource trapMusic = GetComponent<AudioSource>();
			trapMusic.Pause();

		}
		if (dialogue.textNum == 5) 
		{
			moving = false;
		}

		if (dialogue.textNum >= 11) 
		{
			dialogue.toggleOff ();
			StartCoroutine (PeaceOut ());
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			pat.animator.Play ("WalkDown");
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			thisPat.SetActive (true);

			holding.SetActive (false);

			player.enabled = false;
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}


	IEnumerator PeaceOut()
	{
		yield return new WaitForSeconds (3f);

		player.enabled = true;
		levelManager.GetComponent<AudioSource> ().UnPause();
		holding.SetActive (true);
		yield return new WaitForSeconds (.2f);

		player.progPoint = 1;
		nextScene.SetActive (true);

	}
}

