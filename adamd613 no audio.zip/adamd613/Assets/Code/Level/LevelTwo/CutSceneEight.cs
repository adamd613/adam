﻿using UnityEngine;
using System.Collections;

public class CutSceneEight: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject thisPat;
	public FollowerMob pat;
	public Player player;
	public EndingDialogue dialogue;
	public GameObject thisSecondDia;
	public EndingDialogue secondDialogue;
	public GameObject holding;
	public bool bothDead;
	public GameObject attackAnim;
	public GameObject thisDoor;
	public GameObject nextScene;

	public bool lefting;
	public bool upping;

	public AttackingMob EnemyOne;
	public AttackingMob EnemyTwo;

	public bool killing;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{
			

		if (player.progPoint == 1) 
		{
			cutScene.SetActive (true);
			thisPat.SetActive (true);
		}

		if (player.progPoint != 1) 
		{
			cutScene.SetActive (false);
			thisPat.SetActive (false);
		}
			
		if (killing == true)
		{
			EnemyOne.takeHealth (1);
			EnemyTwo.takeHealth (1);
		}

		if (lefting == true) {
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			pat.animator.Play ("WalkLeft");
		}
		if (upping == true) {
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			pat.animator.Play ("WalkUp");
		}
			

		if (dialogue.textNum >= 7) 
		{
			
			if (killing == false) {
				StartCoroutine (killMobs ());
			}


		}
		if (secondDialogue.textNum >= 4) 
		{
			StartCoroutine (ending ());

		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{

			holding.SetActive (false);

			player.enabled = false;
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator killMobs()
	{
		if (EnemyOne.health > 0 || EnemyTwo.health > 0) {
			attackAnim.SetActive (true);
			killing = true;
			yield return new WaitForSeconds (4f);
			killing = false;
		} else {
			dialogue.textNum = 0;
			attackAnim.SetActive (false);
			dialogue.turnOff ();
			StartCoroutine (walkThrough ());
			StopCoroutine (killMobs ());
		}
	


	}

	IEnumerator walkThrough()
	{
		

		lefting = true;
		yield return new WaitForSeconds (1.5f);
		lefting = false;
		thisSecondDia.SetActive (true);

	}


	IEnumerator ending()
	{
		thisDoor.SetActive (false);
		yield return new WaitForSeconds (.5f);
		upping = true;
		yield return new WaitForSeconds (4f);
		upping = false;
		//yield return new WaitForSeconds (.2f);

	
		thisSecondDia.SetActive (false);
		thisPat.SetActive (false);
		player.enabled = true;
		holding.SetActive (true);
		levelManager.GetComponent<AudioSource> ().UnPause();
		nextScene.SetActive (true);
		player.progPoint = 2;


	


	}
}

