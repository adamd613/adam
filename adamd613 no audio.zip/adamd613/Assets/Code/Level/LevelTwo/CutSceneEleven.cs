﻿using UnityEngine;
using System.Collections;

public class CutSceneEleven: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject thisPat;
	public FollowerMob pat;
	public Player player;
	public EndingDialogue dialogue;
	public GameObject thisSecondDia;
	public EndingDialogue secondDialogue;
	public GameObject holding;
	public bool bothDead;
	public GameObject attackAnim;
	public GameObject teleOut;
	public GameObject nextScene;
	public SpriteRenderer patSprite;
	public bool stopKilling;
	public Collider2D thisCollider;


	public bool lefting;
	public bool upping;

	public AttackingMob EnemyOne;
	public AttackingMob EnemyTwo;
	public AttackingMob EnemyThree;

	public bool killing;
	public bool canKill;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{


		if (player.health <= 0) {
			levelManager.GetComponent<AudioSource> ().UnPause ();
			stopKilling = true;
			EnemyOne.health = 0;
			EnemyTwo.health = 0;
			EnemyThree.health = 0;
			player.enabled = true;
			attackAnim.SetActive (false);
			thisCollider.enabled = false;
			canKill = true;
			StartCoroutine (ending ());
		}
			

		if (player.progPoint == 4) 
		{
			cutScene.SetActive (true);
			thisPat.SetActive (true);
		}

		if (player.progPoint != 4) 
		{
			cutScene.SetActive (false);
			thisPat.SetActive (false);
		}
			
		if (lefting == true) {
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			pat.animator.Play ("WalkLeft");
		}
		if (upping == true) {
			pat.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			pat.animator.Play ("WalkUp");
		}


		if (dialogue.textNum >= 3) 
		{

			if (canKill == false)
			{
				StartCoroutine (killMobs ());
			}


		}
		if (secondDialogue.textNum >= 1) 
		{
			StartCoroutine (ending ());

		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator killMobs()
	{
		
		attackAnim.SetActive (true);
		if (player.health < 0 ||(EnemyOne.health > 0 || EnemyTwo.health > 0 || EnemyThree.health > 0)& stopKilling == false)
		{
			canKill = true;
			yield return new WaitForSeconds (.5f);
			EnemyOne.takeHealth (8);
			EnemyTwo.takeHealth (8);
			EnemyThree.takeHealth (8);
			player.takeHealth (10);
			canKill = false;

		}
		else 
		{
			
			StartCoroutine (walkThrough ());
			StopCoroutine (killMobs ());
			dialogue.textNum = 0;
			attackAnim.SetActive (false);
			dialogue.turnOff ();
		}



	}

	IEnumerator walkThrough()
	{
		lefting = true;
		yield return new WaitForSeconds (1.5f);
		lefting = false;
		thisSecondDia.SetActive (true);

	}


	IEnumerator ending()
	{

		yield return new WaitForSeconds (.5f);
		thisSecondDia.SetActive (false);
		teleOut.SetActive (true);
		patSprite.enabled = false;
		yield return new WaitForSeconds (.4f);
		thisPat.SetActive (false);
		player.enabled = true;
		holding.SetActive (true);
		levelManager.GetComponent<AudioSource> ().UnPause();
		nextScene.SetActive (true);
		player.progPoint = 5;

	}
}

