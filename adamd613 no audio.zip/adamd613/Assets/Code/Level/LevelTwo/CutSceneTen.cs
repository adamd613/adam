﻿using UnityEngine;
using System.Collections;

public class CutSceneTen: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject thisPat;
	public FollowerMob pat;
	public Player player;
	public EndingDialogue dialogue;
	public GameObject thisSecondDia;
	public EndingDialogue secondDialogue;
	public GameObject holding;
	public GameObject nextScene;

	public bool upping;
	public bool righting;
	public bool downing;
	public bool canWalk;
	public bool forceGive;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{


		if (player.progPoint == 3) 
		{
			cutScene.SetActive (true);
			thisPat.SetActive (true);
		}

		if (player.progPoint != 3) 
		{
			cutScene.SetActive (false);
		}

		if (righting == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 2 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
		if (downing == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			player.animator.Play ("WalkDown");
		}
		if (upping == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			player.animator.Play ("WalkUp");
		}

		if (dialogue.textNum >= 1 && canWalk == false) 
		{

			{
				StartCoroutine (walkThrough ());
			}


		}
		if (secondDialogue.textNum >= 7) 
		{
			StartCoroutine (giveForce ());
		}

		if (secondDialogue.textNum >= 11)
		{
			StartCoroutine (ending ());
		}

	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}


	IEnumerator walkThrough()
	{

		canWalk = true;
		dialogue.enabled = false;
		righting = true;
		yield return new WaitForSeconds (1);
		righting = false;
		downing = true;
		yield return new WaitForSeconds (.45f);
		downing = false;
		righting= true;
		yield return new WaitForSeconds (1.28f);
		righting= false;
		upping = true;
		yield return new WaitForSeconds (.001f);
		upping = false;
		thisSecondDia.SetActive (true);

	}

	IEnumerator giveForce()
	{
		if (forceGive == false) 
		{
			player.ipManager.addToItemInventory (8, 1);
			forceGive = true;
			player.maxEnergy += 10;
			player.energy = player.maxEnergy;
		}
		yield return new WaitForSeconds (.45f);
	}



	IEnumerator ending()
	{

		thisSecondDia.SetActive (false);
		player.enabled = true;
		holding.SetActive (true);
		levelManager.GetComponent<AudioSource> ().UnPause();
		yield return new WaitForSeconds (.2f);
		player.progPoint = 4;
		nextScene.SetActive (true);

	}
}

