﻿using UnityEngine;
using System.Collections;

public class PlayerStopper: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public OrderedDialogue dialogue;
	public Collider2D thisCollider;

	public bool walkDown;

	public int thisProg;
	public int textTrigger;



	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if (player.progPoint <= thisProg) 
		{

			cutScene.SetActive (true);
		}
		else
		{

			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}
			
		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}

		if (walkDown == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.down * 2 * Time.deltaTime;	
			player.animator.Play ("WalkDown");
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator ending()
	{

		walkDown = true;
		yield return new WaitForSeconds(1f);
		walkDown = false;
		player.enabled = true;
		holding.SetActive (true);
	}
}


