﻿using UnityEngine;
using System.Collections;

public class CutSceneTwentyOne: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisNPC;
	public FollowerMob NPC;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;
	public HUDController HUD;

	public EndingDialogue dialogue;
	public GameObject thisDiaTwo;
	public EndingDialogue dialogueTwo;
	public GameObject thisDiaThree;
	public EndingDialogue dialogueThree;
	public GameObject thisSongDia;
	public AutoDia songDia;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public Animator strum;
	public GameObject notes;

	public bool canPlay;
	public bool canMove;
	public bool canEnd;

	public bool upping;
	public bool lefting;

	public int thisProg;
	public int nextProg;
	public int textTrigger;



	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
			HUD =  thisPlayer.GetComponent<HUDController> ();
		} 

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= 2 && canMove == false) 
		{
			StartCoroutine (walkUp ());
			dialogue.enabled = false;
		}

		if (dialogueTwo.textNum >= 3 && canPlay == false) 
		{
			StartCoroutine (playSong ());
		}
		if (dialogueThree.textNum >= 3 && canEnd == false) 
		{
			StartCoroutine (ending ());
		}


		if (upping == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			player.animator.Play ("WalkUp");
		}
		if (lefting == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.left * 2 * Time.deltaTime;	
			player.animator.Play ("WalkLeft");
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;

			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	IEnumerator walkUp()
	{
		canMove = true;
		upping = true;
		yield return new WaitForSeconds(.6f);
		upping = false;
		lefting = true;
		yield return new WaitForSeconds(2.3f);
		lefting = false;
		player.animator.Play ("WalkUp");
		thisDiaTwo.SetActive (true);

	}
	IEnumerator playSong()
	{
		HUD.enabled = false;
		thisDiaTwo.SetActive (false);
		canPlay = true;
		AudioSource trapMusic = GetComponent<AudioSource>();

		trapMusic.Play();
		strum.enabled = true;
		notes.SetActive (true);
		yield return new WaitForSeconds(38f);
		thisSongDia.SetActive (true);

		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.isBreak = true;
		yield return new WaitForSeconds(19f);
		songDia.isBreak = false;
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.textNum += 1;
		songDia.GenerateDialogue();
		yield return new WaitForSeconds(4.75f);
		songDia.isBreak = true;
		thisSongDia.SetActive (false);
		yield return new WaitForSeconds(21f);
		strum.enabled = false;
		notes.SetActive (false);
		trapMusic.Stop();
		HUD.enabled = true;
		thisDiaThree.SetActive (true);
	}

	IEnumerator ending()
	{

		canEnd = true;
		yield return new WaitForSeconds(1f);
		levelManager.GetComponent<AudioSource> ().Play();
		player.enabled = true;
		holding.SetActive (true);
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}


