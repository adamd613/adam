﻿using UnityEngine;
using System.Collections;

public class CutSceneThirteen: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public GameObject thisMark;
	public FollowerMob mark;
	public Player player;
	public EndingDialogue dialogue;
	public GameObject holding;
	public GameObject nextScene;
	public Collider2D thisCollider;
	public bool shorterRange;
	public MarkHUD markHUD;

	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if (shorterRange == true) {
			mark.range = 2;
		} else {
			mark.range = 5;
		}

		if (player.progPoint == 7) 
		{
			
			cutScene.SetActive (true);
		}

		if (player.progPoint != 7) 
		{
			
			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= 3) 
		{
			StartCoroutine (ending ());
		}


	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			shorterRange = true; 
			player.moving = false;
			holding.SetActive (false);

			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
		}
	}


	IEnumerator ending()
	{
		yield return new WaitForSeconds(.5f);
		player.enabled = true;
		shorterRange = false;
		holding.SetActive (true);
		player.progPoint = 8;
		markHUD.enabled = true;
		shorterRange = false;
		nextScene.SetActive (true);
	}
}


