﻿using UnityEngine;
using System.Collections;

public class CutSceneSeventeen: MonoBehaviour {

	public GameObject levelManager;
	public GameObject cutScene;

	public GameObject thisMark;
	public FollowerMob mark;

	public GameObject thesePats;

	public GameObject thisPlayer;
	public Player player;
	public GameObject holding;

	public EndingDialogue dialogue;
	public GameObject nextScene;
	public Collider2D thisCollider;

	public bool resetMark;
	public bool left;
	public bool right;

	public int thisProg;
	public int nextProg;
	public int textTrigger;
	public bool righting;
	public bool upping;


	void Start () 
	{

		cutScene = gameObject;

		holding = GameObject.FindGameObjectWithTag ("Holding");

		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Player> ();
		} 
		if(thisMark == null)
		{
			thisMark = GameObject.FindGameObjectWithTag ("Mark");
			mark = thisMark.GetComponent<FollowerMob> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}

	void Update ()
	{

		if (player.progPoint == thisProg) 
		{

			cutScene.SetActive (true);
		}

		if (player.progPoint != thisProg) 
		{

			cutScene.SetActive (false);

		}


		if (dialogue.textNum >= textTrigger) 
		{
			StartCoroutine (ending ());
		}
		if (righting == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.right * 4 * Time.deltaTime;	
			player.animator.Play ("WalkRight");
		}
		if (upping == true) {
			player.GetComponent<Rigidbody2D> ().transform.position += Vector3.up * 2 * Time.deltaTime;	
			player.animator.Play ("WalkUp");
		}

	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.moving = false;
			holding.SetActive (false);

			if (resetMark == true && left == false && right == false) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x,thisPlayer.transform.position.y - 3);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && left == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x - 3,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			if (resetMark == true && right == true) {
				thisMark.transform.position = new Vector3(thisPlayer.transform.position.x + 3,thisPlayer.transform.position.y);
				mark.distance = 2;
				mark.range = 5;
			}
			player.enabled = false;
			//AudioSource trapMusic = GetComponent<AudioSource>();

			//trapMusic.Play();
			//levelManager.GetComponent<AudioSource> ().Pause();
			StartCoroutine (goRight ());

		}
	}
	IEnumerator goRight()
	{
		righting = true;
		holding.SetActive (false);
		yield return new WaitForSeconds(3.8f);
		righting = false;
		holding.SetActive (false);
		upping = true;
		yield return new WaitForSeconds(.8f);
		upping = false;
	}
	IEnumerator ending()
	{
		thesePats.SetActive (true);
		player.enabled = true;
		yield return new WaitForSeconds(3f);
		if (player.health < player.maxHealth)
			player.health = 0;
		player.progPoint = nextProg;
		nextScene.SetActive (true);
	}
}



