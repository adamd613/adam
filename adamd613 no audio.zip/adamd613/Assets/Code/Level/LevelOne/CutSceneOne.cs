﻿using UnityEngine;
using System.Collections;

public class CutSceneOne: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public Entity follower;
	public Entity player;
	public EndingDialogue dialogue;
	public GameObject associatedItem;
	public GameObject holding;
	public int cutOneOver;


	public GameObject levelManager;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");
	}
	
	void Update ()
	{
		if (dialogue.textNum >= 4) 
		{
			player.enabled = true;
			holding.SetActive (true);
			associatedItem.SetActive (true);
			levelManager.GetComponent<AudioSource> ().UnPause();
			follower.speed += 2;
			dialogue.toggleOff ();
			cutScene.SetActive (false);


		}
	}
		
	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			player.enabled = false;
			holding.SetActive (false);
			AudioSource trapMusic = GetComponent<AudioSource>();

			trapMusic.Play();
			levelManager.GetComponent<AudioSource> ().Pause();
		}
	}
	public void CutOneOver()
	{

	}
}

