﻿using UnityEngine;
using System.Collections;

public class CutSceneThree: MonoBehaviour {

	public GameObject thisPlayer;
	public GameObject cutScene;
	public Entity player;
	public EndingDialogue dialogue;
	public GameObject npc;
	public GameObject oldNpc;
	public float distance;

	public GameObject enemyOne;
	public GameObject enemyTwo;
	public GameObject enemyThree;
	public GameObject enemyFour;

	public GameObject shop;
	public GameObject villagerHouse;
	public GameObject villagerHouseTwo;
	public GameObject villagerHouseThree;
	public GameObject villagerOne;

	public GameObject genericHouseTwo;
	public GameObject genericHouseThree;
	public GameObject genericHouseOne;

	public GameObject levelManager;

	public GameObject holding;

	void Start () 
	{
		holding = GameObject.FindGameObjectWithTag ("Holding");

		if(thisPlayer == null)
		{
			thisPlayer = GameObject.FindGameObjectWithTag ("Player");
			player = thisPlayer.GetComponent<Entity> ();
		} 
		levelManager = GameObject.FindGameObjectWithTag ("levelManager");

	}

	void Update ()
	{
		if (dialogue.textNum >= 4) 
		{
			
			holding.SetActive (true);
			stopMoving ();
			villagerOne.SetActive (true);
			villagerHouse.SetActive (true);
			villagerHouseTwo.SetActive (true);
			villagerHouseThree.SetActive (true);
			genericHouseThree.SetActive (false);
			genericHouseOne.SetActive (false);
			genericHouseTwo.SetActive (false);
			shop.SetActive (true);
			player.enabled = true;
			levelManager.GetComponent<AudioSource> ().UnPause();
			dialogue.toggleOff ();
			cutScene.SetActive (false);
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if (col.GetComponent<Player> () != null) {
			player.enabled = false;
			AudioSource trapMusic = GetComponent<AudioSource> ();

			trapMusic.Play ();
			levelManager.GetComponent<AudioSource> ().Pause ();

			Destroy (enemyOne);
			Destroy (enemyTwo);
			Destroy (enemyThree);
			Destroy (enemyFour);
			holding.SetActive (false);

			oldNpc.SetActive (false);
			npc.SetActive (true);

		}
	}
	public void stopMoving()
	{
		Destroy (npc.GetComponent<CutSceneThreeNPC>());
	}
}

