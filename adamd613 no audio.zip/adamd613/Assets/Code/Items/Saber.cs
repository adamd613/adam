﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Saber : Item {

	public int direction;

	public int minDamage;
	public int maxDamage;
	private int realDamage;
	public SpriteRenderer weaponSpriteParent;

	public AudioClip swing;

	public Vector2 forwardPos, backPos, sidePos;

	public CircleCollider2D DamageCollider2D;

	public List<Entity> enemyInRange = new List<Entity>();

	void Start () 
	{
		
	}

	void Update () 
	{
		if (player.health <= 0 || (player.transform.position.x == 15 && player.transform.position.y == 28)) 
		{
			enemyInRange.Clear();
		}
		player.attackSpeed = .3f;

		if (Input.GetKey (KeyCode.W) || Input.GetKey (KeyCode.UpArrow)) 
		{
			direction = 1;
		}
		if (Input.GetKey (KeyCode.S) || Input.GetKey (KeyCode.DownArrow)) 
		{
			direction = 0;
		}
		if (Input.GetKey (KeyCode.A) || Input.GetKey (KeyCode.LeftArrow)) 
		{
			direction = 2;
		}
		if (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow)) 
		{
			direction = 3;
		}
		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && player.usable == true)  
		{
			attack ();
		}
		if ( Input.GetKeyDown(KeyCode.LeftShift)) 
		{
			attack ();
		}


		if (direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 45);
			weaponSpriteParent.transform.localRotation = newRot;	
			weaponSpriteParent.transform.localPosition = forwardPos;
			DamageCollider2D.offset = new Vector2 (-.6f, -.2f);
			if (player.attackAnim == true) 
			{
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, 0);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = forwardPos;
			}
		}
		if (direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			Quaternion newRot = Quaternion.Euler (0, 180, 45);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = backPos;
			DamageCollider2D.offset = new Vector2 (.4f, .9f);
			if (player.attackAnim == true)  
			{
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 180, 0);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = backPos;
			}
		}
		if (direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			Quaternion newRot = Quaternion.Euler (0, 180, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (.6f, 0f);
			if (player.attackAnim == true) 
			{
				weaponSpriteParent.sortingOrder = 19;
				Quaternion Rot = Quaternion.Euler (0, 180, -45);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
		}
		if (direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			Quaternion newRot = Quaternion.Euler (0, 0, 0);
			weaponSpriteParent.transform.localRotation = newRot;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (.6f, 0);
			if (player.attackAnim == true) 
			{
				weaponSpriteParent.sortingOrder = 21;
				Quaternion Rot = Quaternion.Euler (0, 0, -45);
				weaponSpriteParent.transform.localRotation = Rot;	
				weaponSpriteParent.transform.localPosition = sidePos;
			}
		}
	}

	public void attack()
	{

		realDamage = Random.Range (minDamage, maxDamage);
		foreach (Entity e in enemyInRange) 
			e.takeHealth (realDamage);
		AudioSource swing = GetComponent<AudioSource> ();
		swing.Play ();

	}

	void OnTriggerEnter2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			if (tempEnt.isHostile) 
			{
				if (enemyInRange.Contains (tempEnt))
					return;
				enemyInRange.Add (tempEnt);
			}
		}
	}

	void OnTriggerExit2D(Collider2D other)
	{
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			int index = enemyInRange.IndexOf (tempEnt);
			enemyInRange.Remove (enemyInRange[index]);
		}
	}
}
