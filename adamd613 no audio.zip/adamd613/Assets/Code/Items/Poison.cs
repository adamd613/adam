﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class Poison : Item {

	public int direction;

	public GameObject poison;

	public int minDamage;
	public int maxDamage;
	private int realDamage;
	public SpriteRenderer weaponSpriteParent;
	//public SpriteRenderer throwingPotion;
	//public SpriteRenderer landingPotion;

	public Vector2 forwardPos, backPos, sidePos;

	public CircleCollider2D DamageCollider2D;

	public List<Entity> enemyInRange = new List<Entity>();

	void Start () 
	{
		
	}

	void Update () 
	{
		if (player.health <= 0 || (player.transform.position.x == 15 && player.transform.position.y == 28)) 
		{
			enemyInRange.Clear();
		}

		player.attackSpeed = .2f;

		if (ipManager.items [2].amountOfItem > 0) 
		{
			weaponSpriteParent.enabled = true;
		}
		else if (ipManager.items [2].amountOfItem == 0) 
		{
			poison.SetActive(false);
			isEquip = false;
		}
		if (Input.GetKey (KeyCode.W) || Input.GetKey (KeyCode.UpArrow)) 
		{
			direction = 1;
		}
		if (Input.GetKey (KeyCode.S) || Input.GetKey (KeyCode.DownArrow)) 
		{
			direction = 0;
		}
		if (Input.GetKey (KeyCode.A) || Input.GetKey (KeyCode.LeftArrow)) 
		{
			direction = 2;
		}
		if (Input.GetKey (KeyCode.D) || Input.GetKey (KeyCode.RightArrow)) 
		{
			direction = 3;
		}
		if ((Input.GetMouseButtonDown (0) || Input.GetKeyDown(KeyCode.LeftShift)|| Input.GetKeyDown(KeyCode.RightShift)) && player.usable == true)  
		{
			StartCoroutine (usePoison ());
		}
		if (direction == 0) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = forwardPos;
			weaponSpriteParent.transform.localPosition = forwardPos;
			DamageCollider2D.offset = new Vector2 (-.35f, -4);
		}
		if (direction == 1) 
		{
			weaponSpriteParent.sortingOrder = 19;
			weaponSpriteParent.transform.localPosition = backPos;
			weaponSpriteParent.transform.localPosition = backPos;
			DamageCollider2D.offset = new Vector2 (.35f, 4);
		}
		if (direction == 2) 
		{
			weaponSpriteParent.sortingOrder = 19; 
			weaponSpriteParent.transform.localPosition = sidePos;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (-4, 0);
		}
		if (direction == 3) 
		{
			weaponSpriteParent.sortingOrder = 21;
			weaponSpriteParent.transform.localPosition = sidePos;
			weaponSpriteParent.transform.localPosition = sidePos;
			DamageCollider2D.offset = new Vector2 (4, 0);
		}
	}

	public void attack()
	{
		realDamage = Random.Range (minDamage, maxDamage);
		foreach (Entity e in enemyInRange) 
		{
			e.takeHealth (realDamage);
		}

	}

	IEnumerator flashSprite()
	{
		attack ();
		weaponSpriteParent.enabled = false;
		yield return new WaitForSeconds (.1f);
		weaponSpriteParent.enabled = true;
	}
	IEnumerator usePoison()
	{
		if (ipManager.items [2].amountOfItem > 0) {
			StartCoroutine (flashSprite ());
		} 
		yield return new WaitForSeconds (.02f);
		ipManager.removeItemFromInventory (1, 1);
	}

	void OnTriggerEnter2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			if (tempEnt.isHostile) 
			{
				if (enemyInRange.Contains (tempEnt))
					return;
				enemyInRange.Add (tempEnt);
			}
		}
	}

	void OnTriggerExit2D(Collider2D other) {
		Entity tempEnt = other.GetComponent<Entity> ();
		if(tempEnt != null)
		{
			int index = enemyInRange.IndexOf (tempEnt);
			enemyInRange.Remove (enemyInRange[index]);
		}
	}
}
