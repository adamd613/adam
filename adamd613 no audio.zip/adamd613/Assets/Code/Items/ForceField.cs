﻿using UnityEngine;
using System.Collections;

public class ForceField : Item {

	public Entity entity;
	public GameObject theAnimation;

	public bool waitFor;

	void Start () 
	{
		waitFor = true;
	}

	void OnAwake()
	{
		waitFor = true;
	}

	void Update ()
	{
		if (entity.health <= 0)
			waitFor = true;
		
		if (entity.isForceFielding == true && waitFor == true && entity.energy <= entity.maxEnergy)
		{
			StartCoroutine (isUsingNow ());
		}
		{	
			if (Input.GetKey (KeyCode.Space) && entity.energy >= 1 ) 
			{
				on ();
			} 
			else 
			{
				off ();
			}
		}

		if (Input.GetKeyUp (KeyCode.Space))
		{
			off ();

		}
	}

	public void on ()
	{
		entity.armor = 10;
		entity.isForceFielding = true;
		theAnimation.SetActive (true);

	}
	public void off()
	{
		waitFor = true;
		entity.armor = 0;
		entity.isForceFielding = false;
		theAnimation.SetActive (false);

	}
	IEnumerator isUsingNow()
	{
		waitFor = false;
		entity.energy -= 1;
		yield return new WaitForSeconds (.25f);
		waitFor = true;
	}
}
