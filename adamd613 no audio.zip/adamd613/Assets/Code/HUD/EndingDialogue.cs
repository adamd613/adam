﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class EndingDialogue : MonoBehaviour {

	private bool showingDialogue;

	public Level levelManager;

	public GameObject thisDialogue;

	public EndingDialogue endDialogue;

	public int textNum;

	public bool isInInventory;

	private string dialogueMessage;
	public List<Dialogue> dialogueMessages = new List<Dialogue>();

	public GUISkin skinn;


	void Start () 
	{
		levelManager = GameObject.FindGameObjectWithTag("levelManager").GetComponent<Level>();
		isInInventory = false;
	}

	void Update () 
	{
		if(Input.GetKeyDown(KeyCode.R) || Input.GetKeyDown(KeyCode.Escape))
			isInInventory = !isInInventory;
		if(showingDialogue)
		{
			if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetMouseButtonDown (1))
				textNum += 1;

			if(Input.GetKeyDown(KeyCode.Return) || Input.GetKeyDown(KeyCode.KeypadEnter) || Input.GetMouseButtonDown (1))
				GenerateDialogue();
		}
	}

	void OnGUI()
	{
		GUI.skin = skinn;
		GUI.depth = 0;
		if (!isInInventory) {
			if (showingDialogue) {
				GUI.Box (new Rect (Screen.width - 650, Screen.height - 120, Screen.width - 130, 100), dialogueMessage, "Dialogue");
			}
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null && showingDialogue == false)
		{
			GenerateDialogue();
			showingDialogue = true;
		}
	}

	public void GenerateDialogue()
	{
		dialogueMessage = dialogueMessages[textNum].dialogue;
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			showingDialogue = false;
		}
	}
	public void toggleOff()
	{
		thisDialogue.SetActive (false);
	}
	public void turnOff()
	{
		endDialogue.enabled = false;
	}
}

