﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class AutoDia : MonoBehaviour {

	private bool showingDialogue;

	public Level levelManager;

	public GameObject thisDialogue;

	public AutoDia endDialogue;

	public int textNum;
	public bool isBreak;

	private string dialogueMessage;
	public List<Dialogue> dialogueMessages = new List<Dialogue>();

	public GUISkin skinn;


	void Start () 
	{
		levelManager = GameObject.FindGameObjectWithTag("levelManager").GetComponent<Level>();
		isBreak = false;
	}

	void Update () 
	{

	}

	void OnGUI()
	{
		GUI.skin = skinn;
		GUI.depth = 0;
		if (isBreak == false) {
			if (showingDialogue) {
				GUI.Box (new Rect (Screen.width - 650, Screen.height - 120, Screen.width - 130, 100), dialogueMessage, "Dialogue");
			}
		}
	}

	void OnTriggerEnter2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null && showingDialogue == false)
		{
			GenerateDialogue();
			showingDialogue = true;
		}
	}

	public void GenerateDialogue()
	{
		dialogueMessage = dialogueMessages[textNum].dialogue;
	}

	void OnTriggerExit2D(Collider2D col)
	{
		if(col.GetComponent<Player>() != null)
		{
			showingDialogue = false;
		}
	}
	public void toggleOff()
	{
		thisDialogue.SetActive (false);
	}
	public void turnOff()
	{
		endDialogue.enabled = false;
	}
}

