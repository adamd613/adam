﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class DialogueController : MonoBehaviour {

	public List<Transform> storyTransforms = new List<Transform>();

	void Start () {
	
	}
	

	void Update () {
	
	}
}
